import os
import urllib
from datetime import datetime
from time import sleep

import allure
import pytest
from selenium import webdriver
from selenium.webdriver import ChromeOptions

from configuration import conftest_constants as constants
from configuration.conftest_constants import DOWNLOAD_PATH, CHROME_DRIVER, BROWSER, \
    RESULT, ERROR_FILE_PATH
from logger.custom_logger import custom_logger
from utils.file_operations import load_db_config_file, passed_tests_write_in_csv, failed_tests_write_in_csv
from utils.screenshot_util import chrome_take_full_page_screenshot
import output_data_set as Shared

log = custom_logger()


def pytest_addoption(parser):
    """ Command line options:
        Example of allowing pytest to accept a command line option  """
    parser.addoption("-B", "--browser",
                     dest="browser",
                     default=BROWSER,
                     help="Browser. Valid options are chrome or ie or edge or headlesschrome "
                          "or remotechrome or suaselabschrome or chromewithwebseriesplugin")
    parser.addoption("--driver",
                     dest="driver",
                     default=CHROME_DRIVER,
                     help="Path of the chrome driver")
    parser.addoption("--screenshot",
                     dest="screenshot",
                     default='True',
                     help="mention if screenshots are required."
                          " Valid options: True/False")
    parser.addoption("--env",
                     action="store",
                     default=None,
                     choices=["dev", "qa", "other"],
                     help="mention if env is required."
                          "Valid options: dev/qa")


@pytest.fixture
def browser(request):
    """ pytest fixture for browser
    :return:
    """
    return request.config.getoption("browser")


def get_driver(browser):
    """  method to instantiate the browser type  """
    driver = None
    # below settings are for setting default download path for automatic downloads.
    prefs = {
        "download.default_directory": DOWNLOAD_PATH,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True
    }
    if browser.lower() == 'chrome':
        chrome_options = ChromeOptions()
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument(
            "--disable-dev-shm-usage")  # // overcome limited resource problems #// open Browser in maximized mode
        chrome_options.add_argument("disable-infobars")  # // disabling infobars
        chrome_options.add_argument("--disable-extensions")  # // disabling extensions
        chrome_options.add_argument("--disable-gpu")  # // applicable to windows os only
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_argument("--ignore-certificate-errors")
        chrome_options.add_experimental_option('prefs', prefs)
        chrome_options.add_experimental_option('prefs', {"profile.default_content_setting_values.geolocation": 2})
        chrome_options.add_experimental_option('prefs', {"profile.default_content_setting_values.notifications": 2})
        chrome_options.add_argument("--disable-popup-blocking")  # disabling popup blocking
        sleep(5)
        if constants.EXECUTION_MODE == 'Debug':
            chrome_options.add_experimental_option("detach", True)
        else:
            driver = webdriver.Chrome(options=chrome_options)
            print(driver.capabilities['browserVersion'])
    elif browser.lower() == 'headless':
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--window-size=1920,1200")
        chrome_options.add_argument("--ignore-certificate-errors")
        chrome_options.add_experimental_option('prefs', prefs)
        chrome_options.add_argument('--headless=new')
        if constants.EXECUTION_MODE == 'Debug':
            chrome_options.add_experimental_option("detach", True)
        else:
            driver = webdriver.Chrome(options=chrome_options)
            print(driver.capabilities['browserVersion'])
    elif browser.lower() == 'firefox':
        profile = webdriver.FirefoxOptions()
        profile.accept_untrusted_certs = True
        driver = webdriver.Firefox(options=profile)
        # driver.maximize_window()

        # elif browser.lower() == 'ie':
        # driver = webdriver.Ie(options=)
        # driver.maximize_window()
        # elif browser.lower() == 'edge':
        #     options = webdriver.EdgeOptions()

        #     driver = webdriver.Edge(options=options)

    return driver


@pytest.fixture
def init_driver(request, browser):
    """  method to instantiate the driver """
    driver = get_driver(browser)
    env = request.config.getoption('--env')
    if env is None:
        print("env is not present")
    elif env == "dev":
        driver.get(load_db_config_file("Eagle Eye API", "dev"))
    elif env == "qa":
        driver.get(load_db_config_file("Eagle Eye API", "uat"))
    else:
        raise ValueError(f"Invalid environment:{env}")
    driver.implicitly_wait(10)
    tests_failed_before_module = request.session.testsfailed
    yield driver
    """ tear down after the tests """
    if request.session.testsfailed > tests_failed_before_module:
        allure.attach(driver.get_screenshot_as_png(), name='error_screenshot',
                      attachment_type=allure.attachment_type.PNG)
    driver.quit()


def pytest_configure(config):
    """
    method to get commandline input values and set to environment variables
    :param config: config object
    """
    os.environ["screenshot"] = config.getoption('screenshot')
    os.environ["browser"] = config.getoption('browser')
    os.environ["driver"] = config.getoption('driver')
    config.addinivalue_line("markers", "regression: mark test to run regression scenarios")


def add_screenshot(driver, title):
    """
    method to add screenshot to allure report based on commandline input
    :param driver: webdriver instance
    :param title: name of screeshot
    """
    try:
        if os.getenv('screenshot'):
            if os.getenv('screenshot').lower() == 'true':
                if os.getenv('browser').lower() == 'chrome':
                    allure.attach(chrome_take_full_page_screenshot(driver), name=title,
                                  attachment_type=allure.attachment_type.PNG)
                else:
                    allure.attach(driver.get_screenshot_as_png(), name=title,
                                  attachment_type=allure.attachment_type.PNG)
                log.info('attached screenshot {0}'.format(title))
    except Exception as e:
        log.error('Failed to attach screenshot due to exception {0}'.format(e))


def pytest_html_report_title(report):
    report.title = "Marketing Test Automation Report"


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    timestamp = datetime.now().strftime("%m-%d-%Y_%H:%M:%S")
    pytest_html = item.config.pluginmanager.getplugin('html')
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, 'extra', [])
    if report.when == 'call':

        TEST_RESULT_PATH = RESULT
        file_name = f'{report.nodeid.split("::")[0]}_{timestamp}.png'.replace(".py", "")
        test_case = item.nodeid.split('::')[0] + "-{}".format(timestamp)
        status = report.outcome

        if "init_driver" in item.fixturenames:
            feature_request = item.funcargs['request']
            driver = feature_request.getfixturevalue('init_driver')
            img_path = os.path.join(TEST_RESULT_PATH, file_name)
            driver.save_screenshot(img_path)
            screenshot = driver.get_screenshot_as_base64()

            # always add url to report
            URL = driver.current_url
            extra.append(pytest_html.extras.url(URL))
            xfail = hasattr(report, 'wasxfail')
            if (report.skipped and xfail) or (report.failed and not xfail):
                extra.append(pytest_html.extras.image(screenshot, ''))
            report.extra = extra
        if Shared.file_path != '' and Shared.output_dict != '':
            passed_tests_write_in_csv(Shared.file_path, Shared.output_dict, test_case, status)
        results = call.excinfo
        if status == 'failed':
            error_message = str(results.value)
            failed_tests_write_in_csv(test_case, status, ERROR_FILE_PATH, error_message)

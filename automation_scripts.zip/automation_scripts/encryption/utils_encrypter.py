import binascii
import os

from pyDes import des, ECB


def encoder(input_text):
    k = des('DESCRYPT', ECB, b"\0\0\0\0\0\0\0\0", pad=None, padmode=2)
    d = k.encrypt(input_text)
    binary_field = binascii.hexlify(bytearray(d))
    return binary_field.decode()



def decoder(input_text):
    binary_field = binascii.unhexlify(input_text.encode())
    k = des('DESCRYPT', ECB, b"\0\0\0\0\0\0\0\0", pad=None, padmode=2)
    b = k.decrypt(binary_field)
    return b.decode('utf-8')


if __name__ == '__main__':
    string = input("Enter the text to be encrypted:")
    print("The encrypted text for your input is : {}".format(encoder(string)))
    print("The decrypted text for your input is : {}".format(decoder(string)))
    os.system('pause')




"""
page object model for getting the Storing the output values into dict
"""
import os
from pathlib import Path
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log
from output_data_set import svoc_output_set, report_data_set


class OutputresultPage():
    """
    Class consists of storing output values objects and methods
    """
    test = ""

    def __init__(self, driver):
            SeHelperPage.__init__(self, driver=None)
            self.driver = driver


    def collect_values(self, LAST_NAME, GEAC_NO, DOB, ZIPCODE, CARD_TYPE, CW_WALLET_ID=None):
        status = False
        try:
            svoc_output_set["LAST_NAME"] = LAST_NAME
            svoc_output_set["CW_WALLET_ID"] = CW_WALLET_ID
            svoc_output_set["GEAC_NO"] = GEAC_NO
            svoc_output_set["DOB"] = DOB
            svoc_output_set["ZIPCODE"] = ZIPCODE
            svoc_output_set["CARD_TYPE"] = CARD_TYPE
            status = True
            log.info(" All the data's captured successfully into the dictionary")
        except Exception as e:
            status &= False
            log.error('Exception occurred - {0} Failed to write a data into dictionary'.format(e))
        return status

    def collect_values_1(self, HH_NUM_API, PARENT_WALLET_ID, WALLET_ID_API, CARD_STATUS_API, CONSUMER_WALLET_IDENTITYID):
        status = False
        try:
            report_data_set["API_HH_NUM"] = HH_NUM_API
            report_data_set["PARENT_WALLET_ID"] = PARENT_WALLET_ID
            report_data_set["API_WALLET_ID"] = WALLET_ID_API
            report_data_set["API_CARD_STATUS"] = CARD_STATUS_API
            report_data_set["CONSUMER_WALLET_IDENTITYID"] = CONSUMER_WALLET_IDENTITYID
            status = True
            log.info(" All the data's captured successfully into the dictionary")
        except Exception as e:
            status &= False
            log.error('Exception occurred - {0} Failed to write a data into dictionary'.format(e))
        return status


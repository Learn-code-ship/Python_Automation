import json
import re

from conftest import log


class ApiHelperPage():

    def extract_value_by_key(self, json_data, key):
        """
        Method to extract the value by key
        :param: json_data - api response
        :param: Key - extract value based on the key
        :return: results
        """
        val = ''
        status = True
        try:
            if json_data != '':
                json_data = json.loads(json_data)
                val = None
                def extract_recursive(data, target_key):
                    nonlocal val
                    if isinstance(data, dict):
                        for k, v in data.items():
                            if k == target_key:
                               val = v
                            elif isinstance(v, (dict, list)):
                                extract_recursive(v, target_key)
                    elif isinstance(data, list):
                        for item in data:
                            extract_recursive(item, target_key)
                extract_recursive(json_data, key)
                log.info("Extracted the value by {0} -{1} from the json response successfully".format(key, val))
            else:
                log.error("The sent response is empty either it 400 or 404")
        except Exception as e:
            log.error("Exception {0} while finding elements".format(e))
            status = False
        return status, val


    def validate_db_with_api_response(self, db_or_ui_value, ee_api_value, name, card_no=None):
        """
        Method to validate db/ui and api
        :param: ui - wallet_id_ui, parent_walletid_ui, hh_num_ui
        :param: api - wallet_id, parent_walletid, hh_num
        :return: results
        """
        status = True
        try:
            if (db_or_ui_value != '' and db_or_ui_value is not None  and ee_api_value != '' and ee_api_value is not None):
                if db_or_ui_value == ee_api_value:
                    log.info("Api {0}_id : {1} matches with svoc {0}_id : {2} ".format(name, ee_api_value, db_or_ui_value))
                else:
                    log.error("Api {0}_id : {1} doesn't matches with svoc {0}_id : {2}".format(name, ee_api_value, db_or_ui_value))
                    status = False
            else:
                log.error("Either passed parameter one must be empty so this check is skipped")
        except Exception as e:
                log.error("Exception occured - {} while validating svoc ui vs eagle eye api".format(e))
                status = False
        return status

    def trim_the_string(self, string_val):
        value = ''
        try:
            value = re.sub(r'\([^)]*\)', '', string_val).strip()
            log.info("Value is trimmed successfully from {0} to {1}".format(string_val,value))
        except Exception as e:
            log.error("Exception - {} occured during trimming the string".format(e))
        return value


    def extract_multi_value_by_multi_key(self, json_data, main_key, sub_key1, sub_key2=None, sub_key3=None):
        """
        Method to extract the multi value by key
        :param: json_data - api response
        :param: Key - extract value based on the main key containing multiple dict
        :return: results
        """
        result = ''
        status = False
        try:
            if json_data != '':
                json_data = json.loads(json_data)
                result = []
                current_level = json_data
                if main_key in current_level:
                    row = current_level[main_key]
                    for part in row:
                        result.append({
                            sub_key1: part[sub_key1],
                            sub_key2: part[sub_key2],
                            sub_key3: part[sub_key3],
                        })
                    log.info("New results set {} is ceated and values are appended".format(result))
                else:
                    print("main key is not found in the json response")
            else:
                log.error("The sent response is empty either it 400 or 404")
                status = True
        except Exception as e:
            log.error("Exception {0} while finding elements".format(e))
            status = False
        return status, result
#!/usr/bin/python
import email
import os
import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.mime.text import MIMEText
from pathlib import Path
import sys
from jinja2 import Template



class Email_Pytest_Report:

    arg = {"Output_File": ""}

    if len(sys.argv)>4:
        arg['Output_File'] = sys.argv[4]

    report_file = sys.argv[1]
    head, tail = os.path.split(report_file)
    release_name = tail.replace('.html', '')
    app = Path(report_file).parts[-3]
    build_no = sys.argv[2]
    azure_exec_task_status = sys.argv[3]
    timestamp = datetime.now().strftime("%m-%d-%Y_%H:%M:%S")
    email_html_template_path = os.path.join(Path(__file__).parent, 'email_template.html')
    html_file = open(email_html_template_path, "r", encoding='utf-8')
    template = html_file.read()
    t = Template(template)
    html = t.render(App=app, Release_Name=release_name, Build_No=build_no)

    smtpserver = 'mail.gianteagle.com'
    to = ['vijaya.raikar@gianteagle.com', 'sharath.kumar@gianteagle.com']
    fromAddr = 'plateng.india@gianteagle.com'
    subject = f"Marketing Automation Results_{azure_exec_task_status}-{timestamp}"

    emailMsg = MIMEMultipart()
    emailMsg['Subject'] = subject
    emailMsg['From'] = 'platengIndia <plateng.india@gianteagle.com>'
    emailMsg['To'] = ", ".join(to)
    emailMsg.attach(MIMEText(html, 'html'))


    def get_attachment(self, attachment_file_path='default'):
        " Get an attachment"
        if attachment_file_path == 'default':
            self.report_file
        else:
            self.report_file = attachment_file_path
        # check file exist or not
        if not os.path.exists(self.report_file):
            raise Exception("File '%s' does not exist. Please provide valid file" % (self.report_file))

    def attach_output_csv_file(self):
        " Get an attachment for other than html report"
        if self.azure_exec_task_status == 'Succeeded' and self.arg['Output_File'] != "":
            self.link_attachment(self.arg['Output_File'])
            print("Output.csv file is attached successfully.")


    def link_attachment(self, attachment_file):
        head, tail = os.path.split(attachment_file)
        file_name = tail
        with open(attachment_file, "rb") as attachment:
            part = MIMEBase('application', "octet-stream")
            part.set_payload(attachment.read())
            email.encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename={}'.format(file_name))
            self.emailMsg.attach(part)
            print("report html file attached successfully")

    def send_email(self):
        try:
            server = smtplib.SMTP(self.smtpserver)
            server.sendmail(self.fromAddr, self.to, self.emailMsg.as_string())
            print("Successfully sent email")
        except smtplib.SMTPException:
            print("Error: unable to send email")
        server.quit()


if __name__ == '__main__':
    emailobj = Email_Pytest_Report()
    emailobj.get_attachment()
    emailobj.attach_output_csv_file()
    emailobj.link_attachment(emailobj.report_file)
    emailobj.send_email()




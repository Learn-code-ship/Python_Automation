import string
import time

import jpype
import jaydebeapi
import pymssql
import os

import pandas as pd
from sqlalchemy.exc import SQLAlchemyError

from configuration.conftest_constants import JAR_FILE_PATH
from encryption import utils_encrypter
from encryption.utils_encrypter import decoder

"""Do not remove below imports required for driver
connectivity using SQL Alchemy"""

from logger.custom_logger import custom_logger
from utils import file_operations

log = custom_logger()
jvm_status = False


def get_db_credentials(db_name):
    """
    function to fetch db credentials from dbconfig file
    :param db_name: String
    :return: dictionary object
    """
    if db_name:
        db_credentials = {
            "dbusername":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "dbusername"),
            "dbpassword":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "dbpassword")
        }
        return db_credentials
    else:
        return None


def get_connection_details(db_name):
    """
    function to fetch connection string details from dbconfig file for Oracle DB
    :param db_name: String
    :return: dictionary object
    """
    if db_name:
        connection_details = {
            "dbhost":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "dbhost"),
            "dbport":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "dbport"),
            "dbname":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "dbname"),
            "dbsid":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "dbsid"),
            "dbdriver":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "driver"),
            "jdbc2":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "jdbc2"),
            "jdbc3":
                file_operations.load_db_config_file(str(db_name).upper(),
                                                    "jdbc3")
        }
        return connection_details
    else:
        return None


# def create_connection_string(db_name):
#     """
#     function to create connection string to connect to db
#     :param db_name: String
#     :return: connection string as String
#     """
#     dbusername = get_db_credentials(db_name)["dbusername"]
#     dbpassword = decoder(get_db_credentials(db_name)["dbpassword"])
#     dbhost = get_connection_details(db_name)["dbhost"]
#     dbport = get_connection_details(db_name)["dbport"]
#     dbname = get_connection_details(db_name)["dbname"]
#     dbsid = get_connection_details(db_name)["dbsid"]
#     dbdriver = get_connection_details(db_name)["dbdriver"]
#     connection_string = ''
#     try:
#         if str(dbname).strip() and str(dbdriver).lower() == "oracle":
#             dsn = cx_Oracle.makedsn(dbhost, dbport, dbname)
#             dsn = dsn.replace('SID', 'SERVICE_NAME')
#             connection_string = dbdriver + '://' + dbusername + ':' + dbpassword + '@' + dsn
#         elif str(dbsid).strip():
#             connection_string = + '://' + dbusername + ':' + \
#                                 dbpassword + '@' + dbhost + ':' + \
#                                 dbport + '/' + dbsid
#     except cx_Oracle.DataError as e:
#         log.error('Data error: %s'.format(e))
#     return connection_string


# def connect_db(db_name):
#     """
#     function to connect oracle db using cx_oracle library
#     :param db_name: String
#     :return: engine as connection string
#     """
#     try:
#         return db.create_engine(create_connection_string(str(db_name).strip()),
#                                 echo=True)
#     except cx_Oracle.DatabaseError as e:
#         log.error('Database connection error: %s'.format(e))
#         return None


# def execute_query(query, engine):
#     """
#     Method to execute given query and retrieve the data from db as dataframe
#     :param query: sql query as string
#     :param engine: engine as connection string
#     :return: result set as data frame
#     """
#     try:
#         time_counter = 0
#         if (engine is not None) and (query is not None):
#             with engine.connect() as con:
#                 result_set = con.execute(query)
#                 df_result_set = pd.DataFrame(result_set.fetchall())
#                 while df_result_set.empty and time_counter < 10:
#                     result_set = con.execute(query)
#                     df_result_set = pd.DataFrame(result_set.fetchmany(100))
#                     time_counter = time_counter + 1
#                     time.sleep(3)
#                 if (df_result_set is not None) and (not df_result_set.empty):
#                     df_result_set.columns = result_set.keys()
#                     log.info('successfully connected to db and fetched results'
#                              'as follows - {0}'.format(df_result_set))
#                     return df_result_set
#                 log.error("Could not fetch records from db"
#                           " even after maximum timeout")
#                 return None
#         else:
#             log.error("Invalid connection object -"
#                       " Either Engine or SQL query is None")
#     except (db.exc.SQLAlchemyError, db.exc.DBAPIError) as e:
#         log.error("Error while establishing connection or"
#                   " executing sql query".format(e))


#def get_mssql_engine_url(db_name):
#    """
#    create engine url for mssql database
#   :param db_name: mssql db connection name
#    :return: engine url
#    """
#    dbusername = get_db_credentials(db_name)["dbusername"]
#    dbpassword = utils_encrypter.decoder(get_db_credentials(db_name)["dbpassword"])
#    host = get_connection_details(db_name)["dbhost"]
#    database = get_connection_details(db_name)["dbname"]
#    try:
#        engine_url = "Driver={SQL Server Native Client 11.0};Server=" + host + ";Database=" + database + ";" \
#                     "uid="+dbusername+";pwd="+dbpassword+""
#        log.info('Successfully created SQL engine url {0}'.format(engine_url))
#    except Exception as e:
#        engine_url = False
#        log.error('Failed to create engine url due to error - {0}'.format(e))
#    return engine_url

# def get_data_from_db(engine_url, sql, *arguments):
#     """
#     connect to SQL db and fetch data into dataframe
#     :param engine_url: db connection url
#     :param sql: sql statement
#     :param arguments: parameters in sql as tuple
#     :return: dataframe or boolean status if connection fails
#     """
#     engine = None
#     try:
#         engine = pyodbc.connect(engine_url)
#         status = True
#         output = pd.read_sql_query(sql, engine, params=arguments)
#         log.info('successfully connected to db and fetched results'
#                  ' as follows - {0}'.format(output))
#     except SQLAlchemyError as e:
#         status = False
#         output = False
#         log.error('failed to execute query in db with following error'
#                   ' - {0}'.format(e))
#     finally:
#         if engine is not None:
#             engine.close()
#             log.info('successfully disposed engine')
#     return output, status


#def get_data_from_db(engine_url, sql, *arguments):
#    """
#    connect to SQL db and fetch data into dataframe
#    :param engine_url: db connection url
#    :param sql: sql statement
#    :param arguments: parameters in sql as tuple
#    :return: dataframe or boolean status if connection fails
#    """
#    engine = None
#    try:
#        engine = pyodbc.connect(engine_url)
#        status = True
#        output = pd.read_sql_query(sql, engine, params=arguments)
#        log.info('successfully connected to db and fetched results'
#                 ' as follows - {0}'.format(output))
#    except SQLAlchemyError as e:
#        status = False
#        output = False
#        log.error('failed to execute query in db with following error'
#                  ' - {0}'.format(e))
#    finally:
#        if engine is not None:
#            engine.close()
#            log.info('successfully disposed engine')
#    return output, status


def connect_db(db_name):
    """
      function to create connection string to connect to db
      :param db_name: String
      :return: connection string as String
      """
    dbusername = get_db_credentials(db_name)["dbusername"]
    dbpassword = decoder(get_db_credentials(db_name)["dbpassword"])
    jdbc2 = get_connection_details(db_name)["jdbc2"]
    jdbc3 = get_connection_details(db_name)["jdbc3"]
    dbport = get_connection_details(db_name)["dbport"]
    dbname = get_connection_details(db_name)["dbname"]
    dbhostname = get_connection_details(db_name)["dbhost"]
    customjdbc = 'jdbc:oracle:thin:' + '@' + dbhostname + ':' + dbport + '/' + dbname
    cursor_object = ''
    connection_string = ''
    try:
        jar = JAR_FILE_PATH
        jclassname = 'oracle.jdbc.driver.OracleDriver'
        args = '-Djava.class.path=%s' % jar
        JHOME = jpype.getDefaultJVMPath()
        if not jpype.isJVMStarted():
            jpype.startJVM(JHOME, args, '-Doracle.jdbc.timezoneAsRegion=false')
        connection_string = jaydebeapi.connect(jclassname, customjdbc, [dbusername, dbpassword], jar)
        cursor_object = connection_string.cursor()
        log.info('connection successful: {0}, {1}'.format(connection_string, cursor_object))
    except Exception as e:
        log.error('Data error: {}'.format(e))
    return connection_string, cursor_object


def execute_query(query, cursor_object):
    """
       Method to execute given query and retrieve the data from db as dataframe
       :param query: sql query as string
       :param engine: engine as connection string
       :return: result set as data frame
       """
    try:
        con = cursor_object
        time.sleep(5)
        time_counter = 0
        if (con is not None) and (query is not None):
            con.execute(query)
            df_result_set = con.fetchall()
            while (len(df_result_set) == 0) and time_counter < 10:
                pd.DataFrame(con.execute(query).fetchmany(100))
                df_result_set = con.fetchall()
                time_counter = time_counter + 1
                time.sleep(3)
            if (df_result_set is not None) and (len(df_result_set) != 0):
                log.info('successfully connected to db and fetched results'
                         'as follows - {0}'.format(df_result_set))
                return df_result_set
            log.error("Could not fetch records from db"
                      " even after maximum timeout")
            return None
        else:
            log.error("Invalid connection object -"
                      " Either Engine or SQL query is None")
    except Exception as e:
        log.error("Error while establishing connection or"
                  " executing sql query".format(e))


def get_mssql_engine_url(db_name):
    """
    create engine url for mssql database
    :param db_name: mssql db connection name
    :return: engine
    """
    dbusername = get_db_credentials(db_name)["dbusername"]
    dbpassword = utils_encrypter.decoder(get_db_credentials(db_name)["dbpassword"])
    host = get_connection_details(db_name)["dbhost"]
    database = get_connection_details(db_name)["dbname"]
    try:
        engine = pymssql.connect(host, dbusername, dbpassword, database, tds_version='7.0')
        log.info('Successfully created SQL engine url {0}'.format(engine))
    except Exception as e:
        engine = False
        log.error('Failed to connect to db due to error - {0}'.format(e))
    return engine


def get_data_from_db(engine, sql):
    """
    connect to SQL db and fetch data into dataframe
    :param engine_url: db connection url
    :param sql: sql statement
    :param arguments: parameters in sql as tuple
    :return: dataframe or boolean status if connection fails
    """
    try:
        engine = engine.cursor()
        status = True
        engine.execute(sql)
        output = engine.fetchall()
        log.info('successfully connected to db and fetched results'
                 ' as follows - {0}'.format(output))
    except SQLAlchemyError as e:
        status = False
        output = False
        log.error('failed to execute query in db with following error'
                  ' - {0}'.format(e))
    finally:
        if engine is not None:
            engine.close()
            log.info('successfully disposed engine')
    return output, status


def close_oracle_db_connection(connection_string, cursor_object):
    """
       close the oracle db connection
       :param engine_url: db connection url
       :return: dataframe or boolean status if connection close
    """
    try:
        cursor_object.close()
        connection_string.close()
        status = True
        log.info('successfully closed db connection')
    except Exception as e:
        status = False
        log.error('failed to close the engine connection due to following error '
                  ' - {0}'.format(e))
    return status

# if __name__ == '__main__':
#     engine = get_mssql_engine_url("SVOC")
#     output, status = get_data_from_db(engine, "SELECT [EmailAddress] from AccountDetailEmail where accountId = '24690555'")
#     print(output)

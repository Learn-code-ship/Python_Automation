from datetime import datetime, timedelta, date
from logger.custom_logger import custom_logger

log = custom_logger()


def format_date(date, current_format, expected_format):
    """
    function to format date in a specified format
    :param date: date
    :param current_format: input date format
    :param expected_format: expected output date format
    :return: string date
    :return: None in case of null date/date formats
    """
    try:
        if (date is not None) \
                and (current_format is not None) \
                and (expected_format is not None) \
                and (len(str(date)) != 0) \
                and (len(str(current_format)) != 0) \
                and (len(str(expected_format)) != 0):
            date = datetime.strptime(str(date), current_format)
            date = datetime.strftime(date, expected_format)
            log.info("Formatted date is {0}: ".format(date))
            return date
        else:
            log.info("Either input date or date format is null -"
                     " Enter valid date/date formats")
            return None
    except Exception as e:
        log.info("Exception {0} while formatting date -"
                 " Check expected and"
                 " input date formats are correct ".format(e))
        return None


def get_next_weekday(starting_day, weekday):
    """
    Method to get next weekday from today's date. example to get next thursday/next wednesday
    :param starting_day: starting date
    :param weekday: 0 = Monday, 1=Tuesday, 2=Wednesday...
    :return: date of next weekday
    """
    next_weekday = None
    try:
        days_ahead = weekday - starting_day.weekday()
        if days_ahead <= 0:  # Target day already happened this week
            days_ahead += 7
        next_weekday = starting_day + timedelta(days_ahead)
        log.info("Formatted date is {0}: ".format(next_weekday))
    except Exception as e:
        log.error('failed to get weekday date with following '
                  'error - {0}'.format(e))
        next_weekday = None
    return next_weekday

def get_past_weekday(weekday):
    """
    Method to get previous weekday from today's date. example to get previous thursday/ wednesday
    :param weekday: starting date
    :param weekday: 0 = Monday, 1=Tuesday, 2=Wednesday...
    :return: date of next weekday in yyyy-mm-dd
    """
    current_dayofweek = datetime.now().weekday()  # Today
    if weekday < current_dayofweek:
        # target is in the current week
        endDate = datetime.now() - timedelta(current_dayofweek - weekday)
    else:
        # target is in the previous week
        endDate = datetime.now() - timedelta(weeks=1) + timedelta(
            weekday - current_dayofweek)
    print(endDate.date())
    return endDate.date()
def get_date():
    """
    Method that gets the current date
    :return: date
    """
    # gets todays date in format (month, day, year)
    today = datetime.today()
    today_date = today.strftime("%B %Y")
    # puts month and year into seperate variables
    month = today_date.split()[0]
    year = today_date.split()[1]
    # corrects length of month and year
    mon = month[0:3:1]
    ye = year[2::]
    # adds correct syntax to be passed to sql
    date = '%' + mon.upper() + "-" + ye
    return date
def get_last_month():
    """
    Method to get last month
    :return: month, year of last month
    """
    # gets last month
    today = datetime.today()
    first = today.replace(day=1)
    last_month = first - timedelta(days=1)
    last_mon = last_month.strftime("%B %Y")
    # puts month and year into seperate variables
    month = last_mon.split()[0]
    year = last_mon.split()[1]
    # corrects length of month and year
    mon = month[0:3:1]
    ye = year[2::]
    # adds correct syntax to be passed to sql
    date = '%' + mon.upper() + "-" + ye
    return date


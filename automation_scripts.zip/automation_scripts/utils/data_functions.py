import pandas as pd
import json

from logger.custom_logger import custom_logger

log = custom_logger()


def df_to_list(df_data, db_name):
    """
    :param df_data: data frame
    :param db_name: string variable
    :return: list of string
    """
    if not df_data.empty and str(db_name) is not None:
        if str(db_name).lower() != "dom":
            lst_result = [''.join(x) for x in df_data.values.tolist()]
        else:
            lst_result = df_data.values.tolist()
    else:
        lst_result = False
        log.info('failed to transform data frame to list due to '
                 'null input value for db name or data frame')
    return lst_result


def convert_list_to_df(*lst):
    """
    function to convert list to dataframe
    :@param: lst - multiple list
    :return: dataframe with each list in separate column
    """
    df_result = None
    if len(lst) != 0:
        df_result = pd.DataFrame()
        for ilist in range(0, len(lst)):
            df_result = pd.DataFrame(
                {'lst1Title' + str(
                    ilist): lst[ilist]}).append(df_result)
    else:
        log.info("input list has no values"
                 " - can not convert to data frame")
    return df_result


def read_json_to_df(file):
    """
    Read json file and return an array of json as data frame
    :param file: File name
    :return: data frame
    """
    try:
        with open(file, "r") as json_file:
            test_data = json.load(json_file)
        return pd.DataFrame(test_data)
    except FileNotFoundError as e:
        log.error("Exception {0} occurred while reading json as data frame".format(e))
        return None

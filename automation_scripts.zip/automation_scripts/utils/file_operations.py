import configparser
import os
from os.path import dirname, abspath
from pathlib import Path
from random import randint
import csv

import pandas as pd
from logger.custom_logger import custom_logger

log = custom_logger()


def load_db_config_file(section, key):
    """
    function to read values from dbconfig file
    :param section: string
    :param key: string
    :return: string value correcsponding to section header and key
    """
    try:
        user_dir = dirname(dirname(abspath(__file__)))
        config = configparser.RawConfigParser()
        config.read(user_dir + "/pytest.ini")
        return config.get(section, key)
    except IOError as e:
        log.error("IO error while reading from properties file".format(e))
        return None


def create_folder(directory_path):
    """
    function to create folder
    :param directory_path: path of the directory including directory name
    :return:
    """
    try:
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
    except OSError:
        log.error('Error: Creating directory. ' + directory_path)


def generate_random_with_n_digits(n):
    """
    function to generate random number of specified length
    :param n: length of random number
    :return: random number with n length
    """
    try:
        if len(str(n)) != 0:
            range_start = 10 ** (n - 1)
            range_end = (10 ** n) - 1
            return randint(range_start, range_end)
        log.info("invalid lenght to generate random number -"
                 " provide valid length")
    except Exception as e:
        log.info("Exception {0} while generating random number: ".format(e))


def is_folder_exists(directory_path):
    try:
        return os.path.exists(directory_path)
    except Exception as e:
        log.error("Exception while checking directory".format(e))


'''def read_csv(directory_path, file_name):
   """
    function to read data from csv file under specified folder
    :param directory_path: string
    :param file_name: string
    :return: csv data as dataframe
    """
    if is_folder_exists:
        try:
            return pd.read_csv(os.path.join(directory_path,
                                            file_name + ".txt"),
                               sep=',', dtype=str)
        except IOError as e:
            log.error("IO error while writing to csv".format(e))
    else:
        log.error("Specified directory does not exists")'''


def passed_tests_write_in_csv(output_file_path,  my_dict, test_case, outcome):
    """
    method to write order details in the output.csv file
    :return:status
    """
    status = False
    outputfile_path = output_file_path
    file_name = Path(output_file_path).parts[-1]
    data = {"TESTCASE": "", "STATUS": "", "MODULE": "", **my_dict}
    data['TESTCASE'] = str(test_case)
    data['STATUS'] = outcome
    csv_columns = data.keys()
    try:
        if outcome == 'passed':
            if os.stat(outputfile_path).st_size == 0:
                with open(outputfile_path, 'w', newline='') as outputfile_path:
                    writer = csv.DictWriter(outputfile_path, fieldnames=csv_columns)
                    writer.writeheader()
                    writer.writerow(data)
                    log.info("All the order details written in the {} file".format(file_name))
            else:
                with open(outputfile_path, 'a+', newline='') as outputfile_path:
                    writer = csv.DictWriter(outputfile_path, fieldnames=csv_columns)
                    writer.writerow(data)
                    log.info(" all the values are appended into {} file".format(file_name))
            status = True
            outputfile_path.close()
        else:
            log.error("testcase-{0} is failed , Hence did not write into {1} csv file".format(test_case,file_name))
    except Exception as e:
        log.error("Exception occurred {0} while writing the details in the {1} file".format(e, file_name))


def failed_tests_write_in_csv(test_case, outcome, failed_file_path, errormsg):
    """
    method to write the failure reasons into the csv file
    :return:status
    """
    status = False
    file_name = Path(failed_file_path).parts[-1]
    data = {"TESTCASE": "", "STATUS": "", "ERROR": "" }
    data['TESTCASE'] = str(test_case)
    data['STATUS'] = outcome
    data['ERROR'] = errormsg
    csv_columns = data.keys()
    try:
        if outcome == 'failed':
            if os.stat(failed_file_path).st_size == 0:
                with open(failed_file_path, 'w', newline='') as failed_file_path:
                    writer = csv.DictWriter(failed_file_path, fieldnames=csv_columns)
                    writer.writeheader()
                    writer.writerow(data)
                    log.info("Failed testcase with error message written in the {} file".format(file_name))
            else:
                with open(failed_file_path, 'a+', newline='') as failed_file_path:
                    writer = csv.DictWriter(failed_file_path, fieldnames=csv_columns)
                    writer.writerow(data)
                    log.info("Failed testcase with error messages are appended into {} file".format(file_name))
            status = True
            failed_file_path.close()
    except Exception as e:
        log.error("Exception occurred {0} while writing the error messages in the {1} file".format(e, file_name))
import datetime
import time

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from configuration import sehelper_constants
from conftest import add_screenshot, log


class SeHelperPage(object):
    def __init__(self, driver):
        self.driver = driver
        self.timeout = sehelper_constants.MAX_WAIT

    def find_element(self, *locator):
        """
        Method to locate the web element
        :param locator: locator - tuple
        :return: web element
        """
        try:
            return self.driver.find_element(*locator)
        except Exception as e:
            log.error("Exception {0} while finding element".format(e))
            return None

    def find_elements(self, *locator):
        """
        Method to locate the web elements
        :param locator: locator - tuple
        :return: web elements - list
        """
        try:
            return self.driver.find_elements(*locator)
        except Exception as e:
            log.error("Exception {0} while finding elements".format(e))
            return None

    def open_url(self, url):
        """
        Method to launch URL
        :param url: String - url
        :return:
        """
        try:
            self.driver.get(url)
        except Exception as e:
            log.error("Exception {0} while launching url".format(e))

    def click(self, *locator):
        """
        Method to click on a element
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            # element = self.element_visible(locator)
            element = WebDriverWait(self.driver, 20).until(
                ec.visibility_of_element_located((locator)))
            text = self.get_inner_text(element).split('\n')[0]
            if not text:
                text = element.get_attribute('title')
            element.click()
            add_screenshot(self.driver, 'screenshot_{0}'.format(text))
            # adding step to take screenshot before element click
            # add_screenshot(self.driver, 'screenshot_{0}'.format(locator[1]))
            # element.click()
            result = True
            log.info(
                "Web element {0} : {1} successfully clicked".format(
                    locator[0], locator[1]))
        except NoSuchElementException as ex:
            log.error("Failed to click Web element {0} : {1},"
                      " displayed with error {2}".format(locator[0],
                                                         locator[1],
                                                         ex.msg))
        return result

    def click_element(self, element):
        """
        Method to click on a element
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            text = self.get_inner_text(element).split('\n')[0]
            if not text:
                text = element.get_attribute('title')
            element.click()
            add_screenshot(self.driver, 'screenshot_{0}'.format(text))
            result = True
            log.info(
                "Web element {0}  successfully clicked".format(
                    element))
        except NoSuchElementException as ex:
            log.error("Failed to click Web element {0} : "
                      "displayed with error {1}".format(element, ex.msg))
        return result

    def enter(self, data, *locator):
        """
        Method to enter data
        :param data: input data
        :param locator: locator - tuple
        :return: status - boolean
        """
        try:
            element = self.element_visible(locator)
            element.send_keys(Keys.CONTROL + 'a', Keys.BACKSPACE)
            time.sleep(3)
            element.send_keys(str(data))
            log.info("Web element {0} : {1} was located "
                     "and entered with value : {2}".
                     format(locator[0], locator[1], str(data)))
            status = True
            time.sleep(2)
        except NoSuchElementException as ex:
            log.error("Failed to enter value {0} for elements {1} : {2},"
                      "displayed  error message {3}".format(str(data),
                                                            locator[0],
                                                            locator[1],
                                                            ex.msg))
            status = False
        return status

    """def enter_to_element(self, data, element):

       Method to enter data
        :param element:
        :param data: input data
        :param locator: locator - tuple
        :return: status - boolean

        try:
            element.clear()
            time.sleep(3)
            element.send_keys(str(data))
          #  log.info("Web element was located "
                       #   "and entered with value : {0}".format(str[data]))
            status = True
        except NoSuchElementException as ex:
            log.error("Failed to enter value {0} for elements {1},"
                           "displayed  error message {2}".format(str[data], element, ex.msg))
            status = False
        return status"""

    def fetch_attribute_value(self, attribute_name, *locator):
        """
        Method to fetch attribute value of an element
        :param attribute_name: attribute name
        :param locator: locator - tuple
        :return: web element
        """
        try:
            element = self.element_visible(locator)
            return element.get_attribute(attribute_name)
        except NoSuchElementException as ex:
            log.error("No such element exception {0} was displayed during"
                      "element {1} : {2} location".format(ex.msg,
                                                          locator[0],
                                                          locator[1]))
            return None

    def keyboard_input(self, data, *locator):
        """
        Method to input data
        :param data: input data
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            element = self.find_element(locator)
            element.send_keys(str(data))
            result = True
        except Exception as e:
            log.error("Exception {0} while entering input data url".format(e))
        return result

    def mouse_hover(self, *locator):
        """
        Method to perform mouse hover action
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            element = self.find_element(*locator)
            hover = ActionChains(self.driver).move_to_element(element)
            hover.perform()
            result = True
        except Exception as e:
            log.error("Exception {0} while performing mouse hover".format(e))
        return result

    def scroll_to_element(self, *locator):
        """
        Method to perform scroll action
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            element = self.find_element(*locator)
            self.driver.execute_script("arguments[0].scrollIntoView();", element)
            time.sleep(2)
        except Exception as e:
            log.error("Exception {0} while scrolling".format(e))
        return result

    def scroll_up_element(self, *locator):
        """
        Method to perform scroll action
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            element = self.find_element(*locator)
            self.driver.execute_script("window.scrollTo(0,-document.body.scrollHeight);", element)
            time.sleep(2)
        except Exception as e:
            log.error("Exception {0} while scrolling".format(e))
        return result


    def scroll_to_web_element(self, element):
        """
        Method to perform scroll action using element
        :param element: webelement - tuple
        :return: result - boolean
        """
        result = False
        try:
            self.driver.execute_script("arguments[0].scrollIntoView();", element)
            time.sleep(2)
        except Exception as e:
            log.error("Exception {0} while scrolling".format(e))
        return result

    def execute_javascript(self, script):
        self.driver.execute_script(script)
        log.info("Javascript executor was called with script {} for "
                 "locator".format(script))

    def click_using_javascript(self, *locator):
        try:
            element = WebDriverWait(self.driver, 20).until(
                ec.element_to_be_clickable((locator)))
            self.driver.execute_script("arguments[0].click();", element)
            status = True
        except Exception as e:
            log.error("Exception {0} while clicking element".format(e))
            status = False
        return status

    def wait_for_element_to_disappear(self, locator):
        """
        Method to wait until element is invisible
        :param locator: locator
        :return: result - boolean
        """
        result = False
        try:
            WebDriverWait(self.driver, sehelper_constants.MAX_WAIT * 2).until(ec.invisibility_of_element(locator))
            result = True
        except Exception as e:
            log.error("Exception {0} while waiting for element to disappear".format(e))
        return result

    def wait_for_element(self, locator):
        """
        Method to wait for an element using locator
        :param locator: locator
        :return: element
        """
        try:
            wait = WebDriverWait(self.driver, sehelper_constants.MAX_WAIT * 2)
            element = wait.until(ec.visibility_of_element_located(locator))
            return element
        except NoSuchElementException as e:
            log.error("Exception - No such element {0}".format(e))
            return None

    def wait_for_webelement(self, web_element):
        """
        Method to wait for an element(web element)
        :param web_element: web element
        :return: element
        """
        try:
            wait = WebDriverWait(self.driver, sehelper_constants.MAX_WAIT * 2)
            element = wait.until(ec.visibility_of(web_element))
            return element
        except NoSuchElementException as e:
            log.info("Exception - No such element {0}".format(e))
            return None

    def is_element_visible(self, locator):
        """
        Method to verify if element is visible
        :param locator: locator
        :return: boolean
        """
        try:
            element = WebDriverWait(self.driver, sehelper_constants.ELEMENT_WAIT).until(
                ec.visibility_of_element_located(locator))
            # self.driver.execute_script("arguments[0].scrollIntoView();", element)
            return True
        except Exception as e:
            log.info("Exception - No such element {0}".format(e))
            return False

    def is_elements_visible(self, locator):
        """
        Method to verify if elements is visible
        :param locator: locator
        :return: boolean
        """
        result = False
        try:
            WebDriverWait(self.driver, sehelper_constants.ELEMENT_WAIT).until(
                ec.visibility_of_all_elements_located(locator))
            result = True
        except Exception as e:
            log.error("Exception - No such element {0}".format(e))
        return result

    def switch_to_window(self, window):
        self.driver.switch_to.window(window)
        log.info("Switched to %s" % str(window))

    def switch_to_window_by_number(self, window_number):
        self.driver.switch_to.window(self.driver.window_handles[window_number])
        log.info("Switched to %s window" % str(window_number))

    def switch_to_alert(self):
        a = self.driver.switch_to.alert
        a.accept()

    def switch_to_child_window(self):
        current_window = self.get_current_window()
        handles = self.driver.window_handles
        for x in handles:
            if x != current_window:
                self.driver.switch_to.window(x)
                log.info("Switched to %s window" % str(x))

    def switch_to_frame(self, *locator):
        element = self.find_element(*locator)
        self.driver.switch_to.frame(element)
        log.info("Switched to frame")

    def open_new_tab_close_current_tab(self):
        self.driver.execute_script("window.open('');")
        log.info("Opened new window")
        time.sleep(3)
        self.driver.switch_to.window(self.driver.window_handles[0])
        self.driver.close()
        time.sleep(3)
        self.driver.switch_to.window(self.driver.window_handles[0])

    def open_and_switch_to_new_tab(self):
        self.driver.execute_script("window.open('');")
        log.info("Opened new window")
        time.sleep(3)
        self.driver.switch_to.window(self.driver.window_handles[1])

    def open_link_in_new_window(self, *locator):
        """
        Method to open link in new window
        :param locator: locator
        :return: result - boolean
        """
        try:
            element = WebDriverWait(self.driver, 20).until(ec.visibility_of_element_located(locator))
            element.send_keys(Keys.CONTROL + Keys.RETURN)
            time.sleep(3)
            log.info("Link opened in new window")
            return True
        except Exception as e:
            log.error("Exception {0} while opening link in new window".format(e))
            return False

    def close_current_tab(self):
        self.driver.close()
        time.sleep(3)
        self.driver.switch_to.window(self.driver.window_handles[0])

    def get_title(self):
        return self.driver.title

    def get_current_url(self):
        return self.driver.current_url

    def get_current_driver(self):
        return self.driver

    def get_attribute_value(self, attribute_name, *locator):
        element = self.find_element(*locator)
        return element.get_attribute(attribute_name)

    def get_attribute_of_element(self, attribute_name, element):
        """
        Method to get attribute of an web element
        :param attribute_name: atrib name
        :param element: web element
        :return:
        """
        try:
            element.get_attribute(attribute_name)
            return True
        except Exception as e:
            log.error("Exception {0} while get attribute".format(e))
            return False

    def get_text(self, *locator):
        try:
            element = self.element_visible(locator)
            if element is not None:
                value = element.text
                log.info('element text is {0}'.format(value))
                return value.strip()
            else:
                return None
        except NoSuchElementException as ex:
            log.error("No such element exception {0} was displayed during"
                      " element {1} : {2} location ".format(ex.msg,
                                                            locator[0],
                                                            locator[1]))

            return None

    def get_window_handles(self):
        return self.driver.window_handles

    def get_current_window(self):
        return self.driver.current_window_handle

    def element_visible(self, locator):
        try:
            element = WebDriverWait(self.driver, sehelper_constants.MAX_WAIT).until(
                ec.visibility_of_element_located(locator))
            self.driver.execute_script("arguments[0].scrollIntoView();",
                                       element)
            log.info("Web element {0} : {1} "
                     "was visible".format(locator[0], locator[1]))
            return element
        except StaleElementReferenceException as ser:
            log.error("Stale element exception {0} was displayed during"
                      " element {1} : {2} location ".format(ser.msg,
                                                            locator[0],
                                                            locator[1]))
        except NoSuchElementException as ex:
            log.error("No such element exception {0} was displayed during"
                      "element {1} : {2} location".format(ex.msg,
                                                          locator[0],
                                                          locator[1]))
        except TimeoutException as et:
            log.error("Script timed out with message {0} during "
                      "element {1} : {2} location".format(et.msg,
                                                          locator[0],
                                                          locator[1]))

    # return True if element is visible within 2 seconds, otherwise False
    def elements_visible(self, locator):
        try:
            WebDriverWait(self.driver, sehelper_constants.MAX_WAIT).until(
                ec.visibility_of_all_elements_located(locator))
            return True
        except TimeoutException:
            return False

    def is_element_visible_for_custom_time(self, locator, time):
        """
        method to wait for an element of user specified time
        :param locator:
        :param time: in seconds
        :return:
        """
        try:
            WebDriverWait(self.driver, time).until(
                ec.visibility_of_element_located(locator))
            return True
        except Exception as e:
            log.error("Exception {0}".format(e))
            return False

    def custom_time_wait(self, time):
        """
        method to wait for an element of user specified time
        :param locator:
        :param time: in seconds
        :return:
        """
        try:
            WebDriverWait(self.driver, time)
            return True
        except Exception as e:
            log.error("Exception {0}".format(e))
            return False

    def isdisplayed(self, *locator):
        """
        Method to check if element displayed
        :param locator: locator
        :return: boolean
        """
        try:
            ele = self.driver.find_element(*locator)
            ele.is_displayed()
            status = True
        except Exception as e:
            log.error("Exception {0}".format(e))
            status = False
        return status

    def press_enter(self, *locator):
        try:
            self.find_element(*locator).send_keys(Keys.ENTER)
            return True
        except Exception as e:
            log.error("Exception {0} while key press".format(e))
            return False

    def get_inner_text(self, element):
        """
        Method to get text of an element
        :param element:
        :return: element text
        """
        return element.text

    def clear_text(self, *locator):
        """
        Method to clear text
        :return:
        """
        element = None
        try:
            element = self.find_element(*locator).clear()
        except Exception as e:
            log.error("Exception {0} while clearing text".format(e))
        return element

    def get_elements_in_list(self, *locator):
        """
        method to get list of elements from ul
        :param locator:
        :return: list of elements
        """
        elements_list = None
        try:
            element_ul = self.find_element(*locator)
            elements_list = element_ul.find_elements_by_tag_name("li")
        except Exception as e:
            log.error("Exception {0} while clearing text".format(e))
        return elements_list

    def select_by_value(self, value, *locator):
        """
        Method to select value from drop down selector
        :param data: option value to select
        :param locator: locator - tuple
        :return: status - boolean
        """
        try:
            element = self.element_visible(locator)
            select = Select(element)
            select.select_by_value(value)
            log.info("selected dropdown with value : {0}".
                     format(value))
            status = True
        except Exception as ex:
            log.error("Failed to select value {0} for elements {1}"
                      "displayed error message {2}".format(value,
                                                           locator[0],
                                                           ex))
            status = False
        return status

    def select_by_text(self, text, *locator):
        """
        Method to select value from drop down selector using text
        :param data: text value to select
        :param locator: locator - tuple
        :return: status - boolean
        """
        try:
            element = self.find_element(*locator)
            select = Select(element)
            select.select_by_visible_text(text)
            log.info("selected dropdown with value : {0}".
                     format(text))
            status = True
        except Exception as ex:
            log.error("Failed to select value {0} for elements {1}"
                      "displayed error message {2}".format(text,
                                                           locator[0],
                                                           ex))
            status = False
        return status

    def get_selected_value(self, element):
        """
        Method to get the selected value from drop down
        :param element - web element
        :return: value - string value
        """
        try:
            select = Select(element)
            value = select.first_selected_option.get_attribute("value")
        except Exception as ex:
            log.error("Failed to get the selected value for element"
                      "displayed error message : {0}".format(ex))
            value = None
        return value

    def click_hold(self, *locator):
        """
        Method to perform click and hold action
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            element = self.find_element(*locator)
            hold_element = ActionChains(self.driver).click_and_hold(*locator)
            hold_element.perform()
            result = True
        except Exception as e:
            log.error("Exception {0} while performing click and hold".format(e))
        return result

    def zoom_web_page(self, zoom_percentile):
        """
        Method to adjust browser zoom level
        :param zoom_percentile:
        :return:
        """
        result = False
        try:
            self.driver.execute_script("document.body.style.zoom='" + zoom_percentile + "'")
            log.info("browser zoom level set to {}".format(zoom_percentile))
            result = True
            time.sleep(5)
        except Exception as e:
            log.error("Exception {} while setting zoom level".format(e))
        return result

    def isSelected(self, *locator):
        """
        Method to check if checkbox is selected
        :param locator: locator
        :return: boolean
        """
        try:
            status = self.find_element(*locator).is_selected()
        except Exception as e:
            log.error("Exception {0}".format(e))
            status = False
        return status

    def wait_for_page_load_complete(self):
        # Selenium by default tries to blocks execution on whole page reload for this
        page_state = self.driver.execute_script('return document.readyState;')
        return page_state == 'complete'

    def select_date_from_calender(self, date, *locator):
        status = False
        try:
            elements = self.find_elements(*locator)
            for dates in elements:
                value = str(dates.get_attribute("innerText"))
                if dates.is_enabled() and dates.is_displayed() and value == date:
                    dates.click()
                    status = True
                    log.info("Selected date as: {0}".format(value))
        except Exception as e:
            log.error("Exception {0} occurred while selecting date".format(e))
            status = False
        return status

    def set_text(self, data, element):
        """
        Method to enter data and press enter
        :param data: input data
        :param element: web element
        :return: status - boolean
        """
        try:
            # element.clear()
            element.send_keys(str(data))
            status = True
        except NoSuchElementException as ex:
            log.error("Failed to enter value {0} for elements {1} "
                      "displayed  error message {2}".format(str(data), element, ex.msg))
            status = False
        return status

    def ele_displayed(self, element):
        """
        Method to check if element displayed
        :param element: locator
        :return: boolean
        """
        try:
            element.is_displayed()
            return True
        except Exception as e:
            log.error("Exception {0}".format(e))
            return False

    def page_refresh(self):
        """
        Method to refresh page
        :return:
        """
        self.driver.get(self.get_current_url())

    def select_by_index(self, index, *locator):
        """
        Method to select value from drop down selector using text
        :param index: text value to select
        :param locator: locator - tuple
        :return: status - boolean
        """
        try:
            element = self.find_element(*locator)
            select = Select(element)
            select.select_by_index(index)
            log.info("selected dropdown with value : {0}".
                     format(index))
            status = True
        except Exception as ex:
            log.error("Failed to select value {0} for elements {1}"
                      "displayed error message {2}".format(index,
                                                           locator[0],
                                                           ex))
            status = False
        return status

    def wait_and_find_ele_by_xpath(self, xpath):
        """
        Method to wait for an element using locator
        :param xpath: xpath as string
        :return: element
        """
        try:
            wait = WebDriverWait(self.driver, sehelper_constants.MAX_WAIT * 2)
            element = wait.until(ec.visibility_of_element_located((By.XPATH, xpath)))
            return element
        except Exception as e:
            log.error("Exception - No such element {0}".format(e))
            return None

    def click_enter(self, data, *locator):
        """
        Method to input data
        :param data: input data
        :param locator: locator - tuple
        :return: result - boolean
        """
        result = False
        try:
            self.click_using_javascript(*locator)
            elem = self.driver.find_element(*locator)
            time.sleep(2)
            elem.send_keys(u'\ue009' + u'\ue003')
            time.sleep(1)
            elem.send_keys(str(data))
            elem.send_keys(Keys.ENTER)
            time.sleep(1)
            result = True
        except Exception as e:
            log.error("Exception {0} while entering input data url".format(e))
        return result

    def is_checked(self, item_id):
        """
            Method to check javascript code status for check or uncheck
            :param data: item id
            :return: result - boolean
        """
        checked = self.driver.execute_script(
            f"return document.getElementById('{item_id}').checked"
        )
        return checked

    def page_up(self, *locator):
        """
            Method to move page up
            :param locator: locator - tuple
            :return: result - boolean
        """
        try:
            self.find_element(*locator).send_keys(Keys.PAGE_UP)
            return True
        except Exception as e:
            log.error("Exception {0} while page up".format(e))
            return False


    def select_by_text_web_element(self, text, web_element):
        """
        Method to select value from drop down selector using text
        :param data: text value to select
        :param locator: locator - tuple
        :return: status - boolean
        """
        try:
            wait = WebDriverWait(self.driver, sehelper_constants.MAX_WAIT * 2)
            element = wait.until(ec.visibility_of(web_element))
            select = Select(element)
            select.select_by_visible_text(text)
            log.info("selected dropdown with value : {0}".
                     format(text))
            status = True
        except Exception as ex:
            log.error("Failed to select value {0} for elements {1}"
                      "displayed error message {2}".format(text,
                                                           web_element[0],
                                                           ex))
            status = False
        return status


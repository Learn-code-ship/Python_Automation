import json
from conftest import log

import allure
import requests



class WalletApi():
    """
    Class consists of get,post,patch,del api methods for objects and methods
    """

    @allure.step("Get wallet id by identities")
    def get_walletid_by_identity(self, URL, identity, type):
        """
        This API method allows the calling application to retrieve a Wallet's details for a specific identity
        :param: identity
        :return: results
        """
        if type == "GEAC":
            identity = identity[:-1]

        status = False
        response_results = ''
        try:
            response = requests.get(f"{URL}/wallet/identity?name={identity}")
            response_code = response.status_code
            if response_code == 200:
                log.info("Get wallet id by identity response code is {}".format(response_code))
                response_results = json.dumps(response.json())
                loaddata = json.loads(response_results)
                status = True
            else:
                log.error("Get wallet id by identity response code is '{}'".format(response_code))
        except Exception as e:
            log.error("Exception occured {} while get method api call for get wallet id by identity ".format(e))
            status &= False
        return status, response_results

    @allure.step("Get wallet id by identities")
    def get_wallet_by_walletid(self, URL, walletid):
        """
        This API method allows the calling application to retrieve a Wallet's details by Id.
        :param: identity
        :return: results
        """
        status = False
        response_results = ' '
        try:
            response = requests.get(f"{URL}/wallet/{walletid}")
            response_code = response.status_code
            if response_code == 200:
                log.info("Get wallet by wallet id response code is {}".format(response_code))
                response_results = json.dumps(response.json())
                loaddata = json.loads(response_results)
                status = True
            else:
                log.error("Get wallet by wallet id response code is '{}'".format(response_code))
        except Exception as e:
            log.error("Exception occured {} while get method api call for get wallet by walletid ".format(e))
            status &= False
        return status, response_results

    @allure.description("Validate consumer wallets match before and after seperation/merge")
    def validate_ee_consumers_wallet(self, old_consumers_details, new_consumers_details):
        """
        Method to Validate consumer wallets match before and after seperation/merge
        :return: status - Boolean True or False
        """
        status = True
        try:
            consumers_data = set(obj1["consumer_wallet_id"] for obj1 in old_consumers_details) & set(
                obj2["consumer_wallet_id"] for obj2 in new_consumers_details)
            if len(consumers_data) != 2:
                log.error(f"consumer wallet don't match before sepration/merge and after seperation/merge,"
                          f"this consumer wallet is present {consumers_data}")
                status = False
            else:
                cw = 2
                log.info(f"consumer wallets matches before sepration/merge and after seperation/merge, consumer wallets ID's are {consumers_data}")
                status = True
        except Exception as e:
            log.error("Exception {} occurred while validating consumer wallet match".format(e))
            status &= False
        return status, cw

    @allure.description("Validate consumer wallets match before and after seperation/merge")
    def validate_consumer_wallet_identity_status(self, card, api_status, consumer_walletid):
        """
        Method to Validate consumer wallets identity value status
        :return: status - Boolean True or False
        """
        status = True
        try:
            if api_status == 'ACTIVE':
                log.info(f"consumer wallet with walletid - {consumer_walletid} having geac card-{card} is {api_status}")
            else:
                log.info(f"consumer wallet with walletid - {consumer_walletid} having geac card-{card} is {api_status}")
                status = True
        except Exception as e:
            log.error("Exception {} occurred while validating consumer wallets identity status".format(e))
            status &= False
        return status








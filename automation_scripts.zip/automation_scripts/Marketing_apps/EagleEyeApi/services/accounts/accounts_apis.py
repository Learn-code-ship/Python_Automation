import json
from conftest import log

import allure
import requests
from Marketing_apps.EagleEyeApi.resources.constants import QA_URL


class AccountsApi():
    """
    Class consists of get,post,patch,del api methods for objects and methods
    """
    @allure.step("Get accounts by wallet id")
    def get_accounts_by_wallet_id(self, URL, walletId):
        status = False
        response_results = ''
        try:
            response = requests.get(f"{URL}/wallet/{walletId}/accounts")
            response_code = response.status_code
            if response_code == 200:
                log.info("Get accounts by wallet id response code is {}".format(response_code))
                response_results = json.dumps(response.json())
                loaddata = json.loads(response_results)
                status = True
            else:
                log.error("Get accounts by wallet id response code is '{}'".format(response_code))
        except Exception as e:
            log.error("Exception occured {} while get method api call for get accounts by walletid ".format(e))
            status &= False
        return status, response_results

    @allure.step("Validate accounts api get by wallet id")
    def validate_accounts_by_wallet_id(self, consumer_walletid, status_val, clientType, state, campaignId):
        """
        This method is to validate the retrieved account list by wallet id
        :param: consumer_walletid
        :param: status_val - which is ACTIVE, STOLEN, INACTIVE etc
        :param: clientType - GEPERKS
        :param: state - EARNBURN,EARN,BURN
        :return: results
        """
        status = False
        try:
            if status_val == 'ACTIVE' and campaignId == "1264274":
                log.info("resulted account api response has Loyalty account active for the "
                         "household with walletid- {}".format(consumer_walletid))
                status = True
            else:
                log.error("Loyalty account is not ACTIVE ")
                status = False
            if clientType == 'GEPERKS':
                log.info("resulted account api response has clientype {}".format(clientType))
            if state == 'EARNBURN' or 'EARN' or 'BURN':
                log.info("resulted account api response has state {}".format(state))
                status = True
        except Exception as e:
            log.error("Exception occured {} while validating get accounts by walletid ".format(e))
            status &= False
        return status



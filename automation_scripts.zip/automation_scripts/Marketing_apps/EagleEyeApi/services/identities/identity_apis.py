import json
from conftest import log

import allure
import requests
from Marketing_apps.EagleEyeApi.resources.constants import QA_URL


class IdentityApi():
    """
    Class consists of get,post,patch,del api methods for objects and methods
    """
    @allure.step("Get identities by wallet id")
    def get_identities_by_wallet_id(self, URL, walletId):
        status = False
        response_results = ''
        try:
            response = requests.get(f"{URL}/wallet/{walletId}/identities")
            response_code = response.status_code
            if response_code == 200:
                log.info("Get identities by wallet id response code is {}".format(response_code))
                response_results = json.dumps(response.json())
                loaddata = json.loads(response_results)
                status = True
            else:
                log.error("Get identities by wallet id response code is '{}'".format(response_code))
        except Exception as e:
            log.error("Exception occured {} while get method api call for get identities by walletid ".format(e))
            status &= False
        return status, response_results



    def validate_svoc_db_ee_ui_ee_api(self, result_set_svoc_db, result_set_ui, result_set_api):
        """
        Method to validate svoc ui ee section and api and svoc db (all card section from ui)
        :param: result_set_svoc_db - Values fetched from svoc database (nothing but all card section from svoc ui)
        :param: result_set_ui - Values fetched from svoc Eagle eye section in UI
        :param: result_set_api - Values fetched from the api response
        :return: results
        """
        status = False
        try:
            if len(result_set_svoc_db) == len(result_set_ui) == len(result_set_api):
                log.info("The count of svoc records fetched from db matches with count of cards present in eagle eye and matches with ee response")
            for obj1 in result_set_svoc_db:
                for obj2 in result_set_ui:
                    for obj3 in result_set_api:
                        if obj1 == obj3["value"] == obj2["card_no"]:
                            log.info("the svoc ui card {0} and the  api response {1} card number matches successfully", obj2["value"], obj1["card_no"])
                status = True
        except Exception as e:
             log.error("Exception occured - {} while validating svoc ui vs eagle eye api's geac cards".format(e))
             status = False
        return status

    @allure.description("Validate consumer identity match before and after seperation")
    def validate_ee_consumers_identities_split(self, old_consumers_details, new_consumers_details):
        """
        Method to Validate consumer identity match before and after seperation
        :param: process - merge , split
        :return: status - Boolean True or False
        """
        status = True
        matched_ids = set()
        try:
             for old in old_consumers_details:
                for new in new_consumers_details:
                    if old["consumer_wallet_id"] == new["consumer_wallet_id"]:
                            matched_ids.add(old["consumer_wallet_id"])
                            if old["consumer_identity_id"] == new["consumer_identity_id"]:
                                log.info(f"This consumer has his old hh_num with consumer wallet- {old['consumer_wallet_id']} and wallet with Geac card info. along with all matches")
                            else:
                                log.info("This consumer wallet got his new hh_num with consumer wallet- {old['consumer_wallet_id']} with new Geac card info")
                            break
                    elif old["consumer_wallet_id"] in matched_ids:
                        log.info(f"{old['consumer_wallet_id']} identity already matched")
                    else:
                        log.info(f"{old['consumer_wallet_id']} don't match may be this new identity is assigned, or consumer identity check failed")
             status = True
        except Exception as e:
            log.error("Exception {} occurred while validating consumer identity match split process".format(e))
            status &= False
        return status

    @allure.description("Validate consumer identity match before and after merge")
    def validate_ee_consumers_identities_merge(self, old_consumers_details, new_consumers_details):
        """
        Method to Validate consumer identity match before and after merge
        :param: old_consumers_details, new_consumers_details
        :return: status - Boolean True or False
        """
        status = True
        matched_ids = set()
        try:
            for old in old_consumers_details:
                for new in new_consumers_details:
                    if old["consumer_wallet_id"] == new["consumer_wallet_id"]:
                        matched_ids.add(old["consumer_wallet_id"])
                        if old["consumer_identity_id"] == new["consumer_identity_id"]:
                            log.info(f"All the consumer validation before and after merge matches with {old['consumer_wallet_id']}")
                        else:
                            log.info(f"All the consumer_identity_id validation before and after merge don't match {old['consumer_wallet_id']}")
                        break
                    elif old["consumer_wallet_id"] in matched_ids:
                        log.info(f"{old['consumer_wallet_id']} identity already matched")
                    else:
                        log.info(f"{old['consumer_wallet_id']} don't match hence consumer identity check failed")
            status = True
        except Exception as e:
            log.error("Exception {} occurred while validating consumer identity match merge process".format(e))
            status &= False
        return status


    @allure.description("Validate consumer parent wallet and identity match before and after seperation")
    def validate_ee_parent_wallet_identity_split(self, old_consumers_details, new_consumers_details):
        """
        Method to Validate consumer identity match before and after seperation
        :param: process -  split
        :return: status - Boolean True or False
        """
        status = True
        matched_ids = set()
        try:
            for old in old_consumers_details:
                for new in new_consumers_details:
                    if old["parent_wallet_id"] == new["parent_wallet_id"]:
                        matched_ids.add(old["parent_wallet_id"])
                        if old["parent_identity_id"] == new["parent_identity_id"]:
                            log.info(f"This consumer's parent wallet id-  {old['parent_wallet_id']} and identity id- {old['parent_identity_id']}  matches with has his old hh_num")
                        else:
                            log.info(f"This consumer's parent identity id check doesn't match -- {old['parent_wallet_id']}")
                        break
                    elif old["parent_wallet_id"] in matched_ids:
                          log.info(f"This consumer hh_num with {old['parent_wallet_id']} matched already")
                    else:
                        log.info(f"This consumer got his new hh_num with new parent wallet -- {new['parent_wallet_id']} and parent identity- {new['parent_identity_id']}")
            status = True
        except Exception as e:
            log.error("Exception {} occurred while validating consumer parent wallet and identity match for split".format(e))
            status &= False
        return status

    @allure.description("Validate consumer parent wallet and identity match before and after merge")
    def validate_ee_parent_wallet_identity_merge(self, old_consumers_details, new_consumers_details):
        """
        Method to Validate consumer identity match before and after merge
        :param: process - merge , split
        :return: status - Boolean True or False
        """
        status = True
        matched_ids = set()
        try:
            for old in old_consumers_details:
                for new in new_consumers_details:
                    if old["parent_wallet_id"] == new["parent_wallet_id"]:
                        matched_ids.add(old["parent_wallet_id"])
                        if old["parent_identity_id"] == new["parent_identity_id"]:
                            log.info(f"This consumer hh_num with {old['parent_wallet_id']} matches before/after merge")
                        else:
                            log.info(f"This consumers parent wallet - {old['parent_wallet_id']} ,parent identity don't match ")
                        break
                    elif old["parent_wallet_id"] in matched_ids:
                        log.info(f"This consumer hh_num with {old['parent_wallet_id']} matched already")
                    else:
                        log.info(f"This consumer hh_num with {old['parent_wallet_id']} is not available because merge is done for the user")
            status = True
        except Exception as e:
            log.error("Exception {} occurred while validating consumer parent wallet and identity match merge process".format(e))
            status &= False
        return status




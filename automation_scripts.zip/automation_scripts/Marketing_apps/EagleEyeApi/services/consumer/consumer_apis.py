import json

from Marketing_apps.SVOC.resources.sql_queries import get_segment_check_eme_db
from conftest import log

import allure
import requests
from utils.db_utils import execute_query


class ConsumerApi():
    """
    Class consists of get,post,patch,del api methods for objects and methods
    """
    @allure.step("Get consumer by wallet id")
    def get_consumer_by_wallet_id(self, URL, walletId):
        """
        This API method allows the calling application to retrieve Wallet Consumer details for a specific
        Wallet
        :param: walletId
        :return: results
        """
        response_results = ''
        status = False
        try:
            response = requests.get(f"{URL}/wallet/{walletId}/consumer")
            response_code = response.status_code
            if response_code == 200:
                log.info("Get consumer by wallet id response code is {}".format(response_code))
                response_results = json.dumps(response.json())
                loaddata = json.loads(response_results)
                status = True
            else:
                log.error("Get consumer by wallet id response code is '{}'".format(response_code))
        except Exception as e:
            log.error("Exception occured {} while get method api call for get identities by walletid ".format(e))
            status &= False
        return status, response_results

    @allure.step("Method to get the segment of the user from api")
    def segment_check(self, segments_api_pro, segments_api_member):
        """
        Method is to validate the segment user is myperks/myperks pro
        :param segments_api_pro: myperkspro member
        :param segments_api_member : myperks member
        :return: status and segment
        """
        status = False
        try:
            if segments_api_member == 'myPerks Member':
                log.info("The user is a myPerks customer segment check is successful")
                status = True
                return status, segments_api_member
            elif segments_api_pro == 'myPerks Pro':
                log.info("The user is a myPerksPro customer segment check is successful")
                status = True
                return status, segments_api_pro
            else:
                log.error("The user is neither has myPerks customer nor myPerksPro customer segment check is failed")
        except Exception as e:
            log.error("Exception - {} occured during segment check".format(e))
            status = False
        return status

    @allure.step("Get GEAC card number from DB")
    def get_segment_check_eme_db(self, hh_num, db_engine):
        """
        Method to get segment check from EME database
        :param hh_num:
        :param db_engine:
        :return: segment in string
        """
        db_result = execute_query(get_segment_check_eme_db(hh_num)["segment"], db_engine)
        list_result = db_result[0]
        result = list_result[0]
        log.info("this hh_num - {0} is a - {1} segment customer ".format(hh_num, result))
        return result

    @allure.step("Get get consumer details before merge split ")
    def get_consumer_details_before_merge_split(self, consumer, HH_wallet_id_api, HH_identity_id, consumer_wallet_id_api, consumer_identity_id_api, consumer_id):
        """
        Method to Get get consumer details before merge split
        :param HH_wallet_id_api, HH_identity_id, consumer_wallet_id_api, consumer_identity_id_api:
        :return: segment in string
        """
        status = True
        try:
            consumer["parent_wallet_id"] = HH_wallet_id_api
            consumer["parent_identity_id"] = HH_identity_id
            consumer["consumer_wallet_id"] = consumer_wallet_id_api
            consumer["consumer_identity_id"] = consumer_identity_id_api
            consumer["consumer_id"] = consumer_id
            log.info("Card with wallet details fetched before merge/split operation successfully")
        except Exception as e:
            log.error("Exception - {} occured during segment check".format(e))
            status = False
        return status, consumer

    @allure.description("Validate consumerid match before and after seperation/merge")
    def validate_ee_consumerid(self, old_consumers_details, new_consumers_details):
        """
        Method to Validate consumer id match before and after seperation/merge
        :return: status - Boolean True or False
        """
        status = True
        matched_ids = set()
        try:
            for old in old_consumers_details:
                for new in new_consumers_details:
                    if old["consumer_wallet_id"] == new["consumer_wallet_id"]:
                        matched_ids.add(old["consumer_wallet_id"])
                        if old["consumer_id"] == new["consumer_id"]:
                            log.info(f"This consumer id-{old['consumer_id']} matches before and after merge/split")
                        else:
                            log.error(f"consumer id's don't match - {old['consumer_wallet_id']}")
                        break
                    elif old["consumer_wallet_id"]  in matched_ids:
                        log.info(f"{old['consumer_wallet_id']} already matched")
                    else:
                        log.info(f"{old['consumer_wallet_id']} don't match it might be in merge it will no longer available because it is old/ if it is split, it will have new one  hence consumerid check failed")
                status = True
        except Exception as e:
            log.error("Exception {} occurred while validating consumer id match".format(e))
            status &= False
        return status

    @allure.description("Validate consumerid match before and after seperation/merge")
    def add_consumerid_into_array(self, new_consumers_details, wallet_id, consumer_id):
        """
        Method To add the consumerid into existing array
        :param new_consumers_details:
        :param walletid:
        :param consumer_id:
        :return: new array
        """
        for item in new_consumers_details:
            if item['consumer_wallet_id'] == wallet_id:
                item['consumer_id'] = consumer_id
        return new_consumers_details




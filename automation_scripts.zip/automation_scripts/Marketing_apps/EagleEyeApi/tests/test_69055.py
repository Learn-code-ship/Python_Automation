import os
import time
import allure
import pytest
import output_data_set
from Marketing_apps.EagleEyeApi.services.accounts.accounts_apis import AccountsApi
from Marketing_apps.EagleEyeApi.services.consumer.consumer_apis import ConsumerApi
from Marketing_apps.EagleEyeApi.services.identities.identity_apis import IdentityApi
from Marketing_apps.SVOC.pages.accounts_page import AccountsPage
from Marketing_apps.SVOC.pages.createacc import CreateaccountsPage
from Marketing_apps.SVOC.pages.db_validations import DbValidationPage
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.search_page import SearchPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL, OUTPUT_PATH
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from custom_csv_output_file import OutputresultPage
from parsers import __parser
from utils.db_utils import get_mssql_engine_url, connect_db
from utils.file_operations import create_folder
from Marketing_apps.EagleEyeApi.services.wallet.wallet_apis import WalletApi
from API_helper_methods.API_helper_methods import ApiHelperPage
from Marketing_apps.EagleEyeApi.resources.constants import Fun_APP_URL, Fun_APP_URL

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_acc_ge.json'),
                             ['FIRST_NAME', 'LAST_NAME', 'DOB', 'ADDRESS_1', 'ZIPCODE', 'STATE', 'CITY',
                              'CARD_TYPE', 'GEAC_NUMBER'])
@pytest.mark.Regression
@pytest.mark.consumer
@pytest.mark.parametrize('first_name, last_name, dob, Address_1, zipcode, state, city, card_type, geac_number', params)
@allure.description("Validate the consumer validation having ACTIVE cards with HH and Consumer my perks/myperkspro member")
def test_validate_consumer_creation(init_driver, first_name, last_name, dob, Address_1, zipcode, state, city, card_type,
                          geac_number):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    search_page = SearchPage(driver)
    createacc = CreateaccountsPage(driver)
    acc_page = AccountsPage(driver)
    db_page = DbValidationPage()
    svoc_db = get_mssql_engine_url("SVOC_DB")
    eme_db = connect_db("EME_DB")

    # URL = "https://eagle/CustomerSingleView/Accounts/Accounts/AccountsView?houseHoldNumber=05177732&IndividualId=103510230"
    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    # assert login_page.launch_application(URL)
    assert home_page.verify_home_page(), "Failed to  verify home page in svoc "
    assert createacc.click_on_add_new_account_page(), "Failed to click on add new account page"
    assert createacc.verify_add_member_first_screen_in_account_page(), "Failed to verify add new account page"
    status, fn, ln = createacc.enter_info_new_acc_member_(first_name, last_name, dob, Address_1, zipcode, state, city)
    assert createacc.click_next_button(), "Failed to click on the next button"
    assert createacc.verify_add_member_second_screen_account_page(), "Failed to verify add new account page 2"
    assert createacc.validate_individual_name(fn, ln), "Failed to validate individual name"
    assert createacc.select_card_type(card_type), "Failed to select card type"
    assert createacc.click_issue_card_button(), "Failed to click on issue card button"
    assert createacc.click_on_generate_geac_button(), "Failed to click on generate geac button"
    assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
    assert createacc.click_submit_button_new_card(), "Failed to click on issue new card submit button"
    assert createacc.verify_add_member_second_indvidual_account_popup_screen(), "Failed to verify text screen"
    assert createacc.click_no_button(), "Failed to click No button"
    status, geac_no = createacc.copy_geac_number_from_main_svoc_screen()
    assert search_page.click_on_account(), "Failed to click on account"
    assert createacc.click_reset_button(), "Failed to click on reset button"
    assert acc_page.click_on_all_cards_drop_down(), "Failed to click on the all cards drop down section"
    status, hh_num = acc_page.extract_hh_num_from_svoc_ui()

    wallet = WalletApi()
    identity = IdentityApi()
    api_helper_methods = ApiHelperPage()
    consumer = ConsumerApi()
    accounts = AccountsApi()
    consumer_details_by_geac = []
    consumer_details_by_wallet = []

    status, geac_card_svoc_db = db_page.get_geac_cards_from_db(hh_num, svoc_db)
    status, HH_identity_response_results = wallet.get_walletid_by_identity(Fun_APP_URL, hh_num, "HOUSEHOLD")
    status, HH_wallet_id_api = api_helper_methods.extract_value_by_key(HH_identity_response_results, key="walletId")
    status, HH_identity_id = api_helper_methods.extract_value_by_key(HH_identity_response_results, key="identityId")
    assert HH_identity_id != '' and  HH_identity_id is not None, "Failed due to HH identity id is empty or none"

    status, HH_wallet_response_results = wallet.get_wallet_by_walletid(Fun_APP_URL, HH_wallet_id_api)
    status, HH_wallet_status_api = api_helper_methods.extract_value_by_key(HH_wallet_response_results, key="status")
    status, HH_wallet_type_api = api_helper_methods.extract_value_by_key(HH_wallet_response_results, key="type")
    assert HH_wallet_status_api == 'ACTIVE', "Failed to validate Parent wallet is active"
    assert HH_wallet_type_api == 'HOUSEHOLD', "Failed to validate Household"

    status, HH_identities_response = identity.get_identities_by_wallet_id(Fun_APP_URL, HH_wallet_id_api)
    status, HH_num_api = api_helper_methods.extract_value_by_key(HH_identities_response, key="value")
    assert HH_num_api == hh_num, "Failed to validate household number from EE api response with svoc"
    status, HH_identity_status_api = api_helper_methods.extract_value_by_key(HH_identities_response, key="status")
    assert HH_identity_status_api == 'ACTIVE', "Failed to validate HH identity status is active"

    for enrolled_cards in geac_card_svoc_db:
        status, cw_response_results = wallet.get_walletid_by_identity(Fun_APP_URL, enrolled_cards, "GEAC")
        if cw_response_results!= '' and cw_response_results is not None:
            status, consumer_wallet_id_api = api_helper_methods.extract_value_by_key(cw_response_results, key="walletId")
            status, consumer_identity_id_api = api_helper_methods.extract_value_by_key(cw_response_results, key="identityId")
            status, consumer_wallet_status_api = api_helper_methods.extract_value_by_key(cw_response_results, key="status")
            consumer_details_by_geac.append({"consumer_wallet_id": consumer_wallet_id_api,
                                     "consumer_identity_id": consumer_identity_id_api,
                                     "enrolled_cards": enrolled_cards,
                                     "card_status":consumer_wallet_status_api})

    unique_wallet_id = set(walletid['consumer_wallet_id'] for walletid in consumer_details_by_geac)
    for walletid in unique_wallet_id:
        status, Consumer_wallet_response_results = wallet.get_wallet_by_walletid(Fun_APP_URL, walletid)
        status, Consumer_wallet_status_api = api_helper_methods.extract_value_by_key(Consumer_wallet_response_results, key="status")
        status, Consumer_wallet_type_api = api_helper_methods.extract_value_by_key(Consumer_wallet_response_results, key="type")
        assert Consumer_wallet_status_api == 'ACTIVE', "Failed to validate Consumer wallet is active"
        assert Consumer_wallet_type_api == 'CONSUMER', "Failed to validate CONSUMER"

        status, consumer_identity_response = identity.get_identities_by_wallet_id(Fun_APP_URL, walletid)
        status, con_wal_id_api = api_helper_methods.extract_value_by_key(consumer_identity_response, key="walletId")
        status, consumer_wallet_details = api_helper_methods.extract_multi_value_by_multi_key(consumer_identity_response, "results",
                                                                                                 "identityId", "value", "status")
        consumer_details_by_wallet.extend(consumer_wallet_details)

        status, consumer_response_results = consumer.get_consumer_by_wallet_id(Fun_APP_URL, walletid)
        status, cons_wallet_status_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="status")
        assert cons_wallet_status_api == 'ACTIVE', "Failed to validate consumer wallet is active"
        status, fn_from_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="firstName")
        status, ln_from_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="lastName")
        name_from_api = fn_from_api + ' ' + ln_from_api
        status, name_from_svoc_db = db_page.get_name_from_db(hh_num, name_from_api, svoc_db)
        assert api_helper_methods.validate_db_with_api_response(name_from_svoc_db, name_from_api,
                                                                 'consumer Name'), "Failed to validate consumer name from api vs ui match"

        status, segments_api_pro = api_helper_methods.extract_value_by_key(consumer_response_results, key="pro")
        status, segments_api_member = api_helper_methods.extract_value_by_key(consumer_response_results, key="member")
        status, consumer_segment_api = consumer.segment_check(segments_api_pro, segments_api_member)
        consumer_segment_db_val =  consumer.get_segment_check_eme_db(hh_num, eme_db[1])
        assert api_helper_methods.validate_db_with_api_response(consumer_segment_db_val, consumer_segment_api,
                                                                     'consumer_segment'), "Failed to validate consumer name from api vs ui match"

        status, accounts_response_results = accounts.get_accounts_by_wallet_id(Fun_APP_URL, walletid)
        status, client_type = api_helper_methods.extract_value_by_key(accounts_response_results, key="clientType")
        status, val = api_helper_methods.extract_value_by_key(accounts_response_results, key="status")
        status, campaignId = api_helper_methods.extract_value_by_key(accounts_response_results, key="campaignId")
        status, state = api_helper_methods.extract_value_by_key(accounts_response_results, key="state")
        assert accounts.validate_accounts_by_wallet_id(walletid, val, client_type, state, campaignId)

    assert acc_page.validate_svoc_db_ee_ui_ee_api(geac_card_svoc_db, consumer_details_by_geac, consumer_details_by_wallet), "Failed to validate consumer wallet api vs ui match"


import os
import time
import allure
import pytest
import output_data_set
from Marketing_apps.EagleEyeApi.services.accounts.accounts_apis import AccountsApi
from Marketing_apps.EagleEyeApi.services.consumer.consumer_apis import ConsumerApi
from Marketing_apps.EagleEyeApi.services.identities.identity_apis import IdentityApi
from Marketing_apps.SVOC.pages.accounts_page import AccountsPage
from Marketing_apps.SVOC.pages.createacc import CreateaccountsPage
from Marketing_apps.SVOC.pages.db_validations import DbValidationPage
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.search_page import SearchPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL, OUTPUT_PATH
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from custom_csv_output_file import OutputresultPage
from parsers import __parser
from utils.db_utils import get_mssql_engine_url
from utils.file_operations import create_folder
from Marketing_apps.EagleEyeApi.services.wallet.wallet_apis import WalletApi
from API_helper_methods.API_helper_methods import ApiHelperPage

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_acc_ge.json'),
                             ['FIRST_NAME', 'LAST_NAME', 'DOB', 'ADDRESS_1', 'ZIPCODE', 'STATE', 'CITY',
                              'CARD_TYPE', 'GEAC_NUMBER'])


@pytest.mark.Regression
@pytest.mark.parametrize('first_name, last_name, dob, Address_1, zipcode, state, city, card_type, geac_number', params)
@allure.description("Validate the HH creation")
def test_validate_hh_creation_(init_driver, first_name, last_name, dob, Address_1, zipcode, state, city, card_type,
                               geac_number):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    search_page = SearchPage(driver)
    db_page = DbValidationPage(driver)
    createacc = CreateaccountsPage(driver)
    acc_page = AccountsPage(driver)
    svoc_db = get_mssql_engine_url("SVOC_DB")

    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    # assert login_page.launch_application(url="http://eagledev/CustomerSingleViewQA/Accounts/Accounts/AccountsView?houseHoldNumber=74215976&IndividualId=87108010")
    assert home_page.verify_home_page(), "Failed to  verify home page in svoc "
    assert createacc.click_on_add_new_account_page(), "Failed to click on add new account page"
    assert createacc.verify_add_member_first_screen_in_account_page(), "Failed to verify add new account page"
    status, fn, ln = createacc.enter_info_new_acc_member_(first_name, last_name, dob, Address_1, zipcode, state, city)
    assert createacc.click_next_button(), "Failed to click on the next button"
    assert createacc.verify_add_member_second_screen_account_page(), "Failed to verify add new account page 2"
    assert createacc.validate_individual_name(fn, ln), "Failed to validate individual name"
    assert createacc.select_card_type(card_type), "Failed to select card type"
    assert createacc.click_issue_card_button(), "Failed to click on issue card button"
    assert createacc.click_on_generate_geac_button(), "Failed to click on generate geac button"
    assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
    assert createacc.click_submit_button_new_card(), "Failed to click on issue card  submit button"
    assert createacc.verify_add_member_second_indvidual_account_popup_screen(), "Failed to verify text screen"
    assert createacc.click_no_button(), "Failed to click No button"
    status, geac_no = createacc.copy_geac_number_from_main_svoc_screen()
    assert search_page.click_on_account(), "Failed to click on account"
    assert createacc.click_reset_button(), "Failed to click on reset button"
    assert acc_page.click_on_eagle_eye_sec(), 'Failed to click on Eagle eye section'
    status, svoc_ui_test_data = acc_page.extract_eagle_eye_section()

    wallet = WalletApi()
    identity = IdentityApi()
    api_helper_methods = ApiHelperPage()
    consumer = ConsumerApi()
    accounts = AccountsApi()
    new_consumer_wallet_identityid = []
    consumer_cards = []

    for values in svoc_ui_test_data:
        status, pw_response_results = wallet.get_walletid_by_identity(values['hh_num'])
        status, api_hh_num = api_helper_methods.extract_value_by_key(pw_response_results, key="value")
        assert api_helper_methods.validate_db_with_api_response(values['hh_num'], api_hh_num,
                                                                     'hh_num'), "Failed to validate api vs ui match"
        status, parent_wallet_id_api = api_helper_methods.extract_value_by_key(pw_response_results, key="walletId")
        status, parent_identity_id = api_helper_methods.extract_value_by_key(pw_response_results, key="identityId")
        assert api_helper_methods.validate_db_with_api_response(values['ParentId'], parent_wallet_id_api,
                                                                     'parent_wallet'), "Failed to validate api vs ui match"

        for enrolled_cards in values['Enrolled Cards']:
            status, cw_response_results = wallet.get_walletid_by_identity(enrolled_cards['card_no'])
            status, wallet_id_api = api_helper_methods.extract_value_by_key(cw_response_results, key="walletId")
            status, card_status_api = api_helper_methods.extract_value_by_key(cw_response_results, key="status")
            assert api_helper_methods.validate_db_with_api_response(values['WalletId'], wallet_id_api,
                                                                         'consumer_wallet_id'), "Failed to validate consumer wallet api vs ui match"
            assert api_helper_methods.validate_db_with_api_response(enrolled_cards['status'], card_status_api,
                                                                         'consumer_card_status'), "Failed to validate consumer card status api vs ui match"
            status, consumer_identity_id = api_helper_methods.extract_value_by_key(cw_response_results,
                                                                                   key="identityId")
            assert api_helper_methods.validate_db_with_api_response(values['WalletId'], wallet_id_api,
                                                                         'consumer_wallet'), "Failed to validate consumer wallet api vs ui match"
            consumer_cards.append(enrolled_cards['card_no'])

        status, parentwallet_response = identity.get_identities_by_wallet_id(values['ParentId'])
        status, pw_wallet_id_api = api_helper_methods.extract_value_by_key(parentwallet_response, key="walletId")
        assert api_helper_methods.validate_db_with_api_response(values['ParentId'], pw_wallet_id_api,
                                                                     'parent_walletid'), "Failed to validate parent walletid api vs ui match"

        status, pw_hh_num_api = api_helper_methods.extract_value_by_key(parentwallet_response, key="value")
        assert api_helper_methods.validate_db_with_api_response(values['hh_num'], pw_hh_num_api,
                                                                     'parent_walletid_hh_num'), "Failed to validate parent wallet hh_num api vs ui match"
        status, parent_wallet_identityid = api_helper_methods.extract_value_by_key(parentwallet_response,
                                                                                   key="identityId")

        status, consumer_response = identity.get_identities_by_wallet_id(values['WalletId'])
        status, con_wal_id_api = api_helper_methods.extract_value_by_key(consumer_response, key="walletId")
        status, consumer_wallet_identityid = api_helper_methods.extract_multi_value_by_multi_key(consumer_response,
                                                                                                 "results",
                                                                                                 "identityId", "value")
        assert api_helper_methods.validate_db_with_api_response(values['WalletId'], con_wal_id_api,
                                                                     'consumer_wallet'), "Failed to validate consumer wallet api vs ui match"
        new_consumer_wallet_identityid.extend(consumer_wallet_identityid)

        status, consumer_response_results = consumer.get_consumer_by_wallet_id(values['WalletId'])
        status, fn_from_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="firstName")
        status, ln_from_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="lastName")
        name_from_api = fn_from_api + ' ' + ln_from_api
        assert api_helper_methods.validate_db_with_api_response(values['Name'], name_from_api,
                                                                     'consumer Name'), "Failed to validate consumer name from api vs ui match"

        status, segments_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="member")
        segments_value_ui = api_helper_methods.trim_the_string(values['RewardTier'])
        assert api_helper_methods.validate_db_with_api_response(segments_value_ui, segments_api,
                                                                     'consumer segment value'), "Failed to validate consumer segment from api vs ui match"

        status, accounts_response_results = accounts.get_accounts_by_wallet_id(values['WalletId'])
        status, client_type = api_helper_methods.extract_value_by_key(accounts_response_results, key="clientType")
        status, val = api_helper_methods.extract_value_by_key(accounts_response_results, key="status")
        status, state = api_helper_methods.extract_value_by_key(accounts_response_results, key="state")
        assert accounts.validate_accounts_by_wallet_id(values['WalletId'], val, client_type, state)

    status, geac_card_svoc_db = db_page.get_geac_cards_from_db(values['hh_num'], svoc_db)
    assert acc_page.validate_svoc_db_ee_ui_ee_api(geac_card_svoc_db, consumer_cards, new_consumer_wallet_identityid,
                                                  ), "Failed to validate consumer wallet api vs ui match"


import os
import time
import allure
import pytest
import output_data_set
from Marketing_apps.EagleEyeApi.services.accounts.accounts_apis import AccountsApi
from Marketing_apps.EagleEyeApi.services.consumer.consumer_apis import ConsumerApi
from Marketing_apps.EagleEyeApi.services.identities.identity_apis import IdentityApi
from Marketing_apps.SVOC.pages.merge_split_process_page import MergeAndSplitPages
from Marketing_apps.SVOC.pages.accounts_page import AccountsPage
from Marketing_apps.SVOC.pages.createacc import CreateaccountsPage
from Marketing_apps.SVOC.pages.db_validations import DbValidationPage
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.search_page import SearchPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL, OUTPUT_PATH
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from custom_csv_output_file import OutputresultPage
from parsers import __parser
from utils.db_utils import get_mssql_engine_url, connect_db
from utils.file_operations import create_folder
from Marketing_apps.EagleEyeApi.services.wallet.wallet_apis import WalletApi
from API_helper_methods.API_helper_methods import ApiHelperPage
from Marketing_apps.EagleEyeApi.resources.constants import Fun_APP_URL

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_data_72080.json'),
                             ['FIRST_NAME', 'LAST_NAME', 'DOB', 'ADDRESS_1', 'ZIPCODE', 'STATE', 'CITY',
                              'CARD_TYPE', 'GEAC_NUMBER', 'FIRST_NAME_1', 'LAST_NAME_1', 'DOB_1', 'ADDRESS_2', 'ZIPCODE_1', 'STATE_1', 'CITY_1'])
@pytest.mark.Regression
@pytest.mark.split
@pytest.mark.parametrize('first_name, last_name, dob, Address_1, zipcode, state, city, card_type, geac_number, first_name_1, last_name_1, dob_1, Address_2, zipcode_1, state_1, city_1', params)
@allure.description("Split when the customer multi cards lost or stolen myperks seperation initiated by consumer 2")
def test_validate_split_process_multi_geac_lost_from_con2(init_driver, first_name, last_name, dob, Address_1, zipcode, state, city, card_type,
                          geac_number, first_name_1, last_name_1, dob_1, Address_2, zipcode_1, state_1, city_1):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    search_page = SearchPage(driver)
    createacc = CreateaccountsPage(driver)
    acc_page = AccountsPage(driver)
    db_page = DbValidationPage()
    split_page = MergeAndSplitPages(driver)
    svoc_db = get_mssql_engine_url("SVOC_DB")
    eme_db = connect_db("EME_DB")
    household = []

    """services"""
    wallet = WalletApi()
    identity = IdentityApi()
    api_helper_methods = ApiHelperPage()
    consumer = ConsumerApi()
    accounts = AccountsApi()
    consumer_details_by_geac = []
    consumer_details_by_wallet = []


    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.verify_home_page(), "Failed to  verify home page in svoc "
    assert createacc.click_on_add_new_account_page(), "Failed to click on add new account page"
    assert createacc.verify_add_member_first_screen_in_account_page(), "Failed to verify add new account page"
    status, fn, ln = createacc.enter_info_new_acc_member_(first_name, last_name, dob, Address_1, zipcode, state, city)
    assert createacc.click_next_button(), "Failed to click on the next button"
    assert createacc.verify_add_member_second_screen_account_page(), "Failed to verify add new account page 2"
    assert createacc.validate_individual_name(fn, ln), "Failed to validate individual name"
    assert createacc.select_card_type(card_type), "Failed to select card type"
    assert createacc.click_issue_card_button(), "Failed to click on issue card button"
    status, consumer1_geac_card =  createacc.click_on_generate_geac_button()
    assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
    assert createacc.click_submit_button_new_card(), "Failed to click on issue card  submit button"
    assert createacc.verify_add_member_second_indvidual_account_popup_screen(), "Failed to verify text screen"
    assert createacc.click_no_button(), "Failed to click No button"
    assert acc_page.verify_new_reward_acc_member_added(), "Failed to verify new member added msg on the svoc screen"
    status, con1_geac_card = createacc.copy_geac_number_from_main_svoc_screen()
    assert search_page.click_on_account(), "Failed to click on account"
    assert createacc.click_reset_button(), "Failed to click on reset button"

    for _ in range(1):
        assert acc_page.click_on_all_cards_drop_down(), "Failed to click on the all cards drop down section"
        assert acc_page.click_on_add_btn_from_all_cards(), "Failed to click on add button in the all card section"
        assert createacc.verify_add_member_to_reward_acc(), "Failed to verify add member reward account page"
        assert createacc.choose_indivdual_name_to_add_card(fn, ln), "Failed to choose the individual name from add account page"
        assert createacc.click_on_generate_geac_button(), "Failed to click on generate geac button"
        assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
        assert createacc.click_submit_button_add_card(), "Failed to click on issue new card submit button"
        assert createacc.verify_new_card_added_alert(), "Failed to validate the 'Card account has been added.' alert message"


    assert acc_page.click_add_member_btn(), "Failed to click on add new member button"
    status, fn_1, ln_1 = createacc.enter_info_new_acc_member_(first_name_1, last_name_1, dob_1, Address_2, zipcode_1, state_1, city_1)
    assert createacc.click_next_button(), "Failed to click on the next button"
    assert createacc.verify_add_member_to_account_page(), "Failed to verify add member to account page"
    status, consumer_geac_2 =  createacc.click_on_generate_geac_button()
    assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
    assert createacc.click_submit_button_issue_card(), "Failed to click on issue card  submit button"
    assert acc_page.verify_new_member_added(), "Failed to verify new member added msg on the svoc screen"
    assert acc_page.verify_acc_users(fn, ln, fn_1, ln_1), "Failed to validate the account user"
    consumer_name_2 = fn_1 + '' + ln_1

    for _ in range(2):
        assert acc_page.click_on_all_cards_drop_down(), "Failed to click on the all cards drop down section"
        assert acc_page.click_on_add_btn_from_all_cards(), "Failed to click on add button in the all card section"
        assert createacc.verify_add_member_to_reward_acc(), "Failed to verify add member reward account page"
        assert createacc.choose_indivdual_name_to_add_card(fn_1, ln_1), "Failed to choose the individual name from add account page"
        assert createacc.click_on_generate_geac_button(), "Failed to click on generate geac button"
        assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
        assert createacc.click_submit_button_add_card(), "Failed to click on issue new card submit button"
        assert createacc.verify_new_card_added_alert(), "Failed to validate the 'Card account has been added.' alert message"

    assert acc_page.click_on_all_cards_drop_down(), "Failed to click on the all cards drop down section"
    status, hh_num_con1_con2 = acc_page.extract_hh_num_from_svoc_ui()
    status, bef_split_cons1_con2_card = db_page.get_geac_cards_from_db(hh_num_con1_con2, svoc_db)
    household.append(hh_num_con1_con2)

    assert acc_page.change_all_card_geac_card_status(bef_split_cons1_con2_card, 'LOST/STOLEN')
    assert acc_page.click_on_update_card_status(), "Failed to update the card status"
    assert acc_page.verify_card_status_change_alert(), "Failed to change the card status"

    status, bef_cons1_con2_card_details = db_page.get_cust_details_from_db(hh_num_con1_con2, svoc_db)
    status, geac_from_svoc_db = db_page.get_geac_cards_from_db(hh_num_con1_con2, svoc_db)
    status, HH_identity_response_results = wallet.get_walletid_by_identity(Fun_APP_URL, hh_num_con1_con2, "HOUSEHOLD")
    status, HH_wallet_id_api = api_helper_methods.extract_value_by_key(HH_identity_response_results, key="walletId")
    status, HH_identity_id = api_helper_methods.extract_value_by_key(HH_identity_response_results, key="identityId")

    for consumers in bef_cons1_con2_card_details:
        for enrolled_cards in geac_from_svoc_db:
            status, cw_response_results = wallet.get_walletid_by_identity(Fun_APP_URL, enrolled_cards, "GEAC")
            status, consumer_wallet_id_api = api_helper_methods.extract_value_by_key(cw_response_results, key="walletId")
            status, consumer_identity_id_api = api_helper_methods.extract_value_by_key(cw_response_results, key="identityId")    #
            status, consumer_response_results = consumer.get_consumer_by_wallet_id(Fun_APP_URL, consumer_wallet_id_api)
            status, consumer_id = api_helper_methods.extract_value_by_key(consumer_response_results, key="consumerId")
            if consumers["CardNumber"] == enrolled_cards:
                status, results = consumer.get_consumer_details_before_merge_split(consumers, HH_wallet_id_api, HH_identity_id, consumer_wallet_id_api,consumer_identity_id_api, consumer_id)

    assert split_page.click_initiate_seperation_btn(), "Failed to click on intiate seperation"
    assert split_page.verify_initiate_seperation_screen(), "Failed to verify intiate seperation"
    assert split_page.click_seperation_btn(), "Failed to click on seperation button"
    assert split_page.click_use_existing_address_btn(), "Failed to click on existing address button"
    assert createacc.verify_add_member_second_screen_account_page(), "Failed to verify add new account page 2"
    status, seperated_name = createacc.validate_individual_name(fn, ln, fn_1, ln_1)
    assert createacc.click_issue_card_button(), "Failed to click on issue card button"
    assert createacc.select_card_type(card_type), "Failed to select card type"
    assert createacc.click_on_generate_geac_button(), "Failed to click on generate geac button"
    assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
    status, assign_new_geac_cons_1 = createacc.click_on_generate_geac_button()
    assert createacc.click_submit_button_new_card(), "Failed to click on issue card  submit button"
    assert createacc.verify_add_member_second_indvidual_account_popup_screen(), "Failed to verify text screen"
    assert createacc.click_no_button(), "Failed to click No button"
    assert split_page.verify_reward_member_seperation_alert_(), "Failed to verify reward member seperation alert"
    assert acc_page.click_on_all_cards_drop_down(), "Failed to click on the all cards drop down section"
    status, hh_num_con2 = acc_page.extract_hh_num_from_svoc_ui()
    household.append(hh_num_con2)

    status, aft_con2_details = db_page.get_cust_details_from_db(hh_num_con2, svoc_db)
    status, old_geac = home_page.validate_consumer_sep(bef_cons1_con2_card_details, aft_con2_details)

    for hh_num in household :
        status, geac_card_svoc_db = db_page.get_geac_cards_from_db(hh_num, svoc_db)
        status, HH_identity_response_results = wallet.get_walletid_by_identity(Fun_APP_URL, hh_num, "HOUSEHOLD")
        status, HH_wallet_id_api = api_helper_methods.extract_value_by_key(HH_identity_response_results, key="walletId")
        status, HH_identity_id = api_helper_methods.extract_value_by_key(HH_identity_response_results, key="identityId")
        assert HH_identity_id != '' and HH_identity_id is not None, "Failed due to HH identity id is empty or none"

        status, HH_wallet_response_results = wallet.get_wallet_by_walletid(Fun_APP_URL, HH_wallet_id_api)
        status, HH_wallet_status_api = api_helper_methods.extract_value_by_key(HH_wallet_response_results, key="status")
        status, HH_wallet_type_api = api_helper_methods.extract_value_by_key(HH_wallet_response_results, key="type")
        assert HH_wallet_status_api == 'ACTIVE', "Failed to validate Parent wallet is active"
        assert HH_wallet_type_api == 'HOUSEHOLD', "Failed to validate Household"

        status, HH_identities_response = identity.get_identities_by_wallet_id(Fun_APP_URL, HH_wallet_id_api)
        status, HH_num_api = api_helper_methods.extract_value_by_key(HH_identities_response, key="value")
        assert HH_num_api == hh_num, "Failed to validate household number from EE api response with svoc"
        status, HH_identity_status_api = api_helper_methods.extract_value_by_key(HH_identities_response, key="status")
        assert HH_identity_status_api == 'ACTIVE', "Failed to validate HH identity status is active"

        for enrolled_cards in geac_card_svoc_db:
            status, cw_response_results = wallet.get_walletid_by_identity(Fun_APP_URL, enrolled_cards, "GEAC")
            if cw_response_results != '' and cw_response_results is not None:
                status, consumer_wallet_id_api = api_helper_methods.extract_value_by_key(cw_response_results, key="walletId")
                status, consumer_identity_id_api = api_helper_methods.extract_value_by_key(cw_response_results, key="identityId")
                status, consumer_identity_wallet_status_api = api_helper_methods.extract_value_by_key(cw_response_results, key="status")
                consumer_details_by_geac.append({"parent_wallet_id": HH_wallet_id_api,
                                                 "parent_identity_id": HH_identity_id,
                                                 "consumer_wallet_id": consumer_wallet_id_api,
                                                 "consumer_identity_id": consumer_identity_id_api,
                                                 "enrolled_cards": enrolled_cards,
                                                 "card_status": consumer_identity_wallet_status_api})

                assert wallet.validate_consumer_wallet_identity_status(enrolled_cards, consumer_identity_wallet_status_api,consumer_wallet_id_api)

            unique_wallet_id = set(walletid['consumer_wallet_id'] for walletid in consumer_details_by_geac if 'consumer_wallet_id' in walletid)
            for walletid in unique_wallet_id:
                status, Consumer_wallet_response_results = wallet.get_wallet_by_walletid(Fun_APP_URL, walletid)
                status, Consumer_wallet_status_api = api_helper_methods.extract_value_by_key(Consumer_wallet_response_results, key="status")
                status, Consumer_wallet_type_api = api_helper_methods.extract_value_by_key(Consumer_wallet_response_results, key="type")
                assert Consumer_wallet_status_api == 'ACTIVE', "Failed to validate Consumer wallet is active"
                assert Consumer_wallet_type_api == 'CONSUMER', "Failed to validate CONSUMER"

                status, consumer_identity_response = identity.get_identities_by_wallet_id(Fun_APP_URL, walletid)
                status, con_wal_id_api = api_helper_methods.extract_value_by_key(consumer_identity_response, key="walletId")
                status, consumer_wallet_details = api_helper_methods.extract_multi_value_by_multi_key(consumer_identity_response, "results",
                                                                                                         "identityId", "value", "status")
                consumer_details_by_wallet.extend(consumer_wallet_details)

                status, consumer_response_results = consumer.get_consumer_by_wallet_id(Fun_APP_URL, walletid)
                status, consumer_id = api_helper_methods.extract_value_by_key(consumer_response_results, key="consumerId")
                status, cons_wallet_status_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="status")
                assert cons_wallet_status_api == 'ACTIVE', "Failed to validate consumer wallet is active"
                status, fn_from_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="firstName")
                status, ln_from_api = api_helper_methods.extract_value_by_key(consumer_response_results, key="lastName")
                name_from_api = fn_from_api + ' ' + ln_from_api
                status, name_from_svoc_db = db_page.get_name_from_db(hh_num, name_from_api, svoc_db)
                assert api_helper_methods.validate_db_with_api_response(name_from_svoc_db, name_from_api,
                                                                         'consumer Name'), "Failed to validate consumer name from api vs ui match"
                consumer_details_by_geac_ = consumer.add_consumerid_into_array(consumer_details_by_geac, walletid,
                                                                               consumer_id)

                status, segments_api_pro = api_helper_methods.extract_value_by_key(consumer_response_results, key="pro")
                status, segments_api_member = api_helper_methods.extract_value_by_key(consumer_response_results, key="member")
                status, consumer_segment_api = consumer.segment_check(segments_api_pro, segments_api_member)
                consumer_segment_db_val = consumer.get_segment_check_eme_db(hh_num, eme_db[1])
                assert api_helper_methods.validate_db_with_api_response(consumer_segment_db_val, consumer_segment_api,
                                                                             'consumer_segment'), "Failed to validate consumer name from api vs ui match"

                status, accounts_response_results = accounts.get_accounts_by_wallet_id(Fun_APP_URL, walletid)
                status, client_type = api_helper_methods.extract_value_by_key(accounts_response_results, key="clientType")
                status, val = api_helper_methods.extract_value_by_key(accounts_response_results, key="status")
                status, campaignId = api_helper_methods.extract_value_by_key(accounts_response_results, key="campaignId")
                status, state = api_helper_methods.extract_value_by_key(accounts_response_results, key="state")
                assert accounts.validate_accounts_by_wallet_id(walletid, val, client_type, state, campaignId)
                status, points_credited = api_helper_methods.extract_value_by_key(accounts_response_results, key="current")


    # assert acc_page.validate_svoc_db_ee_ui_ee_api(geac_card_svoc_db, consumer_details_by_geac, consumer_details_by_wallet), "Failed to validate consumer wallet api vs ui match"
    assert db_page.check_card_exists_in_db(old_geac, svoc_db), "Failed to verify the Geac in DB"
    assert identity.validate_ee_parent_wallet_identity_split(bef_cons1_con2_card_details, consumer_details_by_geac)
    assert split_page.validate_ee_consumers_info(bef_cons1_con2_card_details, consumer_details_by_geac, 'split')

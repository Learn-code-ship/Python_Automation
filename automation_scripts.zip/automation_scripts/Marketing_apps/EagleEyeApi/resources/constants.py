import datetime
import os
from os.path import dirname, abspath
from utils.file_operations import load_db_config_file

RESULTS_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'results')
TEST_DATA_PATH= os.path.join(dirname(dirname(abspath(__file__))), 'resources')

QA_URL = load_db_config_file('Eagle Eye API', "qa_url")
DEV_URL = load_db_config_file('Eagle Eye API', "dev_url")
Fun_APP_URL = load_db_config_file('Eagle Eye API', "fun_app_url")


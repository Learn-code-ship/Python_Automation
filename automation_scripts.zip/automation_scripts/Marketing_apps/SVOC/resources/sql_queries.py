def get_geac_cards_from_svoc_db(hh_num=None, name=None, CardNumber=None):
    query = {
        "hh_num": """select A.CardNumber from (select FirstName, LastName, CardNumber FROM [CustomerSingleView].[dbo].[vwRewardAccount] where HouseholdNumber = '""" + str(
            hh_num) + """'
            group by FirstName, LastName, CardNumber )A""",
        "name": """select FirstName, LastName FROM [CustomerSingleView].[dbo].[vwRewardAccount] where HouseholdNumber = '""" + str(
            hh_num) + """' and concat(FirstName,' ',LastName)= '""" + str(name) + """'
            group by FirstName, LastName""",
        "card_number": """select CardNumber FROM [CustomerSingleView].[dbo].[vwRewardAccount] where HouseholdNumber = '""" + str(
            hh_num) + """' and concat(FirstName,' ',LastName)= '""" + str(name) + """'""",
        "individual_id": """select IndividualId FROM [CustomerSingleView].[dbo].[vwRewardAccount] where HouseholdNumber = '""" + str(
            hh_num) + """'""",
        "customer_details": """select HouseholdNumber, Individualid, FirstName, LastName, CardNumber,
                            case when CardStatuscode = '00' then 'ACTIVE'
                                 when CardStatusCode = '2'  then 'SUSPENDED' else 'NA' end as CardStatuscode
                            FROM [CustomerSingleView].[dbo].[vwRewardAccount] where HouseholdNumber =  '""" + str(hh_num) + """'""",
        "geac": """select CardNumber FROM [CustomerSingleView].[dbo].[vwRewardAccount] where CardNumber = '""" + str(CardNumber) + """'"""
    }
    return query

def get_segment_check_eme_db(hh_num):
    query = {
        "segment": """select case when eme.cpn_in_string(targ_cpns,'3008') = 1 
        and eme.cpn_in_string(targ_cpns,'3009') <> 1 then 'myPerks Member'
        when eme.cpns_in_string(targ_cpns,'30083009') > 0 then 'myPerks Pro' else 'NA' end as status
        from household where hh_num ='"""+str(4)+str(hh_num) + """'"""
    }
    return query

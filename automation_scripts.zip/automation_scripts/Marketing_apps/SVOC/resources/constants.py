import os
from os.path import dirname, abspath

from utils.file_operations import load_db_config_file


RESULTS_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'results')
RESOURCE_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'resources')
TEST_DATA_PATH= os.path.join(dirname(dirname(abspath(__file__))), 'resources', 'testData')
TEMPLATE_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'resources', 'testData', 'Templates')
OUTPUT_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'results', 'output.csv')
REPORT_OUTPUT_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'results', 'report_ee_file.csv')

SVOC_URL = load_db_config_file('SVOC', "url")






import os
import allure
import pytest

from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.profile_page import ProfilePage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54198.json'), ['CUSTOMER_ID','FIRST_NAME', 'LAST_NAME',
                                                                               'ADDRESS', 'PHONE_NO', 'EMAIL_ID'])


@pytest.mark.Regression
@pytest.mark.parametrize('customer_id, first_name, last_name, address, phone_no, email_id', params)
@allure.description("SVOC login  /Search Customer ID")
def test_to_validate_contact_information_of_user(init_driver, customer_id, first_name, last_name, address, phone_no, email_id ):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    svoc = ProfilePage(driver)
    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.navigate_to_customer_profile(customer_id), "Failed to Navigate to Customer Profile Page "
    assert svoc.navigate_to_contact_information(),"Failed to Navigate to Contact Information Page "
    assert svoc.validating_contact_information_of_customer_in_profile(first_name, last_name, address, phone_no, email_id ), "Failed while validating contact information of customer in profile "

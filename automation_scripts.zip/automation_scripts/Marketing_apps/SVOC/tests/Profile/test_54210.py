# import os
# import allure
# import pytest
#
# from Marketing_apps.SVOC.pages.home_page import HomePage
# from Marketing_apps.SVOC.pages.login_page import LoginPage
# from Marketing_apps.SVOC.pages.profile_page import ProfilePage
# from Marketing_apps.SVOC.resources.constants import SVOC_URL
# from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
# from parsers import __parser
# from utils.file_operations import create_folder
#
# params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54197.json'), ['USER_ID', 'CUSTOMER_ID'])
#
#
# @pytest.mark.Regression
# @pytest.mark.Profile
# @pytest.mark.TC54210
# @pytest.mark.parametrize('user_id, customer_id', params)
# @allure.description("SVOC login  /Search Customer ID")
# def  test_to_validate_all_profile_dropdowns(init_driver,user_id, customer_id ):
#     create_folder(RESULTS_PATH)
#     driver = init_driver
#     login_page = LoginPage(driver)
#     home_page = HomePage(driver)
#     svoc = ProfilePage(driver)
#     assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
#     assert home_page.navigate_to_customer_profile(user_id, customer_id), "Failed to Navigate to Customer Profile Page "
#     assert svoc.navigate_to_contact_information(),"Failed to Navigate to Contact Information Page "
#     assert svoc.navigate_to_preference_information(), "Failed to Navigate to Preference  Information Page "
#     assert svoc.navigate_to_household_members_information(), "Failed to Navigate to Household Members Page "
#     assert svoc.navigate_to_Groups_information(), "Failed to Navigate to Groups Information Page "
#     assert svoc.navigate_to_Surveys_information(), "Failed to Navigate to Surveys Information Page "
#     assert svoc.navigate_to_pharmacy_information_page(), "Failed to Navigate to Pharmacy Information Page "
import os
import allure
import pytest

from Marketing_apps.SVOC.pages.accounts_page import AccountsPage
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.search_page import SearchPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_62717.json'), ['HOUSEHOLD_NO'])


@pytest.mark.Regression
@pytest.mark.ProfileSearch
@pytest.mark.parametrize('household_no', params)
@allure.description("SVOC login Search using household of the Customer")
def test_to_search_profile_using_household_num(init_driver, household_no):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    account_page = AccountsPage(driver)
    search_page = SearchPage(driver)

    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.verify_home_page(), "Failed to  verify home page in svoc "
    assert search_page.click_on_advance_search(), "Failed to click on the advanced search in svoc"
    assert search_page.verify_advance_search_popup, "Failed to  verify advanced search pop up page in svoc "
    assert search_page.search_with_household_num(household_no), "Failed to search with household number"
    assert search_page.click_search_button(), "Failed to click on the search button"
    assert search_page.validate_search_page(), "Failed to navigate to search page"
    assert search_page.click_on_account(), "Failed to click on account"
    assert account_page.click_on_all_cards_drop_down(), "Failed to click on all cards dropdown"
    assert search_page.validate_search_with_household(household_no), "Failed to validate the customer profile by household"
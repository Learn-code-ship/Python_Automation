import os
import allure
import pytest

from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.profile_page import ProfilePage
from Marketing_apps.SVOC.pages.preferences_page import PreferencePage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54200.json'), ['USER_ID', 'CUSTOMER_ID','CONTACT_TYPE_DNC','MODE_OF_CONTACT'])


@pytest.mark.Regression
@pytest.mark.Profile
@pytest.mark.TC54197
@pytest.mark.parametrize('user_id, customer_id, contact_type_dnc, mode_of_contact', params)
@allure.description("SVOC login  /Search Customer ID")
def  test_to_validate_and_update_customer_preference_in_profile(init_driver, user_id, customer_id, contact_type_dnc, mode_of_contact):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    svoc = ProfilePage(driver)
    pref = PreferencePage(driver)
    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.navigate_to_customer_profile(user_id, customer_id), "Failed to Navigate to Customer Profile Page "
    assert svoc.profile_button_click(),"Failed to click on profile button "
    assert svoc.navigate_to_preference_information(),"Failed to Navigate to Preference Page "
    assert pref.selecting_method_of_contact_as_do_not_contact(contact_type_dnc),"Failed to select method of contact as do not contact "
    assert pref.selecting_general_preference_of_customer(mode_of_contact),"Failed to select general preferences in prefernece and mode of contact "
    assert pref.selecting_program_preference_of_customer(),"Failed to select program preference of customer"
    assert pref.clicking_update_preference_button_and_validating_updated_preference(),"failed to cick on Update Preference button "
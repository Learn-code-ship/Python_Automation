import os
import allure
import pytest

from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.profile_page import ProfilePage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54199.json'), ['USER_ID', 'CUSTOMER_ID','FIRST_NAME', 'MIDDLE_NAME', 'LAST_NAME','DOB',
                                                                               'ADDRESS', 'PHONE_NO'])


@pytest.mark.Regression
@pytest.mark.parametrize('user_id, customer_id, first_name, middle_name, last_name, dob, address, phone_no', params)
@allure.description("SVOC login  /Search Customer ID")
def test_to_edit_contact_information_and_validate_it_in_contact_details(init_driver, user_id, customer_id, first_name, middle_name, last_name, dob, address, phone_no ):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    svoc = ProfilePage(driver)
    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.navigate_to_customer_profile(user_id, customer_id), "Failed to Navigate to Customer Profile Page "
    assert svoc.navigate_to_contact_information(),"Failed to Navigate to Contact Information Page "
    assert svoc.editing_customer_contact_information_details(first_name, middle_name, last_name, dob, address, phone_no ), "Failed while editing contact information of customer in profile "

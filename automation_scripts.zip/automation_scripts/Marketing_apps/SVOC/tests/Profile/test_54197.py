import os
import allure
import pytest

from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.search_page import SearchPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54197.json'), ['CARD_NO'])


@pytest.mark.Regression
@pytest.mark.ProfileSearch
@pytest.mark.parametrize('card_no', params)
@allure.description("search svoc with card no / bar code")
def  test_to_search_profile_using_barcode(init_driver, card_no):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    search_page = SearchPage(driver)

    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.verify_home_page(), "Failed to  verify home page in svoc "
    assert search_page.click_on_advance_search(), "Failed to click on the advanced search in svoc"
    assert search_page.verify_advance_search_popup, "Failed to  verify advanced search pop up page in svoc "
    assert search_page.search_with_barcode(card_no), "Failed to search with bar code/ card no"
    assert search_page.click_search_button(), "Failed to click on the search button"
    assert search_page.validate_search_page(), "Failed to navigate to search page"
    assert search_page.validate_search_with_barcode(card_no), "Failed to validate the barcode"



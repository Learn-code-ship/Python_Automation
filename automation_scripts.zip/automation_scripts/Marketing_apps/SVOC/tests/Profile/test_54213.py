import os
import allure
import pytest
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.profile_page import ProfilePage
from Marketing_apps.SVOC.pages.pharmacy_page import PharmacyPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54213.json'), ['USER_ID', 'CUSTOMER_ID','PHAR_STATUS'])


@pytest.mark.Regression 
@pytest.mark.Profile
@pytest.mark.TC54197
@pytest.mark.parametrize('user_id, customer_id, phar_status', params)
@allure.description("SVOC login /Search Customer ID")
def  test_to_check_pharmacy_details_of_profile(init_driver, user_id, customer_id, phar_status):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    svoc = ProfilePage(driver)
    phar = PharmacyPage(driver)
    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.navigate_to_customer_profile(user_id, customer_id), "Failed to Navigate to Customer Profile Page "
    assert svoc.profile_button_click(),"Failed to click on profile button "
    assert svoc.navigate_to_pharmacy_information_page(),"Failed to Navigate to Pharmacy Information Page "
    assert phar.checking_pharmacy_information_status(phar_status),"Failed to check pharmacy information status "
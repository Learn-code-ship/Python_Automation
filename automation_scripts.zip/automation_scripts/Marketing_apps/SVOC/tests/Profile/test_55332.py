import os
import allure
import pytest

from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.search_page import SearchPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_55332.json'), ['FIRST_NAME', 'LAST_NAME'])


@pytest.mark.Regression
@pytest.mark.ProfileSearch
@pytest.mark.parametrize('first_name, last_name', params)
@allure.description("SVOC login Search using email of the Customer")
def test_to_search_profile_using_name(init_driver, first_name, last_name):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    search_page = SearchPage(driver)

    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.verify_home_page(), "Failed to  verify home page in svoc "
    assert search_page.click_on_advance_search(), "Failed to click on the advanced search in svoc"
    assert search_page.verify_advance_search_popup, "Failed to  verify advanced search pop up page in svoc "
    assert search_page.search_with_fname_lastname(first_name, last_name), "Failed to search with mail id"
    assert search_page.click_search_button(), "Failed to click on the search button"
    assert search_page.validate_search_page(), "Failed to navigate to search page"
    assert search_page.validate_search_by_name(first_name, last_name), "Failed to validate the customer profile by name"
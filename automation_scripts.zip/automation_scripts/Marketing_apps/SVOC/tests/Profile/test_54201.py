import os
import allure
import pytest
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.profile_page import ProfilePage
from Marketing_apps.SVOC.pages.household_members_page import HouseholdMembersPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54201.json'), ['USER_ID', 'CUSTOMER_ID', 'FIRST_NAME'])


@pytest.mark.Regression
@pytest.mark.Profile
@pytest.mark.TC54197
@pytest.mark.parametrize('user_id, customer_id, first_name', params)
@allure.description("SVOC login /Search Customer ID")
def  test_to_validatae_housheold_members_and_detail(init_driver, user_id, customer_id, first_name):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    svoc = ProfilePage(driver)
    hmp = HouseholdMembersPage(driver)
    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.navigate_to_customer_profile(user_id, customer_id), "Failed to Navigate to Customer Profile Page "
    assert svoc.profile_button_click(),"Failed to click on profile button "
    assert svoc.navigate_to_household_members_information(),"Failed to Navigate to Household Members  Page "
    assert hmp.clicking_on_household_members_and_validating(first_name),"Failed to click on rewards account in group page "
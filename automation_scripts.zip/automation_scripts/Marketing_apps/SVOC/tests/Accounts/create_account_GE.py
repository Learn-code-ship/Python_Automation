import os
import time

import allure
import pytest

import output_data_set
from Marketing_apps.SVOC.pages.createacc import CreateaccountsPage
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.search_page import SearchPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL, OUTPUT_PATH
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from custom_csv_output_file import OutputresultPage
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_acc_ge.json'), ['FIRST_NAME', 'LAST_NAME', 'DOB', 'ADDRESS_1', 'ZIPCODE', 'STATE', 'CITY',
                                                                             'CARD_TYPE', 'GEAC_NUMBER'])


@pytest.mark.Regression
@pytest.mark.ProfileSearch
@pytest.mark.parametrize('first_name, last_name, dob, Address_1, zipcode, state, city, card_type, geac_number', params)
@allure.description("create account in SVOC")
def test_to_create_acc_ge(init_driver, first_name, last_name, dob, Address_1, zipcode, state, city, card_type, geac_number):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    search_page = SearchPage(driver)
    createacc = CreateaccountsPage(driver)
    output_page = OutputresultPage(driver)
    output_data_set.file_path = OUTPUT_PATH
    output_data_set.output_dict = output_data_set.svoc_output_set

    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.verify_home_page(), "Failed to  verify home page in svoc "
    assert createacc.click_on_add_new_account_page(), "Failed to click on add new account page"
    assert createacc.verify_add_member_first_screen_in_account_page(), "Failed to verify add new account page"
    status, fn, ln = createacc.enter_info_new_acc_member_(first_name, last_name, dob, Address_1, zipcode, state, city)
    assert createacc.click_next_button(), "Failed to click on the next button"
    assert createacc.verify_add_member_second_screen_account_page(), "Failed to verify add new account page 2"
    assert createacc.validate_individual_name(fn, ln), "Failed to validate individual name"
    assert createacc.select_card_type(card_type), "Failed to select card type"
    assert createacc.click_issue_card_button(), "Failed to click on issue card button"
    assert createacc.click_on_generate_geac_button(), "Failed to click on generate geac button"
    assert createacc.enter_geac_number(geac_number), "Failed to enter geac number"
    assert createacc.click_submit_button_new_card(), "Failed to click on issue card  submit button"
    assert createacc.verify_add_member_second_indvidual_account_popup_screen(), "Failed to verify text screen"
    assert createacc.click_no_button(), "Failed to click No button"
    status, geac_no = createacc.copy_geac_number_from_main_svoc_screen()
    assert search_page.click_on_account(), "Failed to click on account"
    assert createacc.click_reset_button(), "Failed to click on reset button"
    assert output_page.collect_values(ln, geac_no, dob, zipcode, card_type), " Failed to store the values into custom csv output file"
import os
import allure
import pytest
from Marketing_apps.SVOC.pages.home_page import HomePage
from Marketing_apps.SVOC.pages.login_page import LoginPage
from Marketing_apps.SVOC.pages.accounts_page import AccountsPage
from Marketing_apps.SVOC.resources.constants import SVOC_URL
from Marketing_apps.SVOC.resources.constants import RESULTS_PATH, TEST_DATA_PATH
from parsers import __parser
from utils.file_operations import create_folder

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_54218.json'), ['CUSTOMER_ID', 'REWARDS_ACCOUNT_ID'])


@pytest.mark.Regression
@pytest.mark.Profile
@pytest.mark.TC554218
@pytest.mark.parametrize('customer_id, rewards_account_id', params)
@allure.description("SVOC login  /Search Customer ID")
def test_svoc_validating_accounts_dropdown(init_driver,  customer_id, rewards_account_id):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = HomePage(driver)
    svoc = AccountsPage(driver)

    assert login_page.launch_application(SVOC_URL), "Failed to Login to SVOC Application"
    assert home_page.navigate_to_customer_profile(), "Failed to Navigate to Customer Profile Page "
    assert svoc.navigate_to_geac_rewards_account_page(rewards_account_id),"Failed to Navigate to GEAC Rewards Account Page  "
    # assert svoc.navigate_to_gianteagle_com_accouts_page(), "Failed to Navigate to Giant Eagle Come Accounts Page "
    # assert svoc.navigate_to_add_sep_rewards_account_page(), "Failed to Navigate to Add Sep Rewards Account Page "
    # assert svoc.navigate_to_merge_accounts(), "Failed to Navigate to Merge Accounts Page "

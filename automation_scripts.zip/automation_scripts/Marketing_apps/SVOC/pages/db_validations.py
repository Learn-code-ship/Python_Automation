"""
page object model for account page
"""
import allure
from utils.db_utils import execute_query, get_data_from_db

from Marketing_apps.SVOC.resources.sql_queries import get_geac_cards_from_svoc_db
from conftest import log


class DbValidationPage():

    @allure.step("Get geac cards from database")
    def get_geac_cards_from_db(self, hh_num, db_engine):
        """
        Method to get geac cards from svoc database
        :param hh-num:
        :param db_engine:
        :return: geac cards in string
        """
        status = True
        result = ''
        try:
            query = get_geac_cards_from_svoc_db(hh_num)["hh_num"]
            output, status = get_data_from_db(db_engine, query)
            formatted_output = [val[0] for val in output]
            result = formatted_output
            log.info("Geac Card - {0} is present for {1}".format(result, hh_num))
        except Exception as e:
            log.error("Exception {0} occured while fetching the geac cards from the svoc db based on HH_NUM ".format(e))
            status &= False
        return status, result


    @allure.step("Get name of geac cards from database")
    def get_name_from_db(self, hh_num, name, db_engine):
        """
        Method to get name of geac cards from svoc database
        :param hh-num:
        :param db_engine:
        :return: geac cards in string
        """
        status = True
        full_name = ''
        try:
            query = get_geac_cards_from_svoc_db(hh_num, name)["name"]
            output, status = get_data_from_db(db_engine, query)
            output = output[0]
            full_name = output[0] + ' ' + output[1]
            log.info("Name - {0} displayed for hh_num-{1}".format(full_name, hh_num))
        except Exception as e:
            log.error("Exception {0} occured while fetching the name from the svoc db based on HH_NUM ".format(e))
            status &= False
        return status, full_name

    @allure.step("Get card number from database by filtering the consumer-2 name")
    def get_card_from_db_by_name(self, hh_num, name, db_engine):
        """
        Method to Get card number from database by filtering the consumer-2 name
        :param hh-num:
        :param name:
        :param db_engine:
        :return: geac cards in string
        """
        status = True
        result = ''
        try:
            query = get_geac_cards_from_svoc_db(hh_num, name)["card_number"]
            output, status = get_data_from_db(db_engine, query)
            formatted_output = [val[0] for val in output]
            card_no = formatted_output
            log.info("get the cards from svoc db by filtering the name successfully")
        except Exception as e:
            log.error("Exception {0} occured while fetching the geac card from the svoc db based on name ".format(e))
            status &= False
        return status, card_no

    @allure.step("Get individual id from database")
    def get_individual_id_from_db(self, hh_num, db_engine):
        """
        Method to Get individual id from database
        :param hh-num:
        :param db_engine:
        :return: individual id as string
        """
        status = True
        result = ''
        try:
            query = get_geac_cards_from_svoc_db(hh_num)["individual_id"]
            output, status = get_data_from_db(db_engine, query)
            result = output[0]
            log.info("individual id fetched successfully")
        except Exception as e:
            log.error("Exception {0} occured while fetching the indvidual id from database ".format(e))
            status &= False
        return status, result

    @allure.step("Get customer details from database")
    def get_cust_details_from_db(self, hh_num, db_engine):
        """
        Method to get customer details from svoc database
        :param hh-num:
        :param db_engine:
        :return: customer details in string
        """
        status = True
        result = []
        try:
            query = get_geac_cards_from_svoc_db(hh_num)["customer_details"]
            output, status = get_data_from_db(db_engine, query)
            for i in output:
                result.append({
                    "HouseholdNumber": i[0],
                    "individual_id": i[1],
                    "firstName": i[2],
                    "lastName": i[3],
                    "CardNumber":i[4],
                    "CardStatuscode": i[5]
                })
            log.info("Geac Card - {0} is present for {1}".format(result, hh_num))
        except Exception as e:
            log.error("Exception {0} occured while fetching the geac cards from the svoc db based on HH_NUM ".format(e))
            status &= False
        return status, result

    @allure.step("check cardnumber exists in database")
    def check_card_exists_in_db(self, CardNumber, db_engine):
        """
        Method to Get cardnumber exists in database
        :param CardNumber:
        :param db_engine:
        :return: True or False
        """
        status = True
        result = ''
        try:
            query = get_geac_cards_from_svoc_db(CardNumber)["geac"]
            output, status = get_data_from_db(db_engine, query)
            if output == []:
                log.info(f"old card {CardNumber} is no more present in SVOC database")
        except Exception as e:
            log.error("Exception {0} occured while fetching the old card details from the database from database ".format(e))
            status &= False
        return status

    @allure.step("check household exists in database")
    def check_household_exists_in_db(self, hh_num, db_engine):
        """
        Method to check household exists in database
        :param CardNumber:
        :param db_engine:
        :return: True or False
        """
        status = True
        result = ''
        try:
            query = get_geac_cards_from_svoc_db(hh_num)["hh_num"]
            output, status = get_data_from_db(db_engine, query)
            if output == '' and output is None:
                log.info(f"From HH_NUM - {hh_num} is no more present in SVOC database")
        except Exception as e:
            log.error(
                "Exception {0} occured while fetching the from household details from the database ".format(e))
            status &= False
        return status

    @allure.step("Get geac cards from database")
    def get_geac_cards_from_db(self, hh_num, db_engine):
        """
        Method to get geac cards from svoc database
        :param hh-num:
        :param db_engine:
        :return: geac cards in string
        """
        status = True
        result = ''
        try:
            query = get_geac_cards_from_svoc_db(hh_num)["hh_num"]
            output, status = get_data_from_db(db_engine, query)
            formatted_output = [val[0] for val in output]
            result = formatted_output
            log.info("Geac Card - {0} is present for {1}".format(result, hh_num))
        except Exception as e:
            log.error("Exception {0} occured while fetching the geac cards from the svoc db based on HH_NUM ".format(e))
            status &= False
        return status, result

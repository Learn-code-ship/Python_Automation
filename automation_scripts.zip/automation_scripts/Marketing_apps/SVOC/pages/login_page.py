"""
page object model for login page
"""
from time import sleep

import allure
from selenium.webdriver.common.by import By

from conftest import log
from encryption import utils_encrypter
from seleniumhelper.sehelperpage import SeHelperPage


class LoginPage(SeHelperPage):
    """
    Class consists of login page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    #_username_textbox = (By.ID, 'userid')
    #_password_textbox = (By.ID, 'password')
    #_sign_in_button = (By.ID, 'btnActive')

    @allure.step("Login into the application")
    def launch_application(self, url):
        """
        method to login to application
        :param url: URL
        :return: status
        """
        status = False
        try:
            self.driver.get(str(url))
            sleep(1)
            self.page_refresh()
            self.wait_for_page_load_complete()
            status = True
            log.info("Logged in successfully")
        except Exception as e:
            status &= False
            log.error("Exception {} occurred while logging in".format(e))
        return status


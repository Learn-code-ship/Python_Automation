"""
page object model for Group page
"""
from time import sleep

import allure
from selenium.webdriver.common.by import By
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class GroupsPage(SeHelperPage):
    """
    Class consists of Group page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver


    rewards_account_heading = (By.XPATH,"//p[text()='Rewards Accounts']")
    rewards_account = "//a[text()='{}']"
    rewards_account_information_heading = (By.XPATH,"//p[text()='Rewards Account Information']")
    registered_card = "//span[text()='Registered Card: ']//parent::td//following-sibling::td//input[@value='{}']"
    add_button_for_rewards_account_in_group = (By.CSS_SELECTOR,"a[href*='&pagename=Groups']")
    add_new_account_heading = (By.XPATH,"//p[text()='Add New Account']")
    card_type_dropdown = (By.XPATH,"//select[@name='CardType']")
    ge_option_of_card_type = (By.XPATH,"//select[@name='CardType']//option[text()='GE']")
    account_type_personal = (By.XPATH,"//label[text()='Personal']")
    issue_card_button = (By.XPATH,"//input[@value='Issue Card']")
    generate_digital_card_button = (By.XPATH,"//a[text()='Generate Digital Card']")
    submit_button = (By.XPATH,"//input[@name='IssueCard']")
    no_option_for_pop_up_screen = (By.CSS_SELECTOR,"a[value='No']")
    group_has_been_added_pop_up=(By.XPATH,"//span[text()='Group has been added.']")

    @allure.step("method to click on rewards account in group page   ")
    def clicking_rewards_account_in_group_page(self, reward_account_nu):
        """
        Method to select Rewards account in group page and click on it
        param rewards_account_no: Rewards account ID
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            rewards_account_no = self.wait_and_find_ele_by_xpath(
                self.rewards_account.format(reward_account_nu))
            status &= self.click_element(rewards_account_no)

            log.info("Selected Rewards account in group and clicked on it and checked the detail  ")
        except Exception as e:
            log.error("Exception {} occurred while clicking on Rewards ACCOUNT IN Group Page  ".format(e))
            status &= False
        return status

    @allure.step("method to validate Rewards account information  ")
    def validating_rewards_account_info(self, customer_id):
        """
        Method to validate_rewards_account_info
        param rewards_account_no: Rewards account ID
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            registered_rewards_account_no = self.wait_and_find_ele_by_xpath(
                self.registered_card.format(customer_id))
            if self.ele_displayed(registered_rewards_account_no):
                status &= True
                log.info("Rewards account Information of customer is being displayed  ")
            else:
                log.error("Rewards account Information of customer is not  being displayed  ")
                status &= False

            log.info("Selected Rewards account information is being displayed in rewards account page ")
        except Exception as e:
            log.error("Exception {} occurred while validating rewards account information ".format(e))
            status &= False
        return status

    @allure.step("method to validate Rewards account information  ")
    def adding_rewards_accounts_in_groups(self):
        """
        Method to add rewards account in group
        param rewards_account_no: Rewards account ID
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.add_button_for_rewards_account_in_group)
            status &= self.click(*self.add_button_for_rewards_account_in_group)
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.add_new_account_heading):
                status &= True
                log.info("Add New account heading being displayed  ")
            else:
                log.error("Add new Account heading not being displayed  ")
                status &= False
            self.wait_for_element(self.card_type_dropdown)
            status &= self.click(*self.card_type_dropdown)
            sleep(3)
            self.wait_for_element(self.ge_option_of_card_type)
            status &= self.click(*self.ge_option_of_card_type)
            sleep(3)
            self.wait_for_element(self.account_type_personal)
            status &= self.click(*self.account_type_personal)
            sleep(3)
            self.wait_for_element(self.issue_card_button)
            status &= self.click(*self.issue_card_button)
            sleep(3)
            sleep(3)
            self.wait_for_element(self.generate_digital_card_button)
            status &= self.click(*self.generate_digital_card_button)
            sleep(3)
            self.wait_for_element(self.submit_button)
            status &= self.click(*self.submit_button)
            sleep(3)
            self.wait_for_element(self.no_option_for_pop_up_screen)
            status &= self.click(*self.no_option_for_pop_up_screen)
            if self.isdisplayed(*self.group_has_been_added_pop_up):
                status &= True
                log.info("successfully added a new card to rewards account in group")
            else:
                log.error("could not add a new card to rewards account in group page")
                status &= False

            log.info("Selected Added a new card to Rewards account in Group page  ")
        except Exception as e:
            log.error("Exception {} occurred while adding new card to rewards account in group ".format(e))
            status &= False
        return status
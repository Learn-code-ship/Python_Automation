"""
page object model for Surveys page
"""
from time import sleep

import allure
from selenium.webdriver.common.by import By
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class SurveysPage(SeHelperPage):
    """
    Class consists of Surveys page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver


    survey_history_heading = (By.XPATH,"//p[text()='Survey History']")
    no_survey_history_validator = (By.XPATH,"//pre[text()='No survey history exist for this individual.']")

    @allure.step("method to select mode of contact as do not contact in general preferences   ")
    def checking_if_survey_histroy_present_or_not(self):
        """
        Method to check survey history of customers in surveys page
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.no_survey_history_validator):
                status &= True
                log.info("No survey history is being displayed for customer ")
            else:
                log.error("Survey histories are being displayed for customer  ")
                status &= False
            log.info("succesfully validated if survey history are being displayed for customer in Surveys Page  ")
        except Exception as e:
            log.error("Exception {} occurred while validating Survey history reports for customer in Surveys page   ".format(e))
            status &= False
        return status


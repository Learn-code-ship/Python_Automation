"""
page object model for Profile page
"""
from time import sleep

import allure
from selenium.webdriver.common.by import By
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class ProfilePage(SeHelperPage):
    """
    Class consists of Profile page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver


    profile_tab_dropdown = (By.XPATH, "//span[text()='Profile']//parent::div")
    contact_information_button = (By.XPATH, "//li[@id='contactinformation']//child::a")
    basic_information_heading = (By.XPATH, "//p[text()='Basic Information']")
    preference_button = (By.XPATH, "//li[@id='preferences']//child::a")
    general_preference_heading = (By.XPATH, "//p[text()='General Preferences']")
    household_members_button = (By.XPATH, "//li[@id='household']//child::a")
    residential_household_heading = (By.XPATH, "//p[text()='Residential Household']")
    groups_button = (By.XPATH, "//li[@id='groups']//child::a")
    rewards_account_heading = (By.XPATH, "//p[text()='Rewards Accounts']")
    surveys_button = (By.XPATH, "//li[@id='surveys']//child::a")
    survey_history_heading = (By.XPATH, "//p[text()='Survey History']")
    pharmacy_button = (By.XPATH, "//li[@id='pharmacy']//child::a")
    pharmacy_information_heading = (By.XPATH, "//p[text()='Pharmacy Information']")

    first_name_of_customer = "//span[@id='firstname'][text()='{}']"
    last_name_of_customer = "//span[@id='lastname'][text()='{}']"
    addresses_heading = (By.XPATH,"//p[text()='Addresses']")
    address_detail = "//span[text()='{}']"
    phone_number_displayed = "//input[@value='{}']//preceding-sibling::span"
    email_addresses_heading = (By.XPATH,"//p[text()='Email Addresses']")
    email_id_being_displayed = "//input[@value='{}']//preceding-sibling::span"

    edit_name_button = (By.XPATH,"//a[@id='editname']")
    first_name_inputbox = (By.XPATH,"//span[@id='firstname']//child::input")
    middle_name_inputbox = (By.XPATH,"//span[@id='middlename']//child::input")
    last_name_inputbox = (By.XPATH,"//span[@id='lastname']//child::input")
    save_name_button = (By.XPATH,"//a[@id='savename']")
    dob_add_button = (By.XPATH,"//a[@id='dobadd']")
    edit_dob_button=(By.XPATH,"//a[@id='editdob']")
    dob_input_box = (By.XPATH,"//input[@id='dobcontent']")
    save_dob_button = (By.XPATH,"//a[@id='savedob']")
    edit_address_button = (By.XPATH,"(//a[text()='Edit'])[3]")
    address_input_textbox = (By.XPATH,"//input[@id='Address1']")
    save_address_button = (By.XPATH,"//input[@id='SaveAddress']")
    valid_address_active_check = (By.XPATH,"//label[@class='togglebtn addresstoggle YesActiv']")
    valid_address_no_option = (By.XPATH,"//label[@id='AddressNo']")
    valid_address_yes_option = (By.XPATH,"//label[@id='AddressYes']")
    valid_mail_check = (By.XPATH,"//label[@class='togglebtn SendMailToggle YesActiv']")
    valid_mail_no_option = (By.XPATH,"//label[@id='SendMailNo']")
    valid_mail_yes_option = (By.XPATH,"//label[@id='SendMailYes']")
    mail_status_update_pop_up = (By.XPATH,"//span[text()='Send Mail has been updated.']")
    phone_no_delete_update_pop_up = (By.XPATH, "//span[text()='Phone number has been deleted.']")
    add_phone_no_button = (By.XPATH,"//a[@id='phoneadd']")
    phone_number_input_box = (By.XPATH,"//input[@id='phonecontent1']")
    phone_no_type_dropdown = (By.XPATH,"//select[@id='phonetypeadd']")
    phone_no_type_home = (By.XPATH,"//select[@id='phonetypeadd']//child::option[@value='H']")
    save_phone_no_button = (By.XPATH,"//a[@id='savephone1']")
    delete_new_phone_no_button = (By.XPATH,"(//span[@id='trashicon'])[2]")
    confirm_delete_phone_no_button = (By.XPATH,"//input[@id='deletephoneclick']")
    search_barcode_heading = "//span[text()='{}']"
    count_of_search = (By.XPATH,"//span[@class='search-result-count']")

    @allure.step("Mthod to click on Profile button ")
    def profile_button_click(self):
        """
        Method to Click on Profile button
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.profile_tab_dropdown)
            status &= self.click(*self.profile_tab_dropdown)
            self.wait_for_page_load_complete()
            log.info("Profile button clicked ")
        except Exception as e:
            log.error("Exception {} occurred while Clicking on profile tab".format(e))
            status &= False
        return status

    @allure.step("Navigate to Contact Infromation Page ")
    def navigate_to_contact_information(self):
        """
                Method to Navigate contact informtion page of customer in profile
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.profile_tab_dropdown)
            status &= self.click(*self.profile_tab_dropdown)
            sleep(2)
            self.wait_for_element(self.contact_information_button)
            status &= self.click(*self.contact_information_button)
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.basic_information_heading):
                status &= True
                log.info("Navigated to contact Information page in Profile and Basic Information getting displayed ")
            else:
                log.error("Failed to navigate to contact information and validate basic information getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Navigated to contact information page under profile ")
        except Exception as e:
            log.error("Exception {} occurred while navigating to Contact Information Page in profile".format(e))
            status &= False
        return status

    @allure.step("Editing customer details in Contact Information page in profile  ")
    def editing_customer_contact_information_details(self, first_name, middle_name, last_name, dob, address, phone_no):
        """
        Method to Edit customer contact Information detail
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            # editing basic information
            self.wait_for_element(self.edit_name_button)
            status &= self.click(*self.edit_name_button)
            self.wait_for_element(self.first_name_inputbox)
            self.enter(first_name, *self.first_name_inputbox)
            sleep(2)
            self.wait_for_element(self.middle_name_inputbox)
            self.enter(middle_name, *self.middle_name_inputbox)
            sleep(2)
            self.wait_for_element(self.last_name_inputbox)
            self.enter(last_name, *self.last_name_inputbox)
            sleep(2)
            self.wait_for_element(self.save_name_button)
            status &= self.click(*self.save_name_button)
            self.wait_for_page_load_complete()
            self.wait_for_element(self.edit_dob_button)
            status &= self.click(*self.edit_dob_button)
            sleep(2)
            self.wait_for_element(self.dob_input_box)
            self.enter(dob, *self.dob_input_box)
            self.wait_for_element(self.save_dob_button)
            status &= self.click(*self.save_dob_button)
            sleep(5)

            # editig address of customer
            self.wait_for_element(self.edit_address_button)
            status &= self.click(*self.edit_address_button)
            sleep(3)
            self.wait_for_page_load_complete()
            self.wait_for_element(self.address_input_textbox)
            self.enter(address, *self.address_input_textbox)
            self.wait_for_element(self.save_address_button)
            status &= self.click(*self.save_address_button)
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.valid_address_active_check):
                status &= True
                log.info("address valid is checked to Yes ")
            else:
                log.error("address is not checked as valid making it a valid address  ")
                self.wait_for_element(self.valid_address_yes_option)
                status &= self.click(*self.valid_address_yes_option)
                status &= False
            sleep(3)
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.valid_mail_check):
                status &= True
                log.info("Send Mail has been checked Yes  " )
            else:
                log.error("Send Mail has not been checked Yes  ")
                self.wait_for_element(self.valid_mail_yes_option)
                status &= self.click(*self.valid_mail_yes_option)
                status &= False
            sleep(3)
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.mail_status_update_pop_up):
                status &= True
                log.info("Send Mail has been updated pop up shown  " )
            else:
                log.error("Send Mail has not been updated pop up not shown  ")
                status &= False
            sleep(3)
            self.wait_for_page_load_complete()
            # editing phone number details
            self.wait_for_element(self.add_phone_no_button)
            status &= self.click(*self.add_phone_no_button)
            self.wait_for_element(self.phone_number_input_box)
            self.enter(phone_no, *self.phone_number_input_box)
            self.wait_for_element(self.phone_no_type_dropdown)
            status &= self.click(*self.phone_no_type_dropdown)
            sleep(2)
            self.wait_for_element(self.phone_no_type_home)
            status &= self.click(*self.phone_no_type_home)
            self.wait_for_element(self.save_phone_no_button)
            status &= self.click(*self.save_phone_no_button)
            sleep(5)
            self.wait_for_element(self.delete_new_phone_no_button)
            status &= self.click(*self.delete_new_phone_no_button)
            self.wait_for_page_load_complete()
            self.wait_for_element(self.confirm_delete_phone_no_button)
            status &= self.click(*self.confirm_delete_phone_no_button)
            sleep(3)
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.phone_no_delete_update_pop_up):
                status &= True
                log.info("Phone no has been added and deleted  ")
            else:
                log.error("Phone no has not been added and deleted  ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Edited Contact Information details of customer in Profile ")
        except Exception as e:
            log.error("Exception {} occurred while editing contact Information of customer ".format(e))
            status &= False
        return status

    @allure.step("validating contact information of customer in profile ")
    def validating_contact_information_of_customer_in_profile(self, first_name, last_name, address, phone_no, email_id):
        """
          Method to validate contact information details of customer in profile
          :param first_name: first name of customer
          :param last_name: last name of customer
          :param address: address of customer
          :param phone_no: phone number of customer
          :param email_id: email id of customer

        """
        status = True
        try:
            self.wait_for_page_load_complete()
            customer_first_name= self.wait_and_find_ele_by_xpath(
                self.first_name_of_customer.format(first_name))
            if self.ele_displayed(customer_first_name):
                status &= True
                log.info("first name of customer is getting displayed and is " + first_name )
            else:
                log.error("first name of customer is not getting displayed ")
                status &= False

            customer_last_name = self.wait_and_find_ele_by_xpath(
                self.last_name_of_customer.format(last_name))
            if self.ele_displayed(customer_last_name):
                status &= True
                log.info("last name of customer is getting displayed and is " + last_name)
            else:
                log.error("last name of customer is not getting displayed ")
                status &= False
            self.scroll_to_element(*self.addresses_heading)
            customer_address = self.wait_and_find_ele_by_xpath(
                self.address_detail.format(address))
            if self.ele_displayed(customer_address):
                status &= True
                log.info("address of customer is getting displayed and is " + address)
            else:
                log.error("address of customer is not getting displayed ")
                status &= False

            customer_phone_no = self.wait_and_find_ele_by_xpath(
                self.phone_number_displayed.format(phone_no))
            if self.ele_displayed(customer_phone_no):
                status &= True
                log.info("Phone no. of customer is getting displayed and is " + str(phone_no))
            else:
                log.error("phone no  of customer is not getting displayed ")
                status &= False
            self.scroll_to_element(*self.email_addresses_heading)
            customer_email = self.wait_and_find_ele_by_xpath(
                self.email_id_being_displayed.format(email_id))
            if self.ele_displayed(customer_email):
                status &= True
                log.info("Email Id of customer is getting displayed and is " + str(email_id))
            else:
                log.error("email id  of customer is not getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Validated contact information of customer getting displayed successfully ")
        except Exception as e:
            log.error(
                "Exception {} occurred while validating contact information of customer detail ".format(e))
            status &= False
        return status



    @allure.step("Navigate to Preference Information Page ")
    def navigate_to_preference_information(self):
        """
                Method to Navigate preference  information page of customer in profile
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            #self.wait_for_element(self.profile_tab_dropdown)
            #status &= self.click(*self.profile_tab_dropdown)
            #sleep(2)
            self.wait_for_element(self.preference_button)
            status &= self.click(*self.preference_button)
            if self.isdisplayed(*self.general_preference_heading):
                status &= True
                log.info(" General Preference Information  getting displayed ")
            else:
                log.error("General Preference  information not  getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Navigated to Preference Information Page in Profile  ")
        except Exception as e:
            log.error("Exception {} occurred while navigating to Preference Information Page in Profile".format(e))
            status &= False
        return status

    @allure.step("Navigate to Household Members  Information Page ")
    def navigate_to_household_members_information(self):
        """
                Method to Navigate Household Members Information  page of customer in profile
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            # self.wait_for_element(self.profile_tab_dropdown)
            # status &= self.click(*self.profile_tab_dropdown)
            # sleep(2)
            self.wait_for_element(self.household_members_button)
            status &= self.click(*self.household_members_button)
            if self.isdisplayed(*self.residential_household_heading):
                status &= True
                log.info(" Residential Household Information  getting displayed ")
            else:
                log.error("Residential Household  information not  getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Navigated to Household Members Detail Page in Profile  ")
        except Exception as e:
            log.error("Exception {} occurred while navigating to Household Member Information Page in Profile".format(e))
            status &= False
        return status

    @allure.step("Navigate to Groups  Information Page ")
    def navigate_to_Groups_information(self):
        """
                Method to Navigate Groups Information  page of customer in profile
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            # self.wait_for_element(self.profile_tab_dropdown)
            # status &= self.click(*self.profile_tab_dropdown)
            # sleep(2)
            self.wait_for_element(self.groups_button)
            status &= self.click(*self.groups_button)
            if self.isdisplayed(*self.rewards_account_heading):
                status &= True
                log.info(" Rewards Account  Information  getting displayed ")
            else:
                log.error("Rewards Account   information not  getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Navigated to Groups Detail Page in Profile  ")
        except Exception as e:
            log.error(
                "Exception {} occurred while navigating to Groups Information Page in Profile".format(e))
            status &= False
        return status

    @allure.step("Navigate to Surveys Information Page ")
    def navigate_to_Surveys_information(self):
        """
                Method to Navigate Surveys page of customer in profile
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            # self.wait_for_element(self.profile_tab_dropdown)
            # status &= self.click(*self.profile_tab_dropdown)
            # sleep(2)
            self.wait_for_element(self.surveys_button)
            status &= self.click(*self.surveys_button)
            if self.isdisplayed(*self.survey_history_heading):
                status &= True
                log.info(" Surveys History Information  getting displayed ")
            else:
                log.error("Surveys History information not  getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Navigated to Surveys Detail Page in Profile  ")
        except Exception as e:
            log.error(
                "Exception {} occurred while navigating to Surveys Information Page in Profile".format(e))
            status &= False
        return status

    @allure.step("Navigate to Pharmacy Information Page ")
    def navigate_to_pharmacy_information_page(self):
        """
                Method to Navigate Pharmacy page of customer in profile
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            # self.wait_for_element(self.profile_tab_dropdown)
            # status &= self.click(*self.profile_tab_dropdown)
            # sleep(2)
            self.wait_for_element(self.pharmacy_button)
            status &= self.click(*self.pharmacy_button)
            if self.isdisplayed(*self.pharmacy_information_heading):
                status &= True
                log.info(" Pharmacy Information  getting displayed ")
            else:
                log.error("Pharmacy information not  getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Navigated to Pharmacy Detail Page in Profile  ")
        except Exception as e:
            log.error(
                "Exception {} occurred while navigating to Pharmacy Information Page in Profile".format(e))
            status &= False
        return status

    @allure.step("Navigate to Pharmacy Information Page ")
    def validating_list_of_customers_for_partial_bar_code(self,partial_id):
        """
                Method to validate if list of customers getting displayed for partial bar code
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            barcode_validation = self.wait_and_find_ele_by_xpath(
                self.search_barcode_heading.format(partial_id))
            if self.ele_displayed(barcode_validation):
                status &= True
                log.info("customer names are being displayed for barcode " +str(partial_id))
            else:
                log.error("no names are being displayed for partial bar code ")
                status &= False
            #no_of_customers = self.get_inner_text(self.count_of_search)
            #need to find a way to print no_of customers
            #log.info(no_of_customers)
            self.wait_for_page_load_complete()
            log.info("Searched and validated successfully using partial bar code  ")
        except Exception as e:
            log.error(
                "Exception {} occurred while searching customers list using partial bar code ".format(e))
            status &= False
        return status



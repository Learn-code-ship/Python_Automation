"""
page object model for Preference page
"""
from time import sleep

import allure
from selenium.webdriver.common.by import By
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class PreferencePage(SeHelperPage):
    """
    Class consists of Profile page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver



    preferences_heading = (By.XPATH,"//p[text()='PREFERENCES']")
    general_preferneces_heading = (By.XPATH,"//p[text()='General Preferences']")
    do_not_contact_checkbox = (By.XPATH,"//input[@id='D']")
    email_checkbox = (By.XPATH,"//input[@id='E']")
    mail_checkbox = (By.XPATH,"//input[@id='M']")
    phone_checkbox = (By.XPATH,"//input[@id='P']")
    pharmacy_mail_checkbox =(By.XPATH,"//input[@id='R']")
    text_checkbox = (By.XPATH,"//input[@id='T']")
    unspecified_checbox = (By.XPATH,"//input[@id='U']")
    program_preferences_heading = (By.XPATH,"//p[text()='Program Preferences']")
    eLabels_checkbox = (By.XPATH,"//input[@id='programPreferences_IsELabels']")
    preferred_method_of_contact_dropdown = (By.XPATH,"//select[@id='preference-dropdown']")
    selecting_method_of_contact_option = "//select[@id='preference-dropdown']//child::option[text()='{}']"
    update_preferences_button = (By.XPATH,"//input[@value='Update Preferences']")
    preferences_updated_pop_up = (By.XPATH,"//span[text()='Preferences have been updated.']")

    @allure.step("General Prefernce page and selecting preferences  ")
    def selecting_general_preference_of_customer(self, contact_type):
        """
        Method to Select General Preference of customer and Method of contact of customer
        param contact_type: E for EMAIL/ M FOR MAIL/P FOR PHONE/ R FOR PHARMACY MAIL/T FOR TEXT /U FOR UNSPECIFIED/D FOR DO NOT CONTACT
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.general_preferneces_heading):
                status &= True
                log.info(" General Preferences of customer are displayed   ")
            else:
                log.error("General Preferences of customer are not displayed  ")
                status &= False
            self.wait_for_element(self.email_checkbox)
            status &= self.click(*self.email_checkbox)
            sleep(2)
            self.wait_for_element(self.mail_checkbox)
            status &= self.click(*self.mail_checkbox)
            self.wait_for_element(self.phone_checkbox)
            status &= self.click(*self.phone_checkbox)
            sleep(2)
            self.wait_for_element(self.pharmacy_mail_checkbox)
            status &= self.click(*self.pharmacy_mail_checkbox)
            sleep(2)
            self.wait_for_element(self.text_checkbox)
            status &= self.click(*self.text_checkbox)
            sleep(2)
            self.wait_for_element(self.unspecified_checbox)
            status &= self.click(*self.unspecified_checbox)
            sleep(2)
            self.wait_for_element(self.preferred_method_of_contact_dropdown)
            status &= self.click(*self.preferred_method_of_contact_dropdown)
            mode_of_contact = self.wait_and_find_ele_by_xpath(
                self.selecting_method_of_contact_option.format(contact_type))
            if self.ele_displayed(mode_of_contact):
                status &= True
                log.info("Mode of contact chosen was  " + contact_type)
                status &= self.click_element(mode_of_contact)
            else:
                log.error("mode of contact chosen isn't displayed or not chosen  ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Selected General Preference and mode of contact ")
        except Exception as e:
            log.error("Exception {} occurred while selected General Preference and selectng mode of contact in Preferences page ".format(e))
            status &= False
        return status

    @allure.step("method to select mode of contact as do not contact in general preferences   ")
    def selecting_method_of_contact_as_do_not_contact(self, contact_type):
        """
        Method to Select General Preference of customer and Method of contact of customer
        param contact_type: D FOR DO NOT CONTACT
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.do_not_contact_checkbox)
            status &= self.click(*self.do_not_contact_checkbox)
            mode_of_contact = self.wait_and_find_ele_by_xpath(
                self.selecting_method_of_contact_option.format(contact_type))
            if self.ele_displayed(mode_of_contact):
                status &= True
                log.info("Mode of contact chosen was  " + contact_type)
                self.wait_for_element(self.do_not_contact_checkbox)
                status &= self.click(*self.do_not_contact_checkbox)
            else:
                log.error("mode of contact chosen isn't displayed or not chosen  ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Selected Mode of Contact as Do not disturb  ")
        except Exception as e:
            log.error("Exception {} occurred while selected General Preference and selectng mode of contact as do not disturb  in Preferences page ".format(e))
            status &= False
        return status

    @allure.step("method to select program preference of customer   ")
    def selecting_program_preference_of_customer(self):
        """
        Method to Select Program Preference of customer
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            if self.isdisplayed(*self.program_preferences_heading):
                status &= True
                log.info("Program preferences are being displayed  ")
            else:
                log.error("Program preferences are not being displayed ")
                status &= False
            self.wait_for_element(self.eLabels_checkbox)
            status &= self.click(*self.eLabels_checkbox)
            self.wait_for_page_load_complete()
            log.info("Selected Program preference of customers  ")
        except Exception as e:
            log.error(
                "Exception {} occurred while selecting program preference of customer in Preferences ".format(
                    e))
            status &= False
        return status


    @allure.step("method to click update preference button  ")
    def clicking_update_preference_button_and_validating_updated_preference(self):
        """
        Method to click on Update Prefrence button in prferences page
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.update_preferences_button)
            status &= self.click(*self.update_preferences_button)
            if self.isdisplayed(*self.preferences_updated_pop_up):
                status &= True
                log.info(" Preferences has been updated  ")
            else:
                log.error("Preferences has not been updated  ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Update Preferences button of preference page succesfully clicked   ")
        except Exception as e:
            log.error(
                "Exception {} occurred while clicking on Update preference button of preference page  ".format(
                    e))
            status &= False
        return status
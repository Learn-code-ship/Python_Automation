"""
page object model for Profile page
"""
import json
import re
from time import sleep
import allure
import pandas as pd
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.by import By


from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class AccountsPage(SeHelperPage):
    """
    Class consists of Profile page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _add_member_btn = (By.XPATH, "//div/a[contains(text(),'Add Member')]")
    _verify_alert_msg = (By.XPATH, "//span[@id='alert' and text()='New member has been added.']")
    _verify_reward_alert = (By.XPATH, "//span[@id='alert' and text()='New rewards account has been added.']")
    _acc_user = (By.XPATH, "//ul[@class='list-inline account-users']//li[text()='Account Users:']")
    _consumer_name_1 = (By.XPATH, "//ul[@class='list-inline account-users']//li[@class='user'][1]/a")
    _consumer_name_2 = (By.XPATH, "//ul[@class='list-inline account-users']//li[@class='user'][2]/a")
    _add_new_acc = (By.XPATH, "//strong[contains(text(),'Add new account?')] ")
    _convert_base_to_pro = (By.XPATH, "//div[@class='content-element-4']//parent::div//following-sibling::div//following-sibling::ul[@class='list-inline account-PrimaryFuelStoreNumber']//following::div[2]//ul[@class='list-inline account-PrimaryStoreNumber']//li[@class='user'][9]//a[text()='Convert to myPerks Pro']")
    _add_member_with_name = "//select[@class='textbox-width Text-Transform textbox-value valid']//option[text()='{}']"

    # Eagle eye section
    _eagle_eye_section = (By.XPATH, "//p[text()='Eagle Eye']")
    _wallet_id = (By.XPATH, "//table[@id='eagleeye-table']//td//b[text()='Wallet Id']//following::span//a")
    _parent_wallet_id = (By.XPATH, "//table[@id='eagleeye-table']//td//b[text()='Parent Id']//following::span[1]")
    _eagle_eye_table = (By.XPATH, "//table[@id='eagleeye-table']")
    _ee_table_header = (By.XPATH, "//table[@id='eagleeye-table']//th")
    _ee_table_row = (By.XPATH, "//table[@id='eagleeye-table']//tr")
    _ee_table_records = (By.XPATH, "//table[@id='eagleeye-table']//td")

    #All Card dropdown section
    _hh_num_all_card_sec = (By.XPATH, "//button[@id='stateFilter']")
    all_card_drop_dwn = (By.XPATH, "//div[@id='activecardsarea']/p[text() = 'All Cards']")
    _all_card_drop_dwn = (By.ID, "activecardsarea")
    _add_cards_btn = (By.XPATH, "//div[@id='element-body-5']//div[@class='element-body-inner'][2]//a")
    _verify_pro_conversion_alert = (By.XPATH, "//span[@id='alert' and text()='Household successfully upgraded to myPerks Pro']")
    _change_card_status = "//select[@cardno='{0}' and @id='cardstatus']//option[text()='{1}']"
    _update_card_status_btn = (By.ID, "UpdateCards")
    _initial_card_status = "//select[@cardno='{0}' and @id='cardstatus']//option"
    _card_status_update_alert = (By.XPATH, "//span[@id='alert' and text()='Card has been updated.']")

    # accounts_tab_dropdown = (By.XPATH, "//span[text()='Accounts']//parent::div")
    # geac_rewards_account_button = "//li[@id='{}']//child::a"
    # geac_rewards_account_74207403_button = (By.XPATH, "//li[@id='74207403']//child::a")  #pass value name and locator in jso file
    # rewards_account_information_heading = (By.XPATH, "//p[text()='Rewards Account Information']")
    # gianteagle_com_accounts_tab_button = (By.XPATH, "//li[@id='gianteagle']//child::a")
    # contact_information_at_glance_heading = (By.XPATH, "//span[text()='CONTACT INFORMATION AT A GLANCE']")
    # add_sep_rewards_account_button = (By.XPATH, "//li[@id='addnewaccounts']//child::a")
    # add_new_account_heading = (By.XPATH, "//p[text()='Add New Account']//preceding-sibling::div//child::p[@class='page-heading']")
    # surveys_button = (By.XPATH, "//li[@id='surveys']//child::a")
    # gianteagle_com_accounts_heading = (By.XPATH,"//span[text()='GIANTEAGLE.COM ACCOUNTS']")
    # profile_tab_link = (By.XPATH,"//a[text()='Profile']")
    # account_information_heading = (By.XPATH,"//p[text()='Account Information - wcuz072@aol.com']")
    # view_email_and_preference_history_button = (By.XPATH,"//input[@value='View Email and Preferences History']")
    # email_address_history_report_close_button = (By.XPATH,"//a[text()='Close']")
    # select_receipt_preference_dropdown = (By.XPATH,"//select[@class='textbox-style-Pref receiptdropdown']")
    # always_print_option = (By.XPATH,"//option[text()='Always print my receipts at the register. I do not want my receipts to be emailed.']")
    # update_receipt_preference_button = (By.XPATH,"//input[@value='Update Receipt Preference']")
    # email_preference_market_district_option = (By.XPATH,"(//input[@class='emailpreference-25445219'])[1]")
    # update_email_preference_button = (By.XPATH,"//input[@value='Update Email Preference']")
    # edit_button_account_information = (By.XPATH,"//input[@value='Edit']")
    # advantage_card_enrolled = (By.XPATH,"//a[text()='400476687116']") # will be passed on json file
    # geac_input_box = (By.XPATH,"//span[text()='GEAC:']//following-sibling::span")
    # wetgo_unlimited_heading = (By.XPATH,"//p[text()='WetGo Unlimited']")
    # wet_go_not_enrolled_status = (By.XPATH,"//span[text()=' NOT CURRENTLY ENROLLED']")


    # @allure.step("Navigate to GEAC Rewards Account Page ")
    # def navigate_to_geac_rewards_account_page(self, rewards_account_id):
    #     """
    #             Method to Navigate Geac Rewards Account page of customer in Accounts          """
    #     status = True
    #     try:
    #         self.wait_for_page_load_complete()
    #         rewards_account_button = self.wait_and_find_ele_by_xpath(
    #             self.geac_rewards_account_button.format(rewards_account_id))
    #         self.wait_for_element(rewards_account_button)
    #         status &= self.click_element(rewards_account_button)
    #         self.wait_for_page_load_complete()
    #         if self.isdisplayed(*self.rewards_account_information_heading):
    #             status &= True
    #             log.info("Navigated to GEAC Rewards Account page and Account Information getting displayed ")
    #         else:
    #             log.error("Failed to navigate to GEAC Rewards Account page and Account Information getting displayed")
    #             status &= False
    #         self.wait_for_page_load_complete()
    #         log.info("Navigated to GEAC Rewards Account in Accounts ")
    #     except Exception as e:
    #         log.error("Exception {} occurred while navigating to GEAC Rewards Accounts ".format(e))
    #         status &= False
    #     return status
    #
    # @allure.step("Navigate to GiantEagle.com Accounts Page ")
    # def navigate_to_gianteagle_com_accouts_page(self):
    #     """
    #             Method to Navigate to GiantEagle.com Accounts  page of customer in Accounts
    #             """
    #     status = True
    #     try:
    #         self.wait_for_page_load_complete()
    #         self.wait_for_element(self.gianteagle_com_accounts_tab_button)
    #         status &= self.click(*self.gianteagle_com_accounts_tab_button)
    #         if self.isdisplayed(*self.contact_information_at_glance_heading):
    #             status &= True
    #             log.info(" Contact Information of customer  getting displayed ")
    #         else:
    #             log.error("Contact information not  getting displayed ")
    #             status &= False
    #         self.wait_for_page_load_complete()
    #         log.info("Navigated to GiantEagle.com Accounts Page in Profile  ")
    #     except Exception as e:
    #         log.error("Exception {} occurred while navigating to GiantEagle.com Accounts Page in Profile".format(e))
    #         status &= False
    #     return status
    #
    # @allure.step("Navigate to Ad Sep Rewards Account Page ")
    # def navigate_to_add_sep_rewards_account_page(self):
    #     """
    #             Method to Navigate Add Sep Rewards Account  page of customer in Accounts
    #             """
    #     status = True
    #     try:
    #         self.wait_for_page_load_complete()
    #         self.wait_for_element(self.add_sep_rewards_account_button)
    #         status &= self.click(*self.add_sep_rewards_account_button)
    #         if self.isdisplayed(*self.add_new_account_heading):
    #             status &= True
    #             log.info(" Add New Account heading and options to add new account being displayed   ")
    #         else:
    #             log.error("Add New Account heading and options to add new account not  being displayed")
    #             status &= False
    #         self.wait_for_page_load_complete()
    #         log.info("Navigated to Add  Sep Rewards Account Page in Accounts ")
    #     except Exception as e:
    #         log.error("Exception {} occurred while navigating to Add Sep Rewards Acount Page in Profile".format(e))
    #         status &= False
    #     return status

    @allure.step("click on the All cards drop down")
    def click_on_all_cards_drop_down(self):
        """
        Method to click on the All cards drop down
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self.all_card_drop_dwn)
            status &= self.click(*self.all_card_drop_dwn)
            log.info(" All cards drop down clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on all cards drop down button".format(e))
            status &= False
        return status

    @allure.step("click on the eagle eye section for the new member card")
    def click_on_eagle_eye_sec(self):
        """
        Method to click on the eagle eye section for the new member card
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._eagle_eye_section)
            status &= self.click(*self._eagle_eye_section)
            log.info("all cards section clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on all cards section".format(e))
            status &= False
        return status

    @allure.step("extract walletid, household, parent id from eagle eye section for the new member card")
    def extract_walletid_hh_num_parentid_ui(self):
        """
        Method to extract walletid, household, parent id from eagle eye section for the new member card
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            wallet_id = self.get_text(*self._wallet_id)
            log.info("Wallet id is : {}".format(wallet_id))
            parent_wallet_id = self.get_text(*self._parent_wallet_id)
            num = re.findall(r'\d+', parent_wallet_id)
            parent_wallet_id_hh_num = ','.join(num)
            parent_wallet_id = parent_wallet_id_hh_num.split(",")[0]
            log.info("parent_wallet_id is : {}".format(parent_wallet_id))
            hh_num = parent_wallet_id_hh_num.split(",")[1]
            log.info("hh_num is : {}".format(hh_num))
        except Exception as e:
            log.error("Exception {} occurred while extracting the walletid, household, parent id from eagle eye section".format(e))
            status &= False
        return status, wallet_id, parent_wallet_id, hh_num

    @allure.step("extract walletid, household, parent id from eagle eye section for the new member card as data frame")
    def extract_eagle_eye_section(self):
        """
        Method to extract walletid, household, parent id from eagle eye section for the new member card
        :return: status - Boolean True or False
        """
        status = True
        new_json_data = ''
        try:
            pattern = r'<[^>]*class="tablesaw-cell-label"[^>]*>.*?</[^>]*>'
            table = self.find_element(*self._eagle_eye_table)
            table_html = table.get_attribute('outerHTML')
            modified_html = re.sub(pattern, '', table_html)
            df = pd.read_html(modified_html, header=0)[0]
            json_data = df.to_json(orient="records")
            json_data = json.loads(json_data)
            new_json_data = self.seperate_consumers(json_data)
        except Exception as e:
            log.error("Exception {} occurred while extracting the walletid, household, parent id from eagle eye section".format(
                    e))
            status &= False
        return status, new_json_data

    @allure.step("extract walletid, household, parent id from eagle eye section for the new member card")
    def seperate_consumers(self, json_data):
        """
        Method to extract walletid, household, parent id from eagle eye section for the new member card
        :param: json_data
        :return: status - Boolean True or False
        """
        status = True
        ee_new_json_data = []
        try:
            for records in json_data:
                rm_card_space = (records['Enrolled Cards'].rstrip(',')).replace(', ', ',').replace(' ', ' ')
                sep_cards = rm_card_space.split(', ')
                splitted_cards = []
                for data in sep_cards:
                    card_no = data.split(' ')[0]
                    status = re.sub(r'[()]', '', data).split(' ')[1]
                    splitted_cards.append({'card_no': card_no, 'status': status})
                cw_wallet_id = records['Wallet Id'].split('Created')[0]
                log.info("Consumer wallet id is - {0}".format(cw_wallet_id))
                parent_id = records['Parent Id']
                num = re.findall(r'\d+', parent_id)
                parent_id_hh_num = ','.join(num)
                parent_wallet_id = parent_id_hh_num.split(",")[0]
                log.info("Parent wallet id is - {0}".format(parent_wallet_id))
                hh_num = parent_id_hh_num.split(",")[1]
                log.info("hh_num is - {0}".format(hh_num))
                name = records['Name']
                log.info("name is - {0}".format(name))
                reward_tier = records['Reward Tier']
                log.info("reward_tier is - {0}".format(reward_tier))
                tm = records['TM']
                log.info("tm is - {0}".format(tm))
                vip = records['VIP']
                log.info("vip is - {0}".format(vip))
                dig_engaged = records['Dig Engaged']
                log.info("dig_engaged is - {0}".format(dig_engaged))
                enrolled_cards = splitted_cards
                ee_new_json_data.append({
                    "WalletId": cw_wallet_id,
                    "ParentId": parent_wallet_id,
                    "hh_num": hh_num,
                    "Name": name,
                    "RewardTier": reward_tier,
                    "TM": tm,
                    "VIP": vip,
                    "Dig Engaged": dig_engaged,
                    "Enrolled Cards": enrolled_cards,
                })
        except Exception as e:
            log.error(
                "Exception {} occurred while extracting all the values from eagle eye section".format(e))
            status &= False
        return ee_new_json_data

    def validate_svoc_db_ee_ui_ee_api(self, result_set_svoc_db, result_set_ui, result_set_api):
        """
        Method to validate ui and api
        :param: ui - wallet_id_ui, parent_walletid_ui, hh_num_ui
        :param: api - wallet_id, parent_walletid, hh_num
        :return: results
        """
        status = False
        try:
            if len(result_set_svoc_db) == len(result_set_ui) == len(result_set_api):
                log.info(f"The count of svoc records fetched from db count={len(result_set_svoc_db)} matches with count of cards present in eagle eye section in svoc ui count={len(result_set_ui)} and matches with ee response count={len(result_set_api)}")
            for obj1 in result_set_svoc_db:
                for obj2 in result_set_ui:
                    for obj3 in result_set_api:
                        if obj1 == obj3["value"] == obj2["enrolled_cards"]:
                            log.info("the svoc ui card {0} and the  api response {1} card number matches successfully".format(
                                  obj2["enrolled_cards"], obj3["value"]))
                status = True
        except Exception as e:
            log.error("Exception occured - {} while validating svoc ui vs eagle eye api's geac cards".format(e))
            status = False
        return status

    @allure.step("extract  household number from the svoc screen" )
    def extract_hh_num_from_svoc_ui(self):
        """
        Method to extract household from the svoc screen
        :return: status - Boolean True or False
        """
        status = True
        hh_num = ' '
        try:
            self.wait_for_page_load_complete()
            household_num = self.get_text(*self._hh_num_all_card_sec)
            hh_num = household_num.split("Household ")[1]
            log.info("hh_num is : {}".format(hh_num))
        except Exception as e:
            log.error("Exception {} occurred while extracting the walletid, household, parent id from eagle eye section".format(e))
            status &= False
        return status, hh_num

    @allure.step("click on add member button to add the new consumer ")
    def click_add_member_btn(self):
        """
        Method to click on the add member button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._add_member_btn)
            status &= self.click(*self._add_member_btn)
            log.info("add member button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on add member button".format(e))
            status &= False
        return status

    @allure.step("Verify the new member added into svoc")
    def verify_new_member_added(self):
        """
        Method to validate new member added  message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._verify_alert_msg)
            log.info("new member has been added message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying new member has been added message")
            status &= False
        return status

    @allure.step("Verify the new reward account member added into svoc")
    def verify_new_reward_acc_member_added(self):
        """
        Method to validate new member added  message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._verify_reward_alert)
            log.info("new reward account member has been added message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying new reward account member has been added message")
            status &= False
        return status

    @allure.step("Verify the new member added into svoc")
    def verify_acc_users(self, fn, ln, fn1, ln1):
        """
        Method to validate new member added  message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            consumer_name_1 = self.get_text(*self._consumer_name_1)
            if consumer_name_1 == fn+ '' + ln:
                log.info("validated the first account user successfully")
            consumer_name_2 = self.get_text(*self._consumer_name_2)
            if consumer_name_2 == fn1 + '' + ln1:
                log.info("validated the second account user successfully")
        except Exception as e:
            log.error(
                "Exception {} occurred while validating first and second account user".format(
                    e))
            status &= False
        return status

    @allure.step("Use this method during switch between windows click on the All cards drop down")
    def click_on_all_cards(self):
        """
        Method to Use this method during switch between windows click on the All cards drop down
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._all_card_drop_dwn)
            self.custom_time_wait(10)
            status &= self.click(*self._all_card_drop_dwn)
            log.info(" All cards drop down clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on all cards drop down button".format(e))
            status &= False
        return status

    @allure.step("click on Add cards from All cards drop down")
    def click_on_add_btn_from_all_cards(self):
        """
        Method to click on Add cards from All cards drop down
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._add_cards_btn)
            self.custom_time_wait(2)
            status &= self.click(*self._add_cards_btn)
            log.info("Add cards button from All cards drop down clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on Add cards button from all cards drop down section".format(e))
            status &= False
        return status

    @allure.step("convert myperks to myperks pro")
    def convert_myperksbase_to_pro(self):
        """
        Method to convert myperks to myperks pro
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_up_element(*self._convert_base_to_pro)
            self.scroll_to_element(*self._convert_base_to_pro)
            status &= self.click_using_javascript(*self._convert_base_to_pro)
            alert = Alert(self.driver)
            text_alert = alert.text
            if text_alert == "Upgrade this customer to myPerks Pro?":
                log.info("Upgrade this customer to myPerks Pro? alert window displayed")
                alert.accept()
                log.info("clicked on 'Convert myperks base to myperks pro' successfully")
            else:
                log.error("alert window didn't popup")
        except Exception as e:
            log.error("Exception {} occurred while clicking on Converting myperks base to myperks pro".format(e))
            status &= False
        return status

    @allure.step("Verify the myperks base member converted into myperks pro in svoc")
    def verify_pro_conversion_alert(self):
        """
        Method to validate the myperks base member converted into myperks pro in svoc
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.page_refresh()
            status &= self.isdisplayed(*self._verify_pro_conversion_alert)
            log.info("'Household successfully upgraded to myPerks Pro' message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying 'Household successfully upgraded to myPerks Pro' message")
            status &= False
        return status

    @allure.step("Change the geac card status from all card section")
    def change_geac_card_status(self, geac_no, card_status):
        """
        Method to Change the geac card status from all card section in svoc
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            _card_status = self.wait_and_find_ele_by_xpath(self._change_card_status.format(geac_no, card_status))
            _bfr_card_status = self.wait_and_find_ele_by_xpath(self._initial_card_status.format(geac_no))
            _current_card_status = self.get_inner_text(_bfr_card_status)
            self.click_element(_card_status)
            log.info(f"The cardno-{geac_no} with status as - {_current_card_status} changed to status - {card_status} successfully")
        except Exception as e:
            log.error(
                "Exception {0} occurred while changing the card status for the geac {1})".format(e, geac_no))
            status &= False
        return status

    @allure.step("This method is used to update the card status")
    def click_on_update_card_status(self):
        """
        Method to This method is used to update the card status
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._update_card_status_btn)
            status &= self.click_using_javascript(*self._update_card_status_btn)
            log.info("update the card status is clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on update the card status button".format(e))
            status &= False
        return status

    @allure.step("Verify card status change alert into svoc")
    def verify_card_status_change_alert(self):
        """
        Method to validate card status change alert message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.page_refresh()
            status &= self.isdisplayed(*self._card_status_update_alert)
            log.info("card status change alert message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying card status change alert message")
            status &= False
        return status

    @allure.step("Change the geac card status from all card section")
    def change_all_card_geac_card_status(self, geac_no, card_status):
        """
        Method to Change the geac card status from all card section in svoc
        :return: status - Boolean True or False
        """
        status = True
        try:
            for card in geac_no:
                self.wait_for_page_load_complete()
                _card_status = self.wait_and_find_ele_by_xpath(self._change_card_status.format(card, card_status))
                _bfr_card_status = self.wait_and_find_ele_by_xpath(self._initial_card_status.format(card))
                _current_card_status = self.get_inner_text(_bfr_card_status)
                self.click_element(_card_status)
                log.info(
                f"The cardno-{card} with status as - {_current_card_status} changed to status - {card_status} successfully")
        except Exception as e:
            log.error(
                "Exception {0} occurred while changing the card status for the geac {1})".format(e, card))
            status &= False
        return status






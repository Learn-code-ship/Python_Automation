"""
page object model for Home page
"""
from time import sleep
import allure
from selenium.webdriver.common.by import By
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class HomePage(SeHelperPage):
    """
    Class consists of Home page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    close_advance_search_page_button = (By.XPATH,"(//button[text()='Close'])[1]")
    navigator_link = (By.CSS_SELECTOR, 'a[title="Navigator"]')
    employee_login_welcome_heading = (By.XPATH, "//span[text()='Welcome,']//parent::h3")
    emp_display = (By.XPATH, "//span[text()='Welcome,']//parent::h3//span[contains(text(), 'Welcome,')]")
    _logo_page = (By.ID, "leaveCustomer")
    _pop_up_screen = (By.XPATH, "//strong[text()='Be sure to save any changes before leaving.']")
    _yes_leave_page_btn =(By.XPATH, "//input[@value='Yes, leave this page']")
    _no_leave_page_btn = (By.XPATH, "//input[@value='No, return me to the previous page")


    @allure.step("Verify the home page of svoc")
    def verify_home_page(self):
        """
        Method to verify the home page of svoc
        :return: status - Boolean True or False
        """
        global user_id
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self.close_advance_search_page_button)
            user_id = self.get_text(*self.employee_login_welcome_heading)
            if self.ele_displayed(self.find_element(*self.emp_display)):
                log.info("Home page getting displayed and successfully logged in with user id is {}".format(user_id))
            else:
                log.error("Home page not getting displayed and successfully loged in with employee id")
        except Exception as e:
            log.error(f"Exception {e} occurred while navigating to home page user id is {user_id}")
            status &= False
        return status

    @allure.step("click on the logo pages of svoc")
    def click_logo_page(self):
        """
        Method to click on the logo pages of svoc
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._logo_page)
            log.info("clicked on the logo of the svoc screen successfully")
        except Exception as e:
            log.error(f"Exception {e} occurred while clicking on the logo of the svoc screen")
            status &= False
        return status

    @allure.step("Verify leaving this pop screen page")
    def verify_leaving_this_page_popup(self):
        """
        Method to verify the home page of svoc
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if self.ele_displayed(self.find_element(*self._pop_up_screen)):
                 log.info("Be sure to save any changes before leaving screen is displayed ")
            else:
                log.error("Be sure to save any changes before leaving screen is not displayed")
        except Exception as e:
            log.error(f"Exception {e} occurred while verifying the leaving screen")
            status &= False
        return status

    @allure.step("click on yes leave button")
    def click_yes_leave_btn(self):
        """
        Method to click on yes leave button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._yes_leave_page_btn)
            status &= self.click(*self._yes_leave_page_btn)
            log.info("seperation button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on seperation button".format(e))
            status &= False
        return status

    @allure.step("click on cancel separate button ")
    def click_cancel_separate_btn(self):
        """
        Method to click on cancel separate button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._no_leave_page_btn)
            status &= self.click(*self._no_leave_page_btn)
            log.info("cancel seperation button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on cancel seperation button".format(e))
            status &= False
        return status

    @allure.step("switch to new window")
    def switch_new_window(self):
        """
        Method to open new window
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.open_and_switch_to_new_tab()
            log.info("opened new window successfully")
        except Exception as e:
            log.error("Exception {} occurred while opening new window".format(e))
            status &= False
        return status

    @allure.step("switch to first account")
    def switch_to_first_account(self):
        """
        Method to open new window
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.switch_to_window_by_number(0)
            self.page_refresh()
            log.info("switched to first account successfully")
        except Exception as e:
            log.error("Exception {} occurred while switching to first account window".format(e))
            status &= False
        return status

    @allure.step("validate consumers before and after seperation")
    def validate_consumer_sep(self, old_details, new_details):
        """
        Method to check the seperated consumer here , consumers before and after seperation
        :return: status - Boolean True or False
        """
        status = True
        try:
            for val in old_details:
                if val["individual_id"] == new_details[0]["individual_id"]:
                    log.info(f"Old card {val['CardNumber']} for consumer - {val['firstName']} {val['lastName']} is replaced with new card number-{new_details[0]['CardNumber']}")
                    break
        except Exception as e:
            log.error("Exception {} occurred while switching to first account window".format(e))
            status &= False
        return status, (val['CardNumber'])







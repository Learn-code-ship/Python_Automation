"""
page object model for Profile page
"""
import json
import re
from time import sleep
import allure
import pandas as pd
from selenium.webdriver.common.by import By


from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log
from Marketing_apps.EagleEyeApi.services.wallet.wallet_apis import WalletApi
from Marketing_apps.EagleEyeApi.services.identities.identity_apis import IdentityApi
from Marketing_apps.EagleEyeApi.services.consumer.consumer_apis import ConsumerApi


class MergeAndSplitPages(SeHelperPage):
    """
    Class consists of merge and split methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    """split web elements"""
    _consumer_name_1 = (By.XPATH, "//ul[@class='list-inline account-users']//li[@class='user'][1]/a")
    _consumer_name_2 = (By.XPATH, "//ul[@class='list-inline account-users']//li[@class='user'][2]/a")
    _intiate_seperation_btn = (By.ID, "initiateSeparation")
    _sep_screen = (By.XPATH, "//div//p[text()='Initiate Separation']")
    _seperation_btn = (By.ID, "separate")
    _cancel_sep_btn_initiation = (By.ID, "Cancel")
    _add_new_acc = (By.XPATH, "//strong[contains(text(),'Add new account?')] ")
    _exsting_address_btn = (By.XPATH, "//input[@value='Use existing address?']")
    _new_address_btn = (By.XPATH, "//input[@value='Use new address?']")
    _cancel_sep_btn = (By.XPATH, "//div//a[text()='Cancel']")
    _verify_alert_msg_sep = (By.XPATH, "//span[@id='alert' and text()='Rewards account separation completed.']")
    _merge_pop_up_screen = (By.XPATH, "//div[@id='myModal']//div//h3[2]//following::strong[contains(text(),'Do you want to merge these accounts?')]")

    """Merge web elements"""
    merge_accounts_button = (By.XPATH, "//li[@id='mergeaccounts']//child::a")
    merge_account_heading = (By.XPATH, "//p[text()='Merge Accounts']")
    _from_acc_drop_down = (By.ID, "fromAccount")
    _destination_acc = (By.ID, "DestinationAccount")
    _keep_individual_field = (By.ID, "KeepIndividualDropdownList")
    _keep_individual_drop_down = "//select[@id='KeepIndividualDropdownList']//option[@value='{}']"
    _replace_id = "ReplaceExistingIndividual"
    _next_merge_acc_btn = (By.ID, "MergeAccounts")
    _yes_merge_btn = (By.XPATH, "//input[@name='Merge']")
    _cancel_merge_btn = (By.ID, "NotMerge")
    _verify_alert_merge_msg = (By.XPATH, "//span[@id='alert' and text()='Account has been merged.']")
    _household_merge_alert_msg = (By.XPATH, "//div[@id='agent-alert']//p")
    _merge_alert_notification = (By.XPATH, "//span[contains(text(),'Cannot merge accounts.  Source and destination households are the same.')]")


    @allure.step("Navigate to merge accounts Page and verify the merge account screen")
    def navigate_to_merge_accounts(self):
        """
        Method to Navigate to Merge Accounts page and verify the merge account screen customer in Accounts
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.merge_accounts_button)
            status &= self.click(*self.merge_accounts_button)
            if self.isdisplayed(*self.merge_account_heading):
                status &= True
                log.info(" Merge Accounts heading getting displayed ")
            else:
                log.error("Merge Account heading  not  getting displayed ")
                status &= False
            self.wait_for_page_load_complete()
            log.info("Navigated to Merge Accounts page in Accounts  ")
        except Exception as e:
            log.error(
                "Exception {} occurred while navigating to Merge Accounts Page in Accounts".format(e))
            status &= False
        return status

    @allure.step("click on initiate seperation button")
    def click_initiate_seperation_btn(self):
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._intiate_seperation_btn)
            status &= self.click(*self._intiate_seperation_btn)
            log.info("seperation button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on initiate seperation button".format(e))
            status &= False
        return status

    @allure.step("Verify the initiate seperation page in svoc")
    def verify_initiate_seperation_screen(self):
        """
        Method to Verify the initiate seperation page in svoc
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._sep_screen)
            log.info("initiate seperation page displayed ")
        except Exception as e:
            log.error("Exception {0} occurred while displaying initiate seperation page")
            status &= False
        return status

    @allure.step("click on seperation button")
    def click_seperation_btn(self):
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._seperation_btn)
            status &= self.click(*self._seperation_btn)
            log.info("seperation button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on seperation button".format(e))
            status &= False
        return status

    @allure.step("click on cancel separate button ")
    def click_cancel_separate_btn(self):
        """
        Method to click on cancel separate button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._cancel_sep_btn_initiation)
            status &= self.click(*self._cancel_sep_btn_initiation)
            log.info("cancel seperation button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on cancel seperation button".format(e))
            status &= False
        return status

    @allure.step("click existing address button")
    def click_use_existing_address_btn(self):
        """
        Method to click existing address button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._exsting_address_btn)
            status &= self.click(*self._exsting_address_btn)
            log.info("existing address button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on existing address button".format(e))
            status &= False
        return status

    @allure.step("click use new address button")
    def click_use_new_address_btn(self):
        """
        Method to click use new address button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._new_address_btn)
            status &= self.click(*self._new_address_btn)
            log.info("use new address button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on use new address button".format(e))
            status &= False
        return status

    @allure.step("click cancel seperation button")
    def click_cancel_sep_btn(self):
        """
        Method to click cancel seperation button while adding address
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._cancel_sep_btn)
            status &= self.click(*self._cancel_sep_btn)
            log.info("cancel seperation button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on cancel seperation button".format(e))
            status &= False
        return status

    @allure.step("Verify the Rewards account separation completed in svoc")
    def verify_reward_member_seperation_alert_(self):
        """
        Method to validate new member added  message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._verify_alert_msg_sep)
            log.info("Rewards account separation completed message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying Rewards account separation completed message")
            status &= False
        return status

    @allure.step("extract value from account merge svoc screen")
    def extract_hh_value_merge_from_acc(self):
        """
        Method to extract value from account merge svoc screen
        :return: status - Boolean True or False
        """
        status = True
        hh_num = ' '
        try:
            self.wait_for_page_load_complete()
            household_num = self.get_text(*self._from_acc_drop_down)
            hh_num = household_num.split(" ")[1]
            log.info("merge from hh_num is : {}".format(hh_num))
        except Exception as e:
            log.error(
                "Exception {} occurred while extracting the value from account merge svoc screen".format(e))
            status &= False
        return status, hh_num

    @allure.step("Enter the geac number to Account field to merge")
    def enter_geacno_destination_field(self, geac_no):
        """
        Method to Enter the geac number to Account field to merge
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.enter(geac_no, *self._destination_acc)
            log.info(f"Destination card number entered in the To ACCount field- {geac_no}")
        except Exception as e:
            log.error(
                "Exception {} occurred while selecting the value from individual value".format(e))
            status &= False
        return status

    @allure.step("click merge account button")
    def click_next_merge_acc_btn(self):
        """
        Method to click merge account next button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._next_merge_acc_btn)
            status &= self.click(*self._next_merge_acc_btn)
            log.info("next merge account button clicked successfully")
            self.custom_time_wait(5)
        except Exception as e:
            log.error("Exception {} occurred while clicking on next merge account button".format(e))
            status &= False
        return status

    @allure.step("Verify the merge pop up screen")
    def verify_merge_popup_screen(self):
        """
        Method to Verify the merge pop up screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._merge_pop_up_screen)
            log.info("merge pop up screen displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying merge pop up screen".format(e))
            status &= False
        return status

    @allure.step("click yes merge account button")
    def click_yes_merge_acc_btn(self):
        """
        Method to click merge yes account button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._yes_merge_btn)
            status &= self.click(*self._yes_merge_btn)
            log.info("yes merge button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on yes merge button".format(e))
            status &= False
        return status

    @allure.step("click cancel merge account button")
    def click_cancel_merge_acc_btn(self):
        """
        Method to click merge cancel account button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._cancel_merge_btn)
            status &= self.click(*self._cancel_merge_btn)
            log.info("cancel merge button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on cancel merge button".format(e))
            status &= False
        return status

    @allure.step("Verify the merge account completed in svoc")
    def verify_merge_acc_alert(self):
        """
        Method to validate new member added  message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._verify_alert_merge_msg)
            log.info("Account has been merged message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying Account has been merged message")
            status &= False
        return status

    @allure.step("Verify the household merge alert in svoc")
    def verify_houshold_merge_alert(self):
        """
        Method to Verify the household merge alert in svoc message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._household_merge_alert_msg)
            alert_msg = self.get_text(*self._household_merge_alert_msg)
            log.info(f"message {alert_msg} displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying household from to merge message display")
            status &= False
        return status

    @allure.description("Validate eagle eye consumers before and after seperation/merge")
    def validate_ee_consumers_info(self, old_consumers_details, new_consumers_details, process):
        """
        Method to Validate eagle eye consumers before and after seperation/merge
        :return: status - Boolean True or False
        """
        status = True
        try:
            status, cw = WalletApi().validate_ee_consumers_wallet(old_consumers_details, new_consumers_details)
            if cw == 2:
                if process == 'split':
                    IdentityApi().validate_ee_consumers_identities_split(old_consumers_details, new_consumers_details)
                else:
                    IdentityApi().validate_ee_consumers_identities_merge(old_consumers_details, new_consumers_details)
                ConsumerApi().validate_ee_consumerid(old_consumers_details, new_consumers_details)
            else:
                log.error("2 consumers wallet don't match hence this ee entire validation check failed")
                status = False
        except Exception as e:
            log.error("Exception {} occurred while validating eagle eye consumers before and after".format(e))
            status &= False
        return status

    @allure.step("Verify the merge alert same source and destination accounts in svoc")
    def verify_merge_alert_source_dest_same(self):
        """
        Method to Verify the merge alert source and destination accounts
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._merge_alert_notification)
            log.info("Cannot merge accounts.Source and destination households are the same. message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying merge alert source and destination accounts message")
            status &= False
        return status




"""
page object model for Household Members  page
"""
from time import sleep

import allure
from selenium.webdriver.common.by import By
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class HouseholdMembersPage(SeHelperPage):
    """
    Class consists of Profile page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver




    residential_household_heading = (By.XPATH,"// p[text() = 'Residential Household']")
    address_displayed = (By.XPATH,"//p[text()=' 615 Queen  Street  ']")
    household_member_url = (By.XPATH,"//span[text()='HOUSEHOLD MEMBERS']//parent::div//parent::div//parent::div//child::a")
    basic_information_heading = (By.XPATH,"//p[text()='Basic Information']")
    customer_name = "//span[text()='{}']"

    @allure.step("method to select mode of contact as do not contact in general preferences")
    def clicking_on_household_members_and_validating(self, first_name):
        """
        Method to Select General Preference of customer and Method of contact of customer
        param contact_type: D FOR DO NOT CONTACT
                """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.household_member_url)
            status &= self.click(*self.household_member_url)
            sleep(5)
            self.wait_for_page_load_complete()
            sleep(5)
            #self.open_and_switch_to_new_tab()
            #customer_first_name = self.wait_and_find_ele_by_xpath(self.customer_name.format(first_name)
            '''
            try:
                if self.isdisplayed(*self.basic_information_heading):
                    status &= True
                    log.info("Basic Information heading has been displayed and navigated to contact information page ")
                else:
                    log.error("Failed to redirect to contact information page by clicking on household member name  ")
                    status &= False
            except Exception as e:
                log.error(
                    "Exception {} occurred while checking houshehold member details in new tab".format(e))
                status &= False
                '''
            '''
            if self.ele_displayed(customer_first_name):
                status &= True
                log.info("Customer name and details are being displayed ")
            else:
                log.error("Customer name and details are not being displayed   ")
                status &= False
                '''
            self.close_current_tab()
            self.wait_for_page_load_complete()
            log.info("Navigated to Household Members Page and clicked on household member ")
        except Exception as e:
            log.error("Exception {} occurred while checking household members in Household Members Page  ".format(e))
            status &= False
        return status


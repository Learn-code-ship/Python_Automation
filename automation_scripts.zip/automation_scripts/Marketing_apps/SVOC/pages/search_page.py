"""
page object model for Home page
"""
import time
from time import sleep

import allure
from selenium.webdriver.common.by import By
from encryption import utils_encrypter
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class SearchPage(SeHelperPage):
    """
    Class consists of Search page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    advance_search_button = (By.XPATH, "//button[text()='Advanced Search']")
    advance_search_pop_up = (By.XPATH, "//h4[text()='Advanced Search']")
    bar_code_input_textbox = (By.XPATH, "//div[text()='Bar Code#']//following-sibling::div//child::input")
    _search_button = (By.ID, "AdvancedSearch")
    _clear_button = (By.ID, "ClearAdvancedSearch")
    _close_button = (By.XPATH, "//div[@class='modal-footer']/button[text()='Close']")
    first_name_input_box = (By.XPATH,"//input[@name='mFirstName']")
    last_name_input_box = (By.XPATH,"//input[@name='mLastName']")
    email_box = (By.NAME, "mEmail")
    account_field = (By.XPATH, "//div[@class='select-area bottom-padding']//child::div[contains(@class, 'accounts-box')]")
    value_account = (By.XPATH, "//div[contains(@class, 'accounts-box')]//child::ul/li[1]/a")
    household_num_box = (By.NAME, "mHousehold")
    phone_num_box = (By.NAME, "mPhone")


    #resulted screen from search
    resulted_name = (By.XPATH, "//div[@class='cust-info-header']//p")
    registered_card = (By.XPATH, "//input[contains(@id,'GeacNumber-')]")
    resulted_mailid = (By.ID, "EmailAddress")
    resulted_household_num_box = (By.XPATH, "//button[@id = 'stateFilter']")
    resulted_phone_num_box = (By.XPATH, "//div[@class='content text-center cust-info-main-content']/div[1]/span[2]")


    @allure.step("click on the advanced search button")
    def click_on_advance_search(self):
        """
        Method to click on the advanced search button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self.advance_search_button)
            log.info("Advanced search button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on advanced search button".format(e))
            status &= False
        return status

    @allure.step("Verify the advanced search pop up")
    def verify_advance_search_popup(self):
        """
        Method to Verify the advanced search pop up
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self.advance_search_pop_up)
            log.info("Advanced search pop up displayed successfully")
        except Exception as e:
            log.error("Exception {} occurred while displaying on advanced search popup".format(e))
            status &= False
        return status

    @allure.step("search with barcode / geac card number")
    def search_with_barcode(self, card_no):
        """
        Method to search with barcode / geac card number
        :param:card_no
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.enter(card_no, *self.bar_code_input_textbox)
            log.info("Entered the card no successfully ")
        except Exception as e:
            log.error("Exception {} occurred while entering the card num on advanced search popup".format(e))
            status &= False
        return status

    @allure.step("click on the search button in advanced search pop up")
    def click_search_button(self):
        """
        Method to click on the search button in advanced search pop up
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._search_button)
            status &= self.click(*self._search_button)
            self.custom_time_wait(5)
            log.info("search button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on search button".format(e))
            status &= False
        return status

    @allure.step("click on the clear button in advanced search pop up")
    def click_clear_button(self):
        """
        Method to click on the clear button in advanced search pop up
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._clear_button)
            status &= self.click(*self._clear_button)
            log.info("clear button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on clear button".format(e))
            status &= False
        return status

    @allure.step("click on the close button in advanced search pop up")
    def click_close_button(self):
        """
        Method to click on the close button in advanced search pop up
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._close_button)
            status &= self.click(*self._close_button)
            log.info("close button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on close button".format(e))
            status &= False
        return status

    @allure.step("Validate the search with barcode")
    def validate_search_with_barcode(self, card_no):
        """
        Method to Validate the search with barcode
        :param: card_no
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self.registered_card)
            resulted_barcode = int(self.get_attribute_value("value", *self.registered_card))
            card_no = int(card_no[0])
            if resulted_barcode == card_no:
                log.info("Advanced search with entered barcode matches with the svoc resulted barcode successfully")
            else:
                log.info("Advanced search with entered barcode doesn't matches with the svoc resulted barcode "
                         "successfully")
        except Exception as e:
            log.error("Exception {} occurred while validating the barcode ".format(e))
            status &= False
        return status

    @allure.step("search with first_name ,last_name")
    def search_with_fname_lastname(self, first_name, last_name):
        """
        Method to search with first_name ,last_name
        :param: first_name, last_name
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self.first_name_input_box)
            self.enter(first_name, *self.first_name_input_box)
            self.wait_for_element(self.last_name_input_box)
            self.enter(last_name, *self.last_name_input_box)
            log.info("entered first name , last name in the search field")
        except Exception as e:
            log.error("Exception {} occurred while searching using first name , last name ".format(e))
            status &= False
        return status

    @allure.step("Verify the resulted search page")
    def validate_search_page(self):
        """
        Method to Verify the resulted search page
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            name = (self.get_text(*self.resulted_name)).split(" ")
            resulted_name_ = name[0] + " " + name[1]
            print(resulted_name_)
            log.info("searched resulted page {} displayed successfully".format(name))
        except Exception as e:
            log.error("Exception {} occurred while verifying resulted search".format(e))
            status &= False
        return status

    @allure.step("Validate customer profile by name")
    def validate_search_by_name(self, first_name, last_name):
        """
        Method to Validate customer profile by name
        :param: first_name, last_name
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            name = (self.get_text(*self.resulted_name)).split(" ")
            resulted_name_ = name[0] + " " + name[1]
            print(resulted_name_)
            comp_name = first_name + " " + last_name
            print(comp_name)
            if resulted_name_.lower() == comp_name:
                log.info("Resulted the customer profile matched successfully")
            else:
                log.error("There is a mismatch found in the result")
        except Exception as e:
            log.error("Exception {} occurred while resulting the customer profile".format(e))
            status &= False
        return status

    @allure.step("search with email")
    def search_with_email(self, mail_id):
        """
        Method to search with email
        :param: mail_id
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.enter(mail_id[0], *self.email_box)
            log.info("Entered the mail id  successfully ")
        except Exception as e:
            log.error("Exception {} occurred while entering the mail id  on advanced search popup".format(e))
            status &= False
        return status

    @allure.step("Validate the search with email")
    def validate_search_with_mailid(self, mail_id):
        """
        Method to Validate the search with email
        :param: mail_id
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self.email_box)
            resulted_mail_id = str(self.get_attribute_value("value", *self.resulted_mailid))
            mail_id = str(mail_id[0])
            if resulted_mail_id == mail_id:
                log.info("Advanced search with entered mailid matches with the svoc resulted mailid successfully")
            else:
                log.info("Advanced search with entered mailid doesn't matches with the svoc resulted mailid"
                         "successfully")
        except Exception as e:
            log.error("Exception {} occurred while validating the mailid ".format(e))
            status &= False
        return status

    @allure.step("click on the account button")
    def click_on_account(self):
        """
        Method to click on the account button
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.page_refresh()
            status &= self.click(*self.account_field)
            self.custom_time_wait(5)
            status &= self.click(*self.value_account)
            log.info("Advanced search button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on advanced search button".format(e))
            status &= False
        return status

    @allure.step("search with household")
    def search_with_household_num(self, household_num):
        """
        Method to click on the account button
        :param:household_num
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.enter(household_num, *self.household_num_box)
            log.info("Entered the household num successfully ")
        except Exception as e:
            log.error("Exception {} occurred while entering the household num on advanced search popup".format(e))
            status &= False
        return status

    @allure.step("Validate the search with household")
    def validate_search_with_household(self, household_num):
        """
        Method to Validate the search with household
        :param:household_num
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self.resulted_household_num_box)
            resulted_household_num = self.get_text(*self.resulted_household_num_box)
            resulted_household_num = str(resulted_household_num.split(' ')[1])
            household_num = str(household_num[0].split("'")[1])
            if resulted_household_num == household_num:
                log.info("Advanced search with entered household number matches with the svoc resulted household number successfully")
            else:
                log.info("Advanced search with entered household number doesn't matches with the svoc resulted household number"
                         "successfully")
        except Exception as e:
            log.error("Exception {} occurred while validating the household number ".format(e))
            status &= False
        return status

    @allure.step("search with phone number")
    def search_with_phone_num(self, ph):
        """
        Method to search with phone number
        :param:ph
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.enter(ph[0], *self.phone_num_box)
            log.info("Entered the phone number successfully ")
        except Exception as e:
            log.error("Exception {} occurred while entering the phone number on advanced search popup".format(e))
            status &= False
        return status

    @allure.step("Validate the search with phone number")
    def validate_search_with_phone_num(self, ph):
        """
        Method to Validate the search with phone number
        :param:ph
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            resulted_phone_num = self.get_text(*self.resulted_phone_num_box)
            resulted_phone_num = (resulted_phone_num.split(' ')[1]).strip(',')
            ph = str(ph[0])
            if resulted_phone_num == ph:
                log.info(
                    "Advanced search with entered phone number matches with the svoc resulted household number successfully")
            else:
                log.info(
                    "Advanced search with entered phone number doesn't matches with the svoc resulted household number"
                    "successfully")
        except Exception as e:
            log.error("Exception {} occurred while validating the phone number ".format(e))
            status &= False
        return status

    @allure.step("Validate the search with partial barcode")
    def validate_search_with_partial_barcode(self, partial_id):
        """
        Method to Validate the search with partial barcode
        :param:partial_id
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            resulted_barcode = str(self.get_attribute_value("value", *self.registered_card))
            resulted_barcode = resulted_barcode[:8]
            partial_id = str(partial_id[0])
            if resulted_barcode == partial_id:
                log.info("Advanced search with entered barcode matches with the svoc resulted barcode successfully")
            else:
                log.info("Advanced search with entered barcode doesn't matches with the svoc resulted barcode "
                         "successfully")
        except Exception as e:
            log.error("Exception {} occurred while validating the barcode ".format(e))
            status &= False
        return status
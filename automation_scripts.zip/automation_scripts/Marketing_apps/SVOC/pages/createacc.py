"""
page object model for account page
"""
from random import random, randint
from time import sleep

import allure
from selenium.webdriver.common.by import By
from seleniumhelper.sehelperpage import SeHelperPage
from conftest import log


class CreateaccountsPage(SeHelperPage):
    """
    Class consists of Profile page objects and methods
    """

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    action_button = (By.XPATH, "//span[text()='Select an Action']")
    add_new_acc = (By.XPATH, "//li[text()='Account']//following::li//a[text()='Add New Account ']")
    add_new_acc_page = (By.XPATH, "//p[text()='Add Member to Account']")
    add_new_acc_page_basic_info = (By.XPATH, "//p[text()='Add New Account']")
    _first_name = (By.ID, "FirstName")
    _last_name = (By.ID, "LastName")
    _birth_date = (By.ID, "DOB")
    _address_1 = (By.ID, "Address1")
    _city = (By.ID,"City")
    _state = (By.ID, "state")
    _zip = (By.ID, "Zip")
    _next_btn = (By.ID, "AddMemberSubmit")
    _card_type = (By.ID, "loyalty")
    _individual_name = (By.XPATH, "//input[@id ='IndividualName']")
    _issue_card = (By.NAME, "submitButton")
    _generate_geac_btn = (By.ID,"GenerateDigitalCard")
    _geac_number_field  = (By.XPATH, "//input[@id ='GeneratedCardNumber']")
    _geac_number_field_id = (By.ID, "GeneratedCardNumber")
    _issue_new_card_submit_btn = (By.ID, "issuecardNewSubmit")
    _text_pop_up = (By.XPATH, "//h3//strong[text()='Would you like to add a second individual to this rewards account?']")
    _no_btn = (By.XPATH, "//a[text()='No']")
    _geac_value =(By.XPATH, "//div[@class='list-inline']//span[2]")
    _getgo_card_screen = (By.XPATH, "//a[contains(text(),'GetGo Advantage Card')]")
    _md_card_screen = (By.XPATH, "//a[contains(text(),'MD Advantage Card')]")
    _reset_btn = (By.XPATH, "//button[@id='FixEmeStatusLevel' and text()='Reset']")
    _all_card_section = (By.XPATH, "//div[@id='activecardsarea']//p[text()='All Cards']")
    _geac_value_svoc_screen = (By.XPATH, "//table[@id='tra-rec-table']//b[text()='Card Number']/following::span[1]/a")
    _add_member_to_acc = (By.XPATH, "//div/p[contains(text(),'Add Member to Account')]")
    _add_member_to_reward_acc = (By.XPATH, "//p[text()=' Add Card to Rewards Account']")
    _issue_card_submit_btn = (By.ID, "issueCardSubmit")
    _select_name = (By.ID, "name")
    _enter_name_ = "//select[@id='name']//option[text()='{}']"
    _choose_indvividual_name = (By.XPATH, "//select[@id='name']")
    _add_card_submit_btn = (By.ID, "addcardSubmit")
    _verify_card_added_alert = (By.XPATH, "//span[@id='alert' and text()='Card account has been added.']")



    @allure.step("click on select Account Page ")
    def click_on_add_new_account_page(self):
        """
        Method to click on add new account / create new account in svoc page
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self.action_button)
            status &= self.click(*self.add_new_acc)
            log.info("clicked on log new account")
        except Exception as e:
            log.error("Exception {} occurred while clicking on add new Account ".format(e))
            status &= False
        return status

    @allure.step("Verify the Add Member to Account page of svoc")
    def verify_add_member_first_screen_in_account_page(self):
        """
        Method to verify add new account / created new account member in account page
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self.add_new_acc_page)
            log.info("Add Member to Account page displayed and successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying to Add Member to Account page")
            status &= False
        return status

    @allure.step("Enter info to the Add Member to Account page of svoc")
    def enter_info_new_acc_member_(self, first_name, last_name, dob, Address_1, zipcode, state, city):
        """
        Method to enter the information about the user to create an account/ add member in account page
        :param: first_name, last_name, dob, Address_1, zipcode, state, city
        :return: status - Boolean True or False and first_name, last_name
        """
        status = True
        number = randint(1, 99)
        first_name = "auto" + first_name + str(number)
        last_name = last_name + str(number)
        try:
            self.wait_for_page_load_complete()
            self.enter(first_name, *self._first_name)
            log.info("first_name entered successfully- {}".format(first_name))
            self.enter(last_name, *self._last_name)
            log.info("last_name entered successfully- {}".format(last_name))
            self.enter(dob, *self._birth_date)
            log.info("dob entered successfully- {}".format(dob))
            self.enter(Address_1, *self._address_1)
            log.info("Address_1 entered successfully- {}".format(Address_1))
            self.enter(zipcode, *self._zip)
            log.info("zipcode entered successfully- {}".format(zipcode))
            self.select_by_text(state, *self._state)
            log.info("state entered successfully- {}".format(state))
            self.enter(city, *self._city)
            log.info("city entered successfully- {}".format(city))
        except Exception as e:
            log.error("Exception {0} occurred while entering details into Add Member to Account page")
            status &= False
        return status, first_name, last_name

    @allure.step("Verify the Add new Account page-2 where name and of svoc")
    def verify_add_member_second_screen_account_page(self):
        """
        Method to validate the information provided is correct then this page will be displayed
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self.add_new_acc_page_basic_info)
            log.info("Add new Account page displayed and successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying to Add new Account page")
            status &= False
        return status

    @allure.step("click on the next button in add new member screen")
    def click_next_button(self):
        """
        Method to click on next button in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._next_btn)
            status &= self.click(*self._next_btn)
            log.info("next button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on next button".format(e))
            status &= False
        return status

    @allure.step("Validate customer profile by name")
    def validate_individual_name(self, first_name, last_name, first_name_1=None, last_name_1=None ):
        """
        Method to validate customer profile by name
        :param: first_name, last_name
        :return: status - Boolean True or False
        """
        status = True
        _name = ''
        _name_1 = ''
        try:
            self.wait_for_page_load_complete()
            name = (self.get_attribute_value("value", *self._individual_name)).split(" ")
            resulted_name_ = name[0] + " " + name[1]
            if first_name is not None and last_name is not None:
                 _name = first_name + " " + last_name
            if first_name_1 is not None and last_name_1 is not None:
                _name_1 = first_name_1 + " " + last_name_1
            if resulted_name_.lower() == _name.lower():
                log.info("Resulted individual name- {0} matched with given customer name-{1} successfully".format(resulted_name_, _name))
            elif resulted_name_.lower() == _name_1.lower():
                log.info("Resulted individual name- {0} matched with given customer name-{1} successfully".format(resulted_name_, _name_1))
            else:
                log.error("There is a mismatch found in the result")
        except Exception as e:
            log.error("Exception {} occurred while resulting the individual customer name profile".format(e))
            status &= False
        return status, resulted_name_

    @allure.step("select card_type to the Add Member to Account page of svoc")
    def select_card_type(self, card_type):
        """
        Method to select card_type to the Add Member to Account page of svoc
        :param: first_name, last_name
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.select_by_text(card_type, *self._card_type)
            log.info("card_type entered successfully- {}".format(card_type))
        except Exception as e:
            log.error("Exception {0} occurred while selecting card type into Add Member to Account page")
            status &= False
        return status

    @allure.step("click on the issue card button in add new member screen")
    def click_issue_card_button(self):
        """
        Method to click on the issue card button in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._issue_card)
            status &= self.click(*self._issue_card)
            log.info("issue card button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on issue card button".format(e))
            status &= False
        return status

    @allure.step("click on the generate geac button in add new member screen")
    def click_on_generate_geac_button(self):
        """
        Method to click on the generate geac button in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._generate_geac_btn)
            log.info("generate geac button clicked successfully")
            status &= self.is_element_visible(self._geac_number_field)
            self.custom_time_wait(10)
            resulted_geac_no = self.driver.execute_script("return arguments[0].value;", self.find_element(*self._geac_number_field))
            self.custom_time_wait(5)
            log.info("Resulted geac number is {}".format(resulted_geac_no))
        except Exception as e:
            log.error("Exception {} occurred while clicking on generate geac button".format(e))
            status &= False
        return status, resulted_geac_no

    @allure.step("enter on the geac number in add new member screen")
    def enter_geac_number(self, geac_number):
        """
        Method to enter on the geac number in add new member screen
        :param: geac_number
        :return: status - Boolean True or False
        """
        status = True
        try:
            if geac_number != '':
                self.wait_for_page_load_complete()
                status &= self.enter(geac_number, *self._geac_number_field)
                log.info("geac number entered successfully")
            else:
                log.info("geac number is not passed from json file")
        except Exception as e:
            log.error("Exception {} occurred while entering geac number".format(e))
            status &= False
        return status

    @allure.step("Verify the Add new Account pop up screen of svoc")
    def verify_add_member_second_indvidual_account_popup_screen(self):
        """
        Method to Verify the Add new Account pop up screen of svoc
        :param: geac_number
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._text_pop_up)
            log.info("Add new Account page displayed and successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying to Add new Account page")
            status &= False
        return status

    @allure.step("click on the no button in add new member screen")
    def click_no_button(self):
        """
        Method to click on the no button in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._no_btn)
            status &= self.click(*self._no_btn)
            log.info("no button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on no button".format(e))
            status &= False
        return status

    @allure.step("click on the submit button in add new member screen")
    def click_submit_button_new_card(self):
        """
        Method to click on the submit button in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.custom_time_wait(3)
            self.scroll_to_element(*self._issue_new_card_submit_btn)
            status &= self.click(*self._issue_new_card_submit_btn)
            log.info("submit button clicked successfully and new account is created")
        except Exception as e:
            log.error("Exception {} occurred while clicking on submit button".format(e))
            status &= False
        return status

    @allure.step("copy geac number screen")
    def copy_geac_number_from_main_svoc_screen(self):
        """
         Method to copy geac number screen
         :return: status - Boolean True or False
         """
        status = True
        resulted_geac_no = ''
        try:
            self.wait_for_page_load_complete()
            status &= self.is_element_visible(self._geac_value)
            resulted_geac_no = self.get_text(*self._geac_value)
            log.info("geac number is {} created successfully".format(resulted_geac_no))
        except Exception as e:
            log.error("Exception {} occurred while visibility of the geac number".format(e))
            status &= False
        return status, resulted_geac_no

    @allure.step("click on the getgo card button in add new member screen")
    def click_getgo_card_button(self):
        """
        Method to click on the getgo card button in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._getgo_card_screen)
            status &= self.click(*self._getgo_card_screen)
            log.info("getgo card button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on getgo card button".format(e))
            status &= False
        return status

    @allure.step("click on the md card button in add new member screen")
    def click_md_card_button(self):
        """
        Method to click on the md card button in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._md_card_screen)
            status &= self.click(*self._md_card_screen)
            log.info("md card button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on md card button".format(e))
            status &= False
        return status

    @allure.step("click on the reset button for the new member card")
    def click_reset_button(self):
        """
        Method to click on the reset button for the new member card
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._reset_btn)
            status &= self.click(*self._reset_btn)
            log.info("reset button clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on reset button".format(e))
            status &= False
        return status

    @allure.step("click on the all cards section for the new member card")
    def click_all_cards_sec(self):
        """
        Method to click on the reset button for the new member card
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._all_card_section)
            status &= self.click(*self._all_card_section)
            log.info("all cards section clicked successfully")
        except Exception as e:
            log.error("Exception {} occurred while clicking on all cards section".format(e))
            status &= False
        return status

    @allure.step("select geac value from the screen in add new member screen")
    def select_geac_value_svoc_screen(self):
        """
        Method to select geac value from the screen in add new member screen
        :return: status - Boolean True or False
        """
        status = True
        geac_no_svoc_screen = ''
        try:
            self.wait_for_page_load_complete()
            geac_no_svoc_screen = self.get_text(*self._geac_value_svoc_screen)
            print(geac_no_svoc_screen)
            self.custom_time_wait(5)
            log.info("geac number from svoc is {}".format(geac_no_svoc_screen))
        except Exception as e:
            log.error("Exception {} occurred while selecting geac number from svoc".format(e))
            status &= False
        return status, geac_no_svoc_screen

    @allure.step("Verify the Add Member to Account page of svoc")
    def verify_add_member_to_account_page(self):
        """
        Method to verify add new account / created new account member in account page
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._add_member_to_acc)
            log.info("adding 2nd consumer Add Member to Account page displayed and successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying adding 2nd consumer, Add Member to Account page")
            status &= False
        return status

    @allure.step("get geac card number from the screen")
    def get_geac_card_add_new_acc_screen(self):
        """
        Method to validate customer profile by name
        :param: first_name, last_name
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            resulted_geac_no = self.get_attribute_value("value", *self._geac_number_field_id)
            log.info("Resulted geac number is - {0} successfully".format(resulted_geac_no))
        except Exception as e:
            log.error("Exception {} occurred while resulting the geac number".format(e))
            status &= False
        return status, resulted_geac_no

    @allure.step("Verify the add member to reward account page of svoc")
    def verify_add_member_to_reward_acc(self):
        """
        Method to Verify the add member to reward account page of svoc while clicking add member button from all card section
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._add_member_to_reward_acc)
            log.info("Add member to reward account page displayed and successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying Add member to reward account page")
            status &= False
        return status

    @allure.step("click on the submit button in add new member into the existing account screen")
    def click_submit_button_issue_card(self):
        """
        Method to click on the submit button in add new member into the existing account screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.custom_time_wait(3)
            self.scroll_to_element(*self._issue_card_submit_btn)
            status &= self.click(*self._issue_card_submit_btn)
            log.info("issue card submit button clicked successfully and new account is created")
        except Exception as e:
            log.error("Exception {} occurred while clicking on issue card submit button".format(e))
            status &= False
        return status

    @allure.step("Validate to add the cards by name")
    def choose_indivdual_name_to_add_card(self, first_name, last_name):
        """
        Method to Validate to add the cards by name
        :param: first_name, last_name
        :return: status - Boolean True or False
        """
        status = True
        _name = first_name.capitalize() + " " + last_name.capitalize()
        try:
            self.wait_for_page_load_complete()
            name = (self.get_text(*self._choose_indvividual_name)).split(" ")
            if len(name) != 2:
                names_val = [na.strip() for names in name for na in names.split('\n') if na.strip()]
                resulted_name_ = names_val[0]+ " " + names_val[1]
            else:
                resulted_name_ = name[0] + " " + name[1]
            if resulted_name_ is not None and resulted_name_ != '':
                if resulted_name_.lower() == _name.lower():
                    log.info("Resulted individual name- {0} matched with given customer name-{1} Hence proceeding to add new card".format(
                    resulted_name_, _name))
                else:
                    status &= self.click(*self._select_name)
                    select_name = self.wait_and_find_ele_by_xpath(self._enter_name_.format(_name))
                    self.click_element(select_name)
                    log.info("given customer name-{0} selected successfully".format(_name))
            else:
                log.error("The Resulted name is empty while adding the card for the selected customer")
        except Exception as e:
            log.error("Exception {} occurred while adding the card for a selected individual customer name".format(e))
            status &= False
        return status

    @allure.step("click on the submit button to add new card screen")
    def click_submit_button_add_card(self):
        """
        Method to click on the submit button to add new card screen
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.custom_time_wait(3)
            self.scroll_to_element(*self._add_card_submit_btn)
            status &= self.click(*self._add_card_submit_btn)
            log.info("submit button clicked successfully and new card is added")
        except Exception as e:
            log.error("Exception {} occurred while clicking on submit button to add new card".format(e))
            status &= False
        return status

    @allure.step("Verify the card added alert into svoc")
    def verify_new_card_added_alert(self):
        """
        Method to the card added alert into svoc message displayed correctly
        :return: status - Boolean True or False
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._verify_card_added_alert)
            log.info("Card account has been added. message displayed successfully")
        except Exception as e:
            log.error("Exception {0} occurred while displaying Card account has been added. has been added message")
            status &= False
        return status

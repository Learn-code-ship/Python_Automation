"""
page object model for create new campaign qualification tab page
"""
import datetime
import time
from turtle import delay

import allure
from selenium.common import exceptions, NoSuchElementException, StaleElementReferenceException
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage


class EEqualificationtabPage(SeHelperPage):
    """
    Class consists of create new campaign qualification tab objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _select_qualification_tab = (By.XPATH, "//li[@data-section='qualification']")
    _qualification_btn = (By.XPATH,"//button[contains(text(),'Qualification')]")
    _basket_qualifier_apply_tab = (By.CSS_SELECTOR, "input[type='radio'][value='basket']")
    _basket_spend_box = (By.XPATH, "//input[@id='campaign-properties-campaign-v2-offer-qualification-basket-minimumBasketSpend-input']")
    _product_qualifier_apply_tab = (By.CSS_SELECTOR, "input[type='radio'][value='product']")
    _reward_tier_box = (By.XPATH, "//div[@id='segment-rewardTier-data-included-container']//select[@id='segment-rewardTier-data-included']/following::input[@placeholder='Select rewardTier segment(s)'][1]")
    _reward_tier_value = "//select[@id='segment-rewardTier-data-included']//option[contains(text(),'{}')]"
    _included_button = "//label[contains(text(),'{0} Included Products')]//parent::div//button"
    _ge_included = (By.XPATH, "//label[contains(text(),'Giant Eagle Included Products')]//parent::div//button")
    _product_picker_screen = (By.XPATH, "//h4[contains(text(),'Product Picker')]")
    _pick_by_name = (By.XPATH,"//button//span[text()='Product Name']")
    _name_by_upc = (By.XPATH,"//button//span[text()='Product Name']//following::li/a[contains(text(),'UPC')]")
    _input_search = (By.CSS_SELECTOR, " input.form-control.picker-search-value")
    _input_btn = (By.XPATH, "//button[@class='btn btn-primary search-btn']")
    _search_button = (By.CSS_SELECTOR, "button.btn.btn-primary.search-btn")
    _add_item_button = (By.XPATH, "//*[@class='icon icon-plus add-product']")
    _save_button_picker_screen = (By.XPATH, "//button[contains(text(),'Save')]")
    _ge_qulifier = (By.XPATH, "//input[@name='campaign[properties][campaign][v2][offer][qualification][product][GE][collections][0][minimumProductSpend]']")
    _ge_min_unit = (By.XPATH, "//input[@id='minimum-units-GE-0']")
    _gg_qulifier = (By.XPATH, "//input[@name='campaign[properties][campaign][v2][offer][qualification][product][GG][collections][0][minimumProductSpend]']")
    _gg_min_unit = (By.XPATH, "//input[@id='minimum-units-GG-0']")
    dis_min = (By.XPATH, "//label[contains(text(),' Min Spend *')]")

    #continuity campaign type
    _continuity_qualification_type_transc = (By.CSS_SELECTOR, "input[type='radio'][value='transaction-count']")
    _continuity_qualification_type_spend = (By.CSS_SELECTOR, "input[type='radio'][value='total-spend']")
    _continuity_qualification_type_units = (By.CSS_SELECTOR, "input[type='radio'][value='unit-quantity']")
    _total_spend_field = (By.XPATH, "//input[@id='campaign-properties-campaign-v2-offer-continuity-qualification-totalTransactionSpend-input']")
    _no_of_transc_field = (By.XPATH, "//label[contains(text(),'Number of Transactions *')]//parent::div//input")
    _unit_qty_field = (By.XPATH, "//input[@id='campaign-properties-campaign-v2-offer-continuity-qualification-totalTransactionUnits-input']")

    #discount products
    _ge_qulifier_min_spend = (By.XPATH, "//input[@id='products-min-spend-input-GE']")
    _ge_min_units = (By.XPATH, "//input[@id='products-min-units-input-GE']")
    _gg_qulifier_min_spend = (By.XPATH, "//input[@id='products-min-spend-input-GG']")
    _gg_min_units = (By.XPATH, "//input[@id='products-min-units-input-GG']")
    _qualifier_select = "//label[contains(text(),'{0} Included Products')]//parent::div//button"

    @allure.step("Verify if create new campaign qualification tab screen is displayed")
    def verify_qualification_tab_screen(self):
        """
        method to verify create new campaign qualification tab screen  is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_qualification_tab)
            log.info("create new campaign page qualification tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign  qualification tab page".format(e))
        return status

    @allure.step("select create campaigns by qualification tab")
    def select_by_qualification_tab(self):
        """
        method to select create campaigns by qualification tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._select_qualification_tab)
            log.info("selection of create new campaigns qualification tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns qualification tab").format(e)
        return status

    @allure.step("click qualification button in creation tab")
    def click_qualification_btn(self):
        """
        method to click qualification button in creation tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._qualification_btn)
            log.info("qualification button clicked successfully in creation tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking qualification button in the creation tab").format(e)
        return status

    @allure.step("select Qualifier applies to in qualification tab")
    def select_qualifier_apply_btn(self, qualifier, basket_amount=None):
        """
        method to select Qualifier applies to in qualification tab,
        :param: qualifier
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if qualifier == 'basket':
                checked_att = self.get_attribute_value("checked", *self._basket_qualifier_apply_tab)
                if checked_att == True:
                    print("qualifier applies to - {0} radio button found checked".format(qualifier))
                else:
                    status &= self.click_using_javascript(*self._basket_qualifier_apply_tab)
                    log.info("qualifier applies to  - {0} clicked successfully in creation tab".format(qualifier))
                status &= self.enter(basket_amount, *self._basket_spend_box)
                log.info("basket amount {0} entered successfully in qualification tab".format(basket_amount))
                self.custom_time_wait(2)
            if qualifier == 'product':
                checked_att = self.get_attribute_value("checked", *self._product_qualifier_apply_tab)
                if (checked_att == True):
                    print("qualifier applies to - {0} radio button found checked".format(qualifier))
                else:
                    status &= self.click_using_javascript(*self._product_qualifier_apply_tab)
                    log.info("qualifier applies to  - {0} clicked successfully in creation tab".format(qualifier))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting Qualifier in the qualification tab".format(e))
        return status

    @allure.step("Select reward tier in qualification tab")
    def select_reward_tier(self, reward_tier):
        """
        method to select reward_tier in qualification tab
        :param: reward_tier
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._reward_tier_box)
            status &= self.click_using_javascript(*self._reward_tier_box)
            reward_tier_val = self.wait_and_find_ele_by_xpath(self._reward_tier_value.format(reward_tier))
            status &= self.click_element(reward_tier_val)
            log.info("reward_tier {0} entered successfully in qualification tab".format(reward_tier))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting reward_tier in the qualification tab".format(e))
        return status

    def include_products(self, redemption_partner, ge_include_product=None, gg_included_product=None):
        """
        method to select reward_tier in qualification tab
        :param: products_to_include
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            for value in redemption_partner:
                include_button = self.wait_and_find_ele_by_xpath(self._included_button.format(value))
                status &= self.click_element(include_button)
                log.info("include products button for {0} clicked successfully in qualification tab".format(value))
                status &= self.isdisplayed(*self._product_picker_screen)
                log.info("product picker screen displayed successfully in qualification tab")
                status &= self.click(*self._pick_by_name)
                status &= self.click(*self._name_by_upc)
                log.info("product picker by upc clicked successfully in qualification tab")
                if value == "Giant Eagle":
                    self.click(*self._input_search)
                    self.enter(ge_include_product, *self._input_search)
                    self.custom_time_wait(10)
                    self.click(*self._search_button)
                    time.sleep(20)
                    self.click(*self._add_item_button)
                    log.info("Ge included products has been selected")
                    self.scroll_to_element(*self._save_button_picker_screen)
                    status &= self.click(*self._save_button_picker_screen)
                    log.info("products has been selected and clicked save button")
                    if self.isdisplayed(*self.dis_min)==True:
                        status &= self.enter(10, *self._ge_qulifier)
                        status &= self.enter(1, *self._ge_min_unit)
                        log.info("successfully entered the units and min spend ge qualifier")
                if value == "Get Go":
                    self.click(*self._input_search)
                    self.enter(gg_included_product, *self._input_search)
                    self.custom_time_wait(10)
                    self.click(*self._search_button)
                    time.sleep(20)
                    self.click(*self._add_item_button)
                    log.info("Ge included products has been selected")
                    self.scroll_to_element(*self._save_button_picker_screen)
                    status &= self.click(*self._save_button_picker_screen)
                    log.info("products has been selected and clicked save button")
                    if self.isdisplayed(*self.dis_min) == True:
                        status &= self.enter(10, *self._gg_qulifier)
                        status &= self.enter(1, *self._gg_min_unit)
                        log.info("successfully entered the units and min spend gg qualifier")
            self.custom_time_wait(2)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking include products button in the qualification tab".format(e))
        return status

    def exclude_products(self, redemption_partner):
        """
        method to select reward_tier in qualification tab
        :param: products_to_exclude
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            for value in redemption_partner:
                include_button = self.wait_and_find_ele_by_xpath(*self._included_button.format(value))
                status &= self.click_element(include_button)
                log.info("include products button for {0} clicked successfully in qualification tab".format(value))
        except Exception as e:
            status &= False
            log.error(
                "Exception occurred {0} while clicking include products button in the qualification tab".format(e))
        return status

    @allure.step("select Continuity Qualification Type qualification tab")
    def select_continuity_qualification_type_btn(self, continuity_qualification_type, transctions=None, total_spend=None, unit_qty=None):
        """
        method to select coupon expiry in creation tab
        :param: continuity_qualification_type
        :param: continuity_qualification_type is transctions, define number of transactions parameter
        :param: continuity_qualification_type is spend, define total spend parameter
        :param: continuity_qualification_type is units, define number of unit_quantity parameter
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if continuity_qualification_type == 'Transactions':
                checked_att = self.get_attribute_value("checked", *self._continuity_qualification_type_transc)
                if (checked_att == True):
                    log.info("continuity qualification type - {0} radio button found checked".format(continuity_qualification_type))
                else:
                    status &= self.click_using_javascript(*self._continuity_qualification_type_transc)
                    log.info("continuity qualification type - {0} radio button clicked successfully".format(continuity_qualification_type))
                    status &= self.enter(transctions, *self._no_of_transc_field)
                    log.info("the {0} with no of transactions entered successfully".format(continuity_qualification_type))
            if continuity_qualification_type == 'Spend':
                checked_att = self.get_attribute_value("checked", *self._continuity_qualification_type_spend)
                if (checked_att == True):
                    log.info("continuity qualification type - {0} radio button found checked".format(continuity_qualification_type))
                else:
                    status &= self.click_using_javascript(*self._continuity_qualification_type_spend)
                    log.info("continuity qualification type - {0} radio button clicked successfully".format(continuity_qualification_type))
                    status &= self.enter(total_spend, *self._total_spend_field)
                    log.info("the {0} with no of total spend entered successfully".format(continuity_qualification_type))
            if continuity_qualification_type == 'units':
                checked_att = self.get_attribute_value("checked", *self._continuity_qualification_type_units)
                if (checked_att == True):
                    log.info("continuity qualification type - {0} radio button found checked".format(continuity_qualification_type))
                else:
                    status &= self.click_using_javascript(*self._continuity_qualification_type_units)
                    log.info("continuity qualification type - {0} radio button clicked successfully".format(continuity_qualification_type))
                    status &= self.enter(unit_qty, *self._unit_qty_field)
                    log.info("the {0} with no of total units quantity entered successfully".format(continuity_qualification_type))
            self.custom_time_wait(2)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking continuity qualification button in the qualification tab").format(e)
        return status

    @allure.step("Enter basket spend amount in qualification tab")
    def enter_basket_spend_amount(self, basket_amount):
        """
        method to select basket spend amount in qualification tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.enter(basket_amount, *self._basket_spend_box)
            log.info("basket amount {0} entered successfully in qualification tab".format(basket_amount))
            self.custom_time_wait(2)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting basket amount in the qualification tab".format(e))
        return status

    def product_qualifier(self, redemption_partner):
        """
        method to select product qualifier in qualification tab
        :param: products_to_include
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            for value in redemption_partner:
                if value == "Giant Eagle":
                     status &= self.enter(10, *self._ge_qulifier_min_spend)
                     status &= self.enter(1, *self._ge_min_units)
                     log.info(" Minimum Product Qualifiers for GE {0} clicked successfully in qualification tab".format(value))
                if value == "Get Go":
                    status &= self.enter(10, *self._gg_qulifier_min_spend)
                    status &= self.enter(1, *self._gg_min_units)
                    log.info(" Minimum Product Qualifiers for get go {0} clicked successfully in qualification tab".format(value))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting Minimum Product Qualifiers in the qualification tab".format(e))
        return status






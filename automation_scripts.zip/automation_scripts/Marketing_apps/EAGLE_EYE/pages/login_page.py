"""
page object model for eagle eye login page
"""
from time import sleep
import allure
from selenium.webdriver.common.by import By
from conftest import log
from encryption.utils_encrypter import decoder
from seleniumhelper.sehelperpage import SeHelperPage


class LoginPage(SeHelperPage):
    """
    Class consists of login page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _email_text_box = (By.ID, "el-username")
    _password_text_box = (By.ID, "el-password")
    _sign_in_btn = (By.ID, "submitbutton")
    _log_out_btn = (By.XPATH, "//a[@href='/logout' and @class='logout']")
    _user_acc_btn = (By.ID, "user-settings-dropdown")

    @allure.step("Login to eagle eye application")
    def launch_application(self, url):
        """
        method to login to application
        :param url: URL
        :return: status
        """
        status = False
        try:
            self.driver.get(str(url))
            sleep(5)
            self.wait_for_page_load_complete()
            status = True
            log.info("Logged in successfully")
        except Exception as e:
            status &= False
            log.error("Exception {} occurred while logging in".format(e))
        return status

    @allure.step("Verify if sign in to account")
    def sign_in(self, email_id, password):
        """
        Method to sign in to the application
        :param : email_id
        :param : password
        :return: Sign in status
        """
        status = True
        try:
            self.wait_for_element(self._email_text_box)
            self.enter(email_id, *self._email_text_box)
            self.enter(decoder(password), *self._password_text_box)
            self.click(*self._sign_in_btn)
            log.info("Clicked on Sign In button on login page")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while signing in".format(e))
        return status

    @allure.step("Log out from app")
    def log_out_user(self):
        """
        Method to log out
        :return: Log out status
        """
        status = True
        try:
            self.wait_for_element(self._user_acc_btn)
            status &= self.click(*self._user_acc_btn)
            self.wait_for_element(self._log_out_btn)
            self.click_using_javascript(*self._log_out_btn)
            self.wait_for_page_load_complete()
            status = True
        except Exception as e:
            status &= False
            log.error("Exception occurred logging out user".format(e))
        return status
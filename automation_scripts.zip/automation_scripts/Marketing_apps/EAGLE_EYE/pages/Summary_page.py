"""
page object model for create new campaign Summary tab page
"""
import datetime
import allure
from selenium.webdriver.common.by import By
from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage



class EESummarytabPage(SeHelperPage):
    """
    Class consists of create new campaign Summary tab objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _select_summary_tab = (By.XPATH, "//li[@data-section='summary']")
    _summary_btn = (By.XPATH, "//button[contains(text(),'Summary')]")
    _name_field = (By.ID, "sum-campaign-campaignName-input")
    _mode_field = (By.ID, "sum-campaign-mode-select")
    _start_date_field = (By.ID, "sum-campaign-date-start")
    _end_date_field = (By.ID, "sum-campaign-date-end")
    _campaign_approval = (By.XPATH, "//label[contains(text(),'Approve')]")
    _campaign_request_approval = (By.XPATH, "//label[contains(text(),'Request Approval')]")
    _campaign_save_as_draft = (By.XPATH, "//label[contains(text(),'Save as Draft')]")
    _save_btn = (By.XPATH, "//button[@type='submit']//i")
    _success_campaign = (By.XPATH,"//div[@id='creator-success-msg']//h4")
    _success_screen = (By.XPATH, "//h1[@class='text-center text-success']")


    @allure.step("Verify if create new campaign summary tab screen is displayed")
    def verify_summary_tab_screen(self):
        """
        method to verify create new campaign summary tab screen is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_summary_tab)
            log.info("create new campaign page summary tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign summary tab page".format(e))
        return status

    @allure.step("select create campaigns by summary tab")
    def select_by_summary_tab(self):
        """
        method to select create campaigns by summary tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._select_summary_tab)
            log.info("selection of create new campaigns summary tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns summary tab").format(e)
        return status

    @allure.step("click summary button in receipt details tab")
    def click_summary_btn(self):
        """
        method to click summary details button in receipt details tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._summary_btn)
            log.info("summary button clicked successfully in receipt details tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking summary button in receipt details tab").format(e)
        return status

    @allure.step("Validate summary details in summary tab")
    def validate_summary_details(self, campaign_name, mode, start_date, end_date):
        """
        method to Validate summary details in summary tab
        :param: campaign_name
        :param:mode
        :param:start_date
        :param:end_date
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._name_field)
            assert (self.get_text(*self._name_field)).lower() == campaign_name.lower(), 'campaign_name did not match, expected : {0} actual : {1}'.format(campaign_name, (self.get_text(*self._name_field)))
            self.wait_for_element(self._mode_field)
            assert self.get_text(*self._mode_field) == mode, 'campaign_mode did not match, expected : {0} actual : {1}'.format(mode, (self.get_text(*self._mode_field)))
            self.wait_for_element(self._start_date_field)
            assert self.get_text(*self._start_date_field) == start_date, 'start_date did not match, expected : {0} actual : {1}'.format(start_date, (self.get_text(*self._start_date_field)))
            self.wait_for_element(self._end_date_field)
            assert self.get_text(*self._end_date_field) == end_date, 'end_date did not match, expected : {0} actual : {1}'.format(end_date, (self.get_text(*self._end_date_field)))
            status = True
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while verifying details in summary tab").format(e)
        return status

    @allure.step("click approve button in summary tab")
    def click_approve_btn(self):
        """
        method to click approve button in summary tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._campaign_approval)
            log.info("approve button clicked successfully in summary tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking approve button in summary tab").format(e)
        return status

    @allure.step("click save button in summary tab")
    def click_save_btn(self):
        """
        method to click save button in summary tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._save_btn)
            log.info("save button clicked successfully in summary tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking save button in summary tab").format(e)
        return status


    def verify_camapign_success_creation(self):
        """
        method to verify campaign success creation
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            screen = self.get_text(*self._success_screen)
            if screen == 'Success':
                log.info("Success Screen is displayed")
                campaign_val = self.get_text(*self._success_campaign)
                campaign_ID = (campaign_val.split('(')[1]).split(')')[0]
                log.info(f"{campaign_ID} successfully created")
            else:
                log.info("Error found during creation of campaign")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while creating the campaign").format(e)
        return campaign_ID




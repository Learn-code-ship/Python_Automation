"""
page object model for Home page
"""
from time import sleep
import allure
from selenium.webdriver.common.by import By
from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage


class EEHomePage(SeHelperPage):
    """
    Class consists of Home page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _homepage_logo = (By.XPATH, "//a[@href='/dashboard']//span")
    _campaigns_side_bar = (By.XPATH, "//a[@id='menu-campaign-link']")
    _search_side_bar = (By.XPATH,"//a[@id='menu-searchcampaign-link']")
    _create_new_side_bar = (By.XPATH, "//a[@id='menu-createcampaign-link']")
    _approvals_side_bar = (By.XPATH, "//a[@id='menu-campaignapprovals']")
    _history_side_bar = (By.XPATH, "//a[@id='menu-campaignhistory']")



    @allure.step("Verify if Home page was displayed")
    def verify_home_page(self):
        """
        method to verify Home page logo is displayed
        :return: logo title of an element
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._homepage_logo)
            log.info("Home page is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying home page".format(e))
        return status

    @allure.step("select campaigns in the dashboard side bar")
    def select_campaign_sidebar(self):
        """
        method to select on campaign
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._campaigns_side_bar)
            log.info("campaigns clicked successfully in the dashboard side bar")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while selecting campaigns in the dashboard side bar".format(e))
        return status

    @allure.step("select search in the dashboard side bar")
    def select_search_sidebar(self):
        """
        method to select search sidebar
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._search_side_bar)
            log.info("search clicked successfully in the dashboard side bar")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while selecting search in the dashboard side bar".format(e))
        return status

    @allure.step("select create new in the dashboard side bar")
    def select_create_new_sidebar(self):
        """
        method to select create new sidebar
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._create_new_side_bar)
            log.info("create-new clicked successfully in the dashboard side bar")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while selecting create-new in the dashboard side bar".format(e))
        return status

    @allure.step("select approvals in the dashboard side bar")
    def select_approvals_sidebar(self):
        """
        method to select approvals sidebar
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._approvals_side_bar)
            log.info("approvals clicked successfully in the dashboard side bar")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while selecting approvals in the dashboard side bar".format(e))
        return status

    @allure.step("select history in the dashboard side bar")
    def select_history_sidebar(self):
        """
        method to select history sidebar
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._history_side_bar)
            log.info("historyclicked successfully in the dashboard side bar")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while selecting history in the dashboard side bar".format(e))
        return status

"""
page object model for create new campaign general tab page
"""
import datetime
import random

import allure
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage


class EEGeneraltabPage(SeHelperPage):
    """
    Class consists of create new campaign general tab objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _select_general_tab = (By.XPATH, "//li[@data-section='general']")
    _name_input_box = (By.ID, "campaign-campaignName-input")
    _description_input_box = (By.ID, "campaign-properties-campaign-v2-details-description-textarea")
    _mode_input_box = (By.XPATH, "//span[@id='select2-campaign-mode-select-container']//span[contains(text(),'Campaign Mode')]")
    _mode_value = "//li[contains(text(),'{}')]"
    _client_acc_box = (By.XPATH, "//span[contains(text(),' Select Account Type')]")
    _client_acc_value = "//li[contains(text(),'{}')]"
    _start_date_id = "campaign-date-start"
    _start_date = (By.XPATH, "//input[@id='campaign-date-start']")
    _end_date_id = "campaign-date-end"
    _end_date = (By.XPATH, "//input[@id='campaign-date-end']")
    _tag_input_box = (By.XPATH, "//select[@id='campaign-tags']/following::input[1]")
    _general_back_btn = (By.XPATH, "//button[text()=' General']")
    _cliptoload = (By.XPATH, "//ul[@id='select2-campaign-tags-results']//li[text()='ClipToLoad']")


    @allure.step("Verify if create new campaign general tab screen is displayed")
    def verify_general_tab_screen(self):
        """
        method to verify create new campaign general tab screen  is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_general_tab)
            log.info("create new campaign page general tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign general tab page".format(e))
        return status

    @allure.step("select create campaigns by general tab")
    def select_by_general_tab(self):
        """
        method to select create campaigns by general tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_general_tab)
            log.info("selection of create new campaigns general tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns general tab".format(e))
        return status

    @allure.step("select create campaigns by general tab")
    def select_by_general_tab(self):
        """
        method to select create campaigns by general tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_general_tab)
            log.info("selection of create new campaigns general tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns general tab".format(e))
        return status

    @allure.step("Enter the campaign name in general tab")
    def enter_campaign_name(self, camp_name):
        """
        method to Enter the campaign name in general tab
        :param: camp_name
        :return: status
        """
        status = True
        number = random.randint(1, 999)
        campaign_name = camp_name + "_" + str(number)
        try:
            self.wait_for_page_load_complete()
            status &= self.enter(campaign_name, *self._name_input_box)
            log.info("Enter the campaign name-{0} successfully".format(campaign_name))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering name in the general tab".format(e))
        return campaign_name

    @allure.step("Enter campaign description general tab")
    def enter_campaign_desc(self, campaign_desc):
        """
        method to Enter campaign description in general tab
        :param: campaign_desc
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._description_input_box)
            self.scroll_to_element(*self._description_input_box)
            status &= self.enter(campaign_desc, *self._description_input_box)
            log.info("Entered the campaign desc successfully ")
            self.custom_time_wait(2)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering name in the general tab".format(e))
        return status

    @allure.step("select campaign mode in general tab")
    def select_campaign_mode(self, campaign_mode):
        """
        method to Select campaign mode in general tab
        :param: campaign_mode
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._mode_input_box)
            status &= self.click(*self._mode_input_box)
            mode_path= self.wait_and_find_ele_by_xpath(self._mode_value.format(campaign_mode))
            status &= self.click_element(mode_path)
            if campaign_mode == 'Targeted':
                status &= self.scroll_to_element(*self._tag_input_box)
                status &= self.click(*self._tag_input_box)
                status &= self.enter("ClipToLoad", *self._tag_input_box)
                status &= self.click(*self._cliptoload)
                log.info("selected the campaign Tag-'ClipToLoad' successfully for 'Targeted' campaign")
            else:
                log.info("campaign tag is not applicable to open campaign mode")
            log.info("selected the campaign mode-{0} successfully ".format(campaign_mode))
            self.custom_time_wait(2)
            status = True
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while campaign mode in the general tab".format(e))
        return status

    @allure.step("select client acc type in general tab")
    def select_client_acc(self, client_acc):
        """
        method to Enter client acc type in general tab
        :param: client_acc
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._client_acc_box)
            status &= self.click(*self._client_acc_box)
            client_acc_val = self.wait_and_find_ele_by_xpath(self._client_acc_value.format(client_acc))
            status &= self.click_element(client_acc_val)
            log.info("selected the client account type - {0} successfully ".format(client_acc))
            self.custom_time_wait(2)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while client account type in the general tab".format(e))
        return status

    @allure.step("enter start date in general tab ")
    def enter_start_date(self, start_date):
        """
        method to enter start date in general tab
        :param: start_date
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.driver.execute_script('document.getElementById("{0}").value ="{1}"'.format(self._start_date_id, start_date))
            self.press_enter(*self._start_date)
            log.info("Start date is - {0} is selected".format(start_date))
            self.custom_time_wait(2)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering start date ".format(e, start_date))
        return status

    @allure.step("enter end date in general tab ")
    def enter_end_date(self, end_date):
        """
        method to enter end date in general tab
         :param: end_date
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.driver.execute_script('document.getElementById("{0}").value ="{1}"'.format(self._end_date_id, end_date))
            self.press_enter(*self._end_date)
            log.info("End date is - {0} is selected".format(end_date))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering start date ".format(e, end_date))
        return status







"""
page object model for create new campaign creation tab page
"""
import allure
from selenium.webdriver.common.by import By

from EAGLE_EYE.resources.constants import redemption_partner_val
from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage


class EECreationtabPage(SeHelperPage):
    """
    Class consists of create new campaign creation tab objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _select_creation_tab = (By.XPATH, "//li[@data-section='creation']")
    _coupon_exp_val = (By.XPATH,
                       "//input[@name='campaign[properties][campaign][voucher][expiry][type]']//parent::label[@class='btn btn-default  active']/text()[2]")
    _campaign_expiry_box = (By.CSS_SELECTOR, "input[type='radio'][value='campaignEnd']")
    _fixed_date_box = (By.CSS_SELECTOR, "input[type='radio'][value='datetime']")
    _time_creation_box = (By.CSS_SELECTOR, "input[type='radio'][value='time']")
    _redemption_partner_field = (By.XPATH,
                                 "//select[@id='redemption-partners-selector']/following::input[@data-parsley-group='section-creation'][1]")
    _redemption_partner_value = "//li[contains(text(),'{}')]"
    _creation_button = (By.XPATH, "//button[contains(text(),'Creation ')] ")
    _fixed_date_entry_field = (By.XPATH, "//input[@id='coupon-expiry-datetime']")
    _fixed_date_entry_id = "//input[@id='coupon-expiry-datetime']"
    _time_creation_hour_field = (By.XPATH, "//input[@id='coupon-expiry-time-hours']")
    _time_creation_hour_id = "//input[@id='coupon-expiry-time-hours']"
    _time_creation_days_field = (By.XPATH, "//input[@id='coupon-expiry-time-days']")
    _time_creation_days_id = "//input[@id='coupon-expiry-time-days']"

    _campaign_start_box = (By.CSS_SELECTOR, "input[type='radio'][value='creationDate']")
    _start_fixed_date_box = (By.CSS_SELECTOR, "input[type='radio'][value='setDate']")
    _start_time_creation_box = (By.CSS_SELECTOR, "input[type='radio'][id='coupon-start-time-radio']")
    _start_fixed_date_entry_field = (By.XPATH, "//input[@id='coupon-start-datetime']")
    _start_fixed_date_entry_id = "//input[@id='coupon-start-datetime']"
    _start_time_creation_hour_field = (By.XPATH, "//input[@id='coupon-start-time-hours']")
    _start_time_creation_hour_id = "//input[@id='coupon-start-time-hours']"
    _start_time_creation_days_field = (By.XPATH, "//input[@id='coupon-start-time-days']")
    _start_time_creation_days_id = "//input[@id='coupon-start-time-days']"

    @allure.step("Verify if create new campaign creation tab screen is displayed")
    def verify_creation_tab_screen(self):
        """
        method to verify create new campaign creation tab screen is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_creation_tab)
            log.info("create new campaign page creation tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign  creation tab page".format(e))
        return status

    @allure.step("select create campaigns by creation tab")
    def select_by_creation_tab(self):
        """
        method to select create campaigns by creation tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._select_creation_tab)
            log.info("selection of create new campaigns creation tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns creation tab").format(e)
        return status

    @allure.step("click creation button in general tab")
    def click_creation_btn(self):
        """
        method to click creation button in general tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._creation_button)
            log.info("create button clicked successfully in general tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking create button in the general tab").format(e)
        return status

    @allure.step("select coupon expiry radio button in creation tab")
    def select_coupon_expiry_btn(self, coupon_expiry, fixed_date=None, time_creation_hours=None,
                                 time_creation_days=None):
        """
        method to select coupon expiry in creation tab
        :param: coupon_expiry
        :param:fixed_date
        :param:time_creation_hours
        :param:time_creation_days
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if coupon_expiry == 'Campaign Expiry':
                checked_att = self.get_attribute_value("checked", *self._campaign_expiry_box)
                if (checked_att == True):
                    print("coupon expiry - {0} radio button found checked".format(coupon_expiry))
                else:
                    status &= self.click_using_javascript(*self._campaign_expiry_box)
                    log.info("coupon expiry - {0} clicked successfully in creation tab".format(coupon_expiry))
            if coupon_expiry == 'Fixed Date' or "fixed-price":
                checked_att = self.get_attribute_value("checked", *self._fixed_date_box)
                if (checked_att == True):
                    print("coupon expiry - {0} radio button found checked".format(coupon_expiry))
                else:
                    status &= self.click_using_javascript(*self._fixed_date_box)
                    status &= self.click_using_javascript(*self._fixed_date_entry_field)
                    self.driver.execute_script(
                        'document.getElementById("{0}").value ="{1}"'.format(self._fixed_date_entry_id, fixed_date))
                    self.press_enter(*self._fixed_date_entry_field)
                    log.info("coupon expiry - {0} clicked successfully in creation tab".format(coupon_expiry))
            if coupon_expiry == "Time After Creation":
                checked_att = self.get_attribute_value("checked", *self._time_creation_box)
                if checked_att == True:
                    print("coupon expiry - {0} radio button found checked".format(coupon_expiry))
                else:
                    status &= self.click(*self._time_creation_box)
                    log.info("coupon expiry - {0} clicked successfully in creation tab".format(coupon_expiry))
                    if time_creation_hours is not None:
                        status &= self.click_using_javascript(*self._time_creation_hour_field)
                        status &= self.enter(time_creation_hours, *self._time_creation_hour_field)
                        self.press_enter(*self._time_creation_hour_field)
                        log.info("time creation hour - {0} entered successfully in creation tab".format(time_creation_hours))
                    elif time_creation_days is not None:
                        status &= self.click_using_javascript(*self._time_creation_days_id)
                        status &= self.enter(time_creation_days, *self._time_creation_days_id)
                        self.press_enter(*self._time_creation_days_id)
                        log.info("time_creation_days - {0} clicked successfully in creation tab".format(time_creation_days))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking coupon expiry button in the creation tab").format(e)
        return status

    @allure.step("select redemption partner in creation tab")
    def select_redemption_partner(self, redemption_partner):
        """
        method to select redemption partner in creation tab
        :param: redemption_partner here send the value as Giant
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            for value in redemption_partner:
                self.scroll_to_element(*self._redemption_partner_field)
                status &= self.click(*self._redemption_partner_field)
                if value in redemption_partner_val:
                    redemption_value = self.wait_and_find_ele_by_xpath(self._redemption_partner_value.format(value))
                    status &= self.click_element(redemption_value)
            log.info("Redemption partner - {0} selected successfully in creation tab".format(value))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting redemption_partner in the creation tab".format(e))
        return status

    @allure.step("select coupon start radio button in creation tab")
    def select_coupon_start_btn(self, coupon_start, fixed_date=None, time_creation_hours=None,
                                 time_creation_days=None):
        """
        method to select coupon start in creation tab
        :param: coupon_start
        :param:fixed_date
        :param:time_creation_hours
        :param:time_creation_days
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if coupon_start == 'Immediately':
                checked_att = self.get_attribute_value("checked", *self._campaign_start_box)
                if (checked_att == True):
                    print("coupon_start - {0} radio button found checked".format(coupon_start))
                else:
                    status &= self.click_using_javascript(*self._campaign_expiry_box)
                    log.info("coupon_start - {0} clicked successfully in creation tab".format(coupon_start))
            if coupon_start == 'Fixed Date':
                checked_att = self.get_attribute_value("checked", *self._start_fixed_date_box)
                if (checked_att == True):
                    print("coupon start - {0} radio button found checked".format(coupon_start))
                else:
                    status &= self.click_using_javascript(*self._start_fixed_date_box)
                    status &= self.click_using_javascript(*self._start_fixed_date_entry_field)
                    self.driver.execute_script(
                        'document.getElementById("{0}").value ="{1}"'.format(self._start_fixed_date_entry_id, fixed_date))
                    self.press_enter(*self._start_fixed_date_entry_field)
                    log.info("coupon start - {0} clicked successfully in creation tab".format(coupon_start))
            if coupon_start == "Time After Creation":
                checked_att = self.get_attribute_value("checked", *self._start_time_creation_box)
                if checked_att == True:
                    print("coupon start - {0} radio button found checked".format(coupon_start))
                else:
                    status &= self.click(*self._start_time_creation_box)
                    log.info("coupon start - {0} clicked successfully in creation tab".format(coupon_start))
                    if time_creation_hours is not None:
                        status &= self.click_using_javascript(*self._start_time_creation_hour_field)
                        status &= self.enter(time_creation_hours, *self._start_time_creation_hour_field)
                        self.press_enter(*self._start_time_creation_hour_field)
                        log.info(
                            "time creation hour - {0} entered successfully in creation tab".format(time_creation_hours))
                    elif time_creation_days is not None:
                        status &= self.click_using_javascript(*self._start_time_creation_days_id)
                        status &= self.enter(time_creation_days, *self._start_time_creation_days_id)
                        self.press_enter(*self._start_time_creation_days_id)
                        log.info(
                            "time_creation_days - {0} clicked successfully in creation tab".format(time_creation_days))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking coupon start button in the creation tab").format(e)
        return status
"""
page object model for create new campaign rewardtab page
"""
import allure
from selenium.webdriver.common.by import By

from EAGLE_EYE.resources.constants import type_unlimited, discount
from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage


class EErewardtabPage(SeHelperPage):
    """
    Class consists of create new campaign reward tab objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _select_reward_tab = (By.XPATH, "//li[@data-section='reward']")
    _reward_btn = (By.XPATH, "//div[@id='creator-footer']//button[contains(text(),'Reward')]")
    _reward_reciept_check_box = "campaign-custom-form-receiptDetails-active-"
    _reciept_display_name = (By.ID, "campaign-properties-campaign-v2-custom-receiptDetails-displayNameForReceipt-input")
    _max_reward_per_transc = (By.XPATH, "//input[@id='campaign-properties-campaign-v2-rules-redemption-maximumAccountUsage-input']")
    _discount_type_btn = "//div[@class='btn-group ']//input[@value='{}']"
    _treat_as = "//span[@class='select2-results']//ul//li[contains(text(),'{}')]"
    _treat_as_field = (By.ID, "select2-select-64a2897f6764c-container")
    _redemption_limit_per_coupon = "//input[@name='campaign[creation]' and @value='{}']"
    _seperate_redeem_acc_transc_id = "allow-multiple-redemptions-checkbox"
    _seperate_redeem_acc_transc_id_ = (By.XPATH, "//div[@id='allow-multiple-redemptions-checkbox-checkbox-container']//label[@for='allow-multiple-redemptions-checkbox']")
    _sec_box = (By.XPATH, "//input[@id='campaign-properties-campaign-rule-timeBetweenRedemptions-value-input']")

    _points_multiplier = (By.XPATH, "//input[@placeholder='Points' or @placeholder='Multiplier']")
    _scheme_search_box = (By.XPATH, "//input[@placeholder='Select a scheme by name or ID']")
    _scheme_ = (By.XPATH, "//span[@id='select2-reward-standard-points-schemeId-select-container']//span//following::span[1]")
    _scheme_value = (By.XPATH, "//li[contains(text(),'1264274 - Giant Eagle Perks - ACTIVE - 7')]")

    _multi_use_max_redemption = (By.XPATH, "//input[@placeholder=\"Max redemption's\"]")
    _single_use_box = (By.CSS_SELECTOR, "input[type='radio'][value='single']")
    _multi_use_box = (By.CSS_SELECTOR, "input[type='radio'][value='multi']")
    _unlimited_btn = (By.CSS_SELECTOR,"input[type='radio'][value='unlimited']")
    _unlimited_box = (By.CSS_SELECTOR, "input[type='radio'][value='0']")
    _limited_box = (By.CSS_SELECTOR, "input[type='radio'][value='1']")
    _min_time_redemption = (By.XPATH, "//label[@for='time-between-redemptions-checkbox' and contains(text(),'Enable')]")
    _min_time_redemption_id = "time-between-redemptions-checkbox"
    _value_input = (By.XPATH, "//input[@id='campaign-properties-campaign-rule-periodThresholds-value-input']")

    _spend_from_tier = (By.XPATH, "//input[@id='tiered-spend-for-points-floor-geplc']")
    _spend_upto_tier = (By.XPATH, "//input[@id='tiered-spend-for-points-ceiling-geplc']")
    _points_tier = (By.XPATH, "//input[@id='tiered-spend-for-points-credit-amount-geplc']")
    _scheme_tiered = (By.XPATH, "//span[@id='select2-tiered-spend-for-points-scheme-id-container']/parent::span")
    _add_tier = (By.XPATH, "//button//em[@class='icon icon-fw icon-plus']")

    _min_spend_ = (By.XPATH,"//input[@id='range-campaign-properties--campaign--v2--offer--reward--basket--points--interval--floor']")
    _max_spend_ = (By.XPATH, "//input[@id='range-campaign-properties--campaign--v2--offer--reward--basket--points--interval--ceiling']")
    _interval_ = (By.XPATH, "//input[@id='range-campaign-properties--campaign--v2--offer--reward--basket--points--interval--interval']")
    _scheme_basket = (By.XPATH, "//select[@name='campaign[properties][campaign][v2][offer][reward][basket][points][interval][schemeId]']/following::span[1]")
    _scheme_basket_point = (By.XPATH, "//select[@name='campaign[properties][campaign][v2][offer][reward][standard][points][schemeId]']/following::span[1]")

    _scheme_product_point = (By.XPATH, "//select[@name = 'campaign[properties][campaign][v2][offer][reward][product][reward][collections][0][points][standard][schemeId]']/following::span[1]")

    _min_spend_product = (By.XPATH,"//input[@id='range-campaign-properties--campaign--v2--offer--reward--product--reward--collections--0--points--interval--floor']")
    _max_spend_product = (By.XPATH, "//input[@id='range-campaign-properties--campaign--v2--offer--reward--product--reward--collections--0--points--interval--ceiling']")
    _interval_product = (By.XPATH, "//input[@id='range-campaign-properties--campaign--v2--offer--reward--product--reward--collections--0--points--interval--interval']")
    _scheme_product_variable =(By.XPATH, "//select[@id='points-variable-scheme-id']/following::span[1]")

    _scheme_product_spend_variable = (By.XPATH, "//select[@id='reward-scheme-id']/following::span[1]")
    _min_product_spend_ = (By.XPATH, "//input[@id='range-campaign-properties--campaign--v2--offer--reward--product--reward--collections--0--points--interval--floor']")
    _max_product_spend_ = (By.XPATH, "//input[@id='range-campaign-properties--campaign--v2--offer--reward--product--reward--collections--0--points--interval--ceiling']")
    _interval_product_spend = (By.XPATH, "//input[@id='range-campaign-properties--campaign--v2--offer--reward--product--reward--collections--0--points--interval--interval']")

    _fixed_val = (By.XPATH, "//input[@id='campaign-properties-campaign-v2-offer-reward-product-reward-collections-0-value-standard-discountAmount-input']")
    _percentage_val = (By.XPATH, "//input[@id='campaign-properties-campaign-v2-offer-reward-product-reward-collections-0-value-standard-percentageAmount-input']")

    @allure.step("Verify if create new campaign reward tab screen is displayed")
    def verify_reward_tab_screen(self):
        """
        method to verify create new campaign reward tab screen  is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_reward_tab)
            log.info("create new campaign page reward tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign  reward tab page".format(e))
        return status

    @allure.step("select create campaigns by reward tab")
    def select_by_reward_tab(self):
        """
        method to select create campaigns by reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._select_reward_tab)
            log.info("selection of create new campaigns reward tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns reward tab").format(e)
        return status

    @allure.step("click reward button in qualification tab")
    def click_reward_btn(self):
        """
        method to click reward button in qualification tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._reward_btn)
            log.info("reward button clicked successfully in qualification tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking reward button in the qualification tab").format(e)
        return status

    @allure.step("select discount type in reward tab")
    def select_discount_type_btn(self, discount_type):
        """
        method to select discount applies to in reward tab
        :param: discount type as tax-saver, fixed, percentage
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if discount_type in discount:
                disc_value = self.wait_and_find_ele_by_xpath(self._discount_type_btn.format(discount_type))
                checked_att = self.get_attribute_of_element("checked", disc_value)
                if checked_att is True:
                    log.info("discount {0} radio button found checked".format(discount_type))
                else:
                    status &= self.click_element(disc_value)
                    if discount_type == "fixed":
                        status &= self.enter(50, *self._fixed_val)
                        log.info("fixed value is entered")
                    log.info("discount type- {0} selected successfully in reward tab".format(discount_type))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting discount type in the reward tab".format(e))
        return status

    @allure.step("enter max reward per transaction in reward tab")
    def enter_max_reward_per_transc(self, max_reward):
        """
        method to enter max reward per transaction in reward tab
        :param: max_reward
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.enter(max_reward, *self._max_reward_per_transc)
            log.info("max reward per transaction entered successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering receipt display name in reward tab").format(e)
        return status

    @allure.step("select redemption limit per coupon transaction in reward tab")
    def select_redemption_limit_per_transc(self, redemption_coupon, max_redemptions=None):
        """
        method to select redemption limit per coupon transaction in reward tab
        :param: redemption coupon single, multi, unlimited
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if redemption_coupon == 'Single Use':
                checked_att = self.get_attribute_value("checked", *self._single_use_box)
                if (checked_att == True):
                    log.info("redemption limit per coupon type- {0} radio button found checked".format(redemption_coupon))
                else:
                    status &= self.click_using_javascript(*self._single_use_box)
                    log.info("redemption limit per coupon type- {0} selected successfully in reward tab".format(redemption_coupon))
            if redemption_coupon == 'Multi Use':
                checked_att = self.get_attribute_value("checked", *self._multi_use_box)
                if (checked_att == True):
                    log.info("redemption limit per coupon type- {0} radio button found checked".format(redemption_coupon))
                else:
                    status &= self.click_using_javascript(*self._multi_use_box)
                    status &= self.scroll_to_element(*self._multi_use_max_redemption)
                    status &= self.enter(max_redemptions, *self._multi_use_max_redemption)
                    log.info("redemption limit per coupon type- {0} selected successfully  and entered max redemption in reward tab".format(redemption_coupon))
            if redemption_coupon == 'Unlimited':
                checked_att = self.get_attribute_value("checked", *self._unlimited_btn)
                if (checked_att == True):
                    log.info("redemption limit per coupon type- {0} radio button found checked".format(redemption_coupon))
                else:
                    status &= self.click_using_javascript(*self._unlimited_btn)
                    log.info("redemption limit per coupon type- {0} selected successfully  and entered max redemption "
                             "in reward tab".format(redemption_coupon))
            status = True
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting redemption limit per coupon type in the reward tab".format(e))
        return status

    @allure.step("select treat as coupon in reward tab")
    def select_treat_as_coupon(self, treat_as):
        """
        method to click reward button in qualification tab
        :param: treat as Discount, Rebate, Tender
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._treat_as_field)
            status &= self.click_using_javascript(*self._treat_as_field)
            treat_coupon_as = self.wait_and_find_ele_by_xpath(*self._treat_as.format(treat_as))
            self.click_element(treat_coupon_as)
            log.info("selected reward treat as dropdown button with value successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting reward treat as dropdown button with value in reward tab").format(e)
        return status

    @allure.step("enable Create separate Redeem Account Transactions in reward tab")
    def click_redeem_check_box(self):
        """
        method to enable Create separate Redeem Account Transactions in reward
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if self.is_checked(self._seperate_redeem_acc_transc_id):
                log.info("Create separate Redeem Account Transactions enabled already in reward tab")
            else:
                status &= self.click(*self._seperate_redeem_acc_transc_id_)
                log.info("Create separate Redeem Account Transactions enabled in reward tab")
                status = True
            self.custom_time_wait(2)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking Create separate Redeem Account Transactions in reward tab").format(e)
        return status

    @allure.step("enter points in reward tab")
    def enter_points(self, points):
        """
         method to enter points in reward tab
        :param: points
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.enter(points, *self._points_multiplier)
            log.info("points per transaction entered successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering points per transaction in reward tab").format(e)
        return status

    @allure.step("select scheme per transaction in reward tab")
    def select_scheme_points_fixed(self):
        """
        method to select scheme per transaction in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("select scheme in reward tab")
    def select_scheme_continuity(self):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_search_box)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("enter tier in reward tab")
    def enter_tier_values(self, spend_from, spend_upto, points):
        """
         method to enter tier values in reward tab
        :param: points
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._spend_from_tier)
            status &= self.enter(spend_from, *self._spend_from_tier)
            log.info("spend from value entered successfully in tier reward tab")
            status &= self.enter(spend_upto, *self._spend_upto_tier)
            log.info("spend upto value entered successfully in tier reward tab")
            status &= self.enter(points, *self._points_tier)
            log.info("points value entered successfully in tier reward tab")
            status &= self.click(*self._add_tier)
            log.info("tier is added ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering tier in reward tab").format(e)
        return status

    @allure.step("select scheme in reward tab")
    def select_scheme_tiered_points(self):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_tiered)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("enter tier in reward tab")
    def enter_basket_spend_values(self, min, max, interval):
        """
         method to enter tier values in reward tab
        :param: min,max,interval
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._min_spend_)
            status &= self.enter(min, *self._min_spend_)
            log.info("min basket spend value entered successfully in  reward tab")
            status &= self.enter(max, *self._max_spend_)
            log.info("max basket spend  value entered successfully in  reward tab")
            status &= self.enter(interval, *self._interval_)
            log.info("interval basket spend  value entered successfully in  reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering basket spend in reward tab").format(e)
        return status

    @allure.step("select scheme basket spend in reward tab")
    def select_scheme_basket_spend(self):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_basket)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("select scheme basket point in reward tab")
    def select_scheme_basket_point(self):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_basket_point)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("select redemption period for the Basket Points Multiplier,Product Points Multiplier, Product Units Points Variable in reward tab")
    def select_multi_use_redemption_limit(self, redemption_limit_coupon, campaign_type, redemption_limit_period):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if redemption_limit_coupon == "Multi Use" and campaign_type in type_unlimited:
                if redemption_limit_period == 'Unlimited':
                    checked_att = self.get_attribute_value("checked", *self._unlimited_box)
                    if (checked_att == True):
                        log.info("redemption limit per period coupon type- {0} radio button found checked".format(redemption_limit_period))
                    else:
                        status &= self.click_using_javascript(*self._unlimited_box)
                        log.info("redemption limit per period  coupon type- {0} selected successfully in reward tab".format(redemption_limit_period))
                if redemption_limit_period == 'limited':
                    checked_att = self.get_attribute_value("checked", *self._limited_box)
                    if (checked_att == True):
                        log.info("redemption limit per period coupon type- {0} radio button found checked".format(
                            redemption_limit_period))
                    else:
                        status &= self.click_using_javascript(*self._limited_box)
                        log.info("redemption limit per period  coupon type- {0} selected successfully in reward tab".format(redemption_limit_period))
                        status &= self.enter("1", *self._value_input)
                        log.info("redemption limit per period value entered successfully in reward tab")
                if self.is_checked(self._min_time_redemption_id) == True:
                    log.info("Min Time Between Redemptions  radio button is enabled already")
                else:
                    status &= self.click_using_javascript(*self._min_time_redemption)
                    status &= self.enter(5,*self._sec_box)
                    log.info("Min Time Between Redemptions radio button is enabled successfully")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("select scheme product point in reward tab")
    def select_scheme_product_point(self):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_product_point)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("enter tier in reward tab")
    def enter_product_spend_values(self, min, max, interval):
        """
         method to enter tier values in reward tab
        :param: min,max,interval
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._min_spend_product)
            status &= self.enter(min, *self._min_spend_product)
            log.info("min basket spend value entered successfully in  reward tab")
            status &= self.enter(max, *self._max_spend_product)
            log.info("max basket spend  value entered successfully in  reward tab")
            status &= self.enter(interval, *self._interval_product)
            log.info("interval basket spend  value entered successfully in  reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering basket spend in reward tab").format(e)
        return status

    @allure.step("select scheme product point in reward tab")
    def select_scheme_product_point_variable(self):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_product_variable)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("select scheme product spend point variable in reward tab")
    def select_scheme_product_spend_point_variable(self):
        """
        method to select scheme in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._scheme_product_spend_variable)
            status &= self.click(*self._scheme_value)
            log.info("select scheme per transaction successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting scheme in reward tab").format(e)
        return status

    @allure.step("enter tier in reward tab")
    def enter_basket_spend_values(self, min, max, interval):
        """
         method to enter tier values in reward tab
        :param: min,max,interval
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._min_spend_)
            status &= self.enter(min, *self._min_spend_)
            log.info("min basket spend value entered successfully in  reward tab")
            status &= self.enter(max, *self._max_spend_)
            log.info("max basket spend  value entered successfully in  reward tab")
            status &= self.enter(interval, *self._interval_)
            log.info("interval basket spend  value entered successfully in  reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering basket spend in reward tab").format(e)
        return status






"""
page object model for create new campaign page
"""
import datetime
import random

import allure
from selenium.webdriver.common.by import By
from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage

class EECampaignPage(SeHelperPage):
    """
    Class consists of create new campaign objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    _campaign_header = (By.XPATH, "//div[@id='main-page-title']//h2")
    _select_campaign_type = "//div[@id='campaign-types-flexbox']//span[contains(text(),'{}')]"
    _create_campaign_page = "//div[@id='creator-header']//h3[contains(text(),'Create Campaign: {} ')]"

    #GEDigital elements
    _select_gedigital_tab = (By.XPATH, "//li[@data-section='geplc-ge-digital-210']")
    distribution_check_box_id = "campaign-properties-distributionChannelsTemp-channels-gedigital-active-"
    _distribution_check_box_id = (By.XPATH, "//label[@for='campaign-properties-distributionChannelsTemp-channels-gedigital-active-']")
    _offer_display_name = (By.ID, "campaign-properties-distributionChannelsTemp-channels-gedigital-data-offerDisplayName-fieldData-input" )
    _upload_file_btn = (By.XPATH, "//input[@type='file']")
    _offer_desc = (By.ID, "campaign-properties-distributionChannelsTemp-channels-gedigital-data-offerDescription-fieldData-textarea")
    _ge_digital_btn = (By.XPATH, "//div[@id='creator-footer']//button[contains(text(),'GEDigital')]")
    _ge_misc_nav_btn = (By.XPATH, "//div[@id='creator-footer']//button[contains(text(),'GE Misc. Accounts')]")


    #GEmisc account elements
    _select_gemiscacc_tab = (By.XPATH, "//li[@data-section='geMiscAccounts-590']")
    _misc_account = (By.XPATH, "//span[@title=' 288 - Promotional Expense  ***  DEFAULT for Marketing Campaigns ']")
    _misc_acc_value = (By.XPATH, "//ul[@role='listbox']//li[6]")
    _receipt_details_btn = (By.XPATH, "//div[@id='creator-footer']//button[2]")


    # Receipt details elements
    _select_receiptdetail_tab = (By.XPATH, "//li[@data-section='receiptDetails-659']")
    _display_name = (By.ID, "campaign-properties-campaign-v2-custom-receiptDetails-displayNameForReceipt-input")
    receipt_details_check_box = "campaign-custom-form-receiptDetails-active-"


    @allure.step("Verify if create new campaign page is displayed")
    def verify_campaign_page(self):
        """
        method to verify create new campaign page is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._campaign_header)
            log.info("create new campaign page is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign page".format(e))
        return status

    @allure.step("Create campaigns by Campaign type ")
    def create_by_campaign_type(self, campaign_type):
        """
        method to Create campaigns by Campaign type
        :param: Campaign type
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            type_val = self.wait_and_find_ele_by_xpath(self._select_campaign_type.format(campaign_type))
            status &= self.click_element(type_val)
            log.info("selection of create new campaigns type {} clicked successfully ".format(campaign_type))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns type {1}").format(e, campaign_type)
        return status

    @allure.step("Verify create new campaign page is displayed after the selection of type")
    def verify_create_campaign_page(self, campaign_type):
        """
        method to verify create new campaign page is displayed after the selection of type
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            ele = self.wait_and_find_ele_by_xpath(self._create_campaign_page.format(campaign_type))
            status &= self.ele_displayed(ele)
            log.info("create new campaign page is verified after the selection of type")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign page after the selection of type".format(e))
        return status

    #GEDigital Tab methods
    @allure.step("select create campaigns by gedigital tab")
    def select_by_gedigital_tab(self):
        """
        method to select create campaigns by gedigital tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._select_gedigital_tab)
            log.info("selection of create new campaigns gedigital tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns gedigital tab").format(e)
        return status

    @allure.step("Verify if create new campaign gedigital tab screen is displayed")
    def verify_gedigital_tab_screen(self):
        """
        method to verify create new campaign gedigital tab screen  is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_gedigital_tab)
            log.info("create new campaign page gedigital tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign  gedigital tab page".format(e))
        return status

    @allure.step("click GEDigital button in reward tab")
    def click_GEDigital_btn(self):
        """
        method to click GEDigital button in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._ge_digital_btn)
            log.info("GEDigital button clicked successfully in reward tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking GEDigital button in reward tab").format(e)
        return status

    @allure.step("enable distribution channel button in GEDigital tab")
    def click_distribution_channel_btn(self):
        """
        method to distribution channel button in GEDigital tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if self.is_checked(self.distribution_check_box_id) == True:
                log.info("distribution channel button enabled already in GEDigital tab")
            else:
                status &= self.click(*self._distribution_check_box_id)
                log.info("distribution channel button enabled in GEDigital tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking GEDigital button in GEDigital tab").format(e)
        return status

    @allure.step("Enter offer display name in GEDigital tab")
    def enter_offer_display_name(self, campaign_name, campaign_type):
        """
        method to enter offer display name in GEDigital tab
        :param: campaign_name
        :param: campaign_type
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.wait_for_element(self._offer_display_name)
            campaign_offer_name = campaign_name +"_"+campaign_type
            status &= self.enter(campaign_offer_name, *self._offer_display_name)
            log.info("entered offer display name successfully in GEDigital tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering offer display name in GEDigital tab").format(e)
        return status

    @allure.step("upload offer image file in GEDigital tab")
    def upload_offer_image_file(self, file_path):
        """
        method to upload offer image file in GEDigital tab
        :param: file_path
        :return: status
        """
        status = True
        try:
            self.wait_for_element(self._upload_file_btn)
            self.scroll_to_element(*self._upload_file_btn)
            choose_btn = self.find_element(*self._upload_file_btn)
            self.custom_time_wait(3)
            choose_btn.send_keys(file_path)
            self.wait_for_page_load_complete()
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while uploading image file in GEDigital tab").format(e)
        return status

    @allure.step("Enter offer desc in GEDigital tab")
    def enter_offer_desc(self, offer_desc):
        """
        method to enter offer desc in GEDigital tab
        :param: offer_desc
        :return: status
        """
        status = True
        try:
            self.wait_for_element(self._offer_desc)
            self.scroll_to_element(*self._offer_desc)
            status &= self.enter(offer_desc, *self._offer_display_name)
            log.info("entered offer description successfully in GEDigital tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering offer description in GEDigital tab").format(e)
        return status


    #GEmisc account method
    @allure.step("select create campaigns by gemiscacc tab")
    def select_by_gemiscacc_tab(self):
        """
        method to select create campaigns by gemiscacc tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._select_gemiscacc_tab)
            log.info("selection of create new campaigns gemiscacc tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns gemiscacc tab").format(e)
        return status

    @allure.step("Verify if create new campaign gemiscacc tab screen is displayed")
    def verify_gemiscacc_tab_screen(self):
        """
        method to verify create new campaign gemiscacc tab screen  is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_gemiscacc_tab)
            log.info("create new campaign page gemiscacc tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign gemiscacc tab page".format(e))
        return status

    @allure.step("click GEmisc account button in GEDigital tab")
    def click_GEmiscacc_btn(self):
        """
        method to click GEDigital button in reward tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._ge_misc_nav_btn)
            log.info("GEmisc account button clicked successfully in GEDigital tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking GEmisc account button in GEDigital tab").format(e)
        return status

    @allure.step("select GEmisc account ID in GEmisc tab")
    def select_miscacc_id(self):
        """
        method to select GEmisc account ID in GEmisc tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._misc_account)
            status &= self.click_using_javascript(*self._misc_acc_value)
            log.info("GEmisc account ID selected successfully in GEmisc tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selecting GEmisc account ID in GEmisc tab").format(e)
        return status


    #Receiptdetail method
    @allure.step("select create campaigns by receiptdetail tab")
    def select_by_receiptdetail_tab(self):
        """
        method to select create campaigns by receiptdetail tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._select_receiptdetail_tab)
            log.info("selection of create new campaigns receiptdetail tab clicked successfully ")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while selection of create new campaigns receiptdetail tab").format(e)
        return status

    @allure.step("Verify if create new campaign receiptdetail tab screen is displayed")
    def verify_receiptdetail_tab_screen(self):
        """
        method to verify create new campaign receiptdetail tab screen is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._select_receiptdetail_tab)
            log.info("create new campaign page receiptdetail tab is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying create new campaign receiptdetail tab page".format(e))
        return status

    @allure.step("click receipt details button in GEmisc account tab")
    def click_receiptdetail_btn(self):
        """
        method to click receipt details button in GEmisc account tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click(*self._receipt_details_btn)
            log.info("receipt details button clicked successfully in GEmisc account tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking receipt details button in GEmisc account tab").format(e)
        return status

    @allure.step("enter display name in receipt details tab")
    def enter_receipt_disply_name(self, campaign_name):
        """
        method to enter receipt display name in receipt details tab
        :param: campaign_name
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            receipt_display_name = campaign_name + "_" + "receipt"
            status &= self.enter(receipt_display_name, *self._display_name)
            log.info("receipt display name entered successfully in receipt details tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while entering receipt display name in receipt details tab").format(e)
        return status

    @allure.step("enable receipt details button in receipt details tab")
    def enable_receipt_details_btn(self):
        """
        method to enable receipt details button in receipt details tab
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            if self.is_checked(self.receipt_details_check_box) == True:
                log.info("receipt details button enabled already in receipt details tab")
            else:
                status &= self.click_using_javascript(*self.receipt_details_check_box)
                log.info("receipt details button enabled in receipt details tab")
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while enabling receipt details button in receipt details tab").format(e)
        return status









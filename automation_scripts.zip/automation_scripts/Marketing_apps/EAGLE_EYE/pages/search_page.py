"""
page object model for search page
"""
import datetime
import re
import allure
from selenium.webdriver.common.by import By
from conftest import log
from seleniumhelper.sehelperpage import SeHelperPage
from Marketing_apps.EAGLE_EYE.resources.constants import Common, Approval, Other, type_val

class EESearchPage(SeHelperPage):
    """
    Class consists of search page objects and methods
    """
    test = ""

    def __init__(self, driver):
        SeHelperPage.__init__(self, driver)
        self.driver = driver

    # search elements
    _searchpage_header = (By.XPATH, "//div[@id='main-page-title']//h2")
    _campaign_name_search = (By.XPATH, "//input[@id='campaign-search-name']")
    _campaign_id_search = (By.XPATH, "//input[@id='campaignNameQuery']")
    _type_search = (By.XPATH, "//select[@id='campaignTypeId']/following::input[1]")
    _type_values = "//ul[@id='select2-campaignTypeId-results']//li[contains(text(),'{}')]"

    #status elements
    _status_search = (By.XPATH, "//select[@id='campaign-status-select']/following::input[1]")
    _common_status_value = "//ul[@id='select2-campaign-status-select-results']//li//strong[contains(text(),'Common')]//following::ul//li[contains(text(),'{}')]"
    _approval_status_value = "//ul[@id='select2-campaign-status-select-results']//li//strong[contains(text(),'Approval')]//following::ul//li[contains(text(),'{}')]"
    _other_status_value = "//ul[@id='select2-campaign-status-select-results']//li//strong[contains(text(),'Other')]//following::ul//li[contains(text(),'{}')]"

    #date elements
    _start_date_search = (By.XPATH, "//input[@name='startDate']")
    _selected_date_val = (By.XPATH, "//span[@class='drp-selected']")
    _search_btn = (By.XPATH, "//button[@id='btn-campaign-search']")
    _clear_btn  = (By.XPATH, "//button[@id='btn-campaign-reset']")
    _calender_apply_btn = (By.XPATH, "//button[text()='Apply']")
    _calender_cancel_btn = (By.XPATH, "//button[text()='Cancel']")
    _today_calender = (By.XPATH, "//li[text()='Today']")
    _yesterday_calender = (By.XPATH, "//li[text()='Yesterday']")
    _last_7_days_calender = (By.XPATH, "//li[text()='Last 7 Days']")
    _last_30_days_calender = (By.XPATH, "//li[text()='Last 30 Days']")
    _this_month_calender = (By.XPATH, "//li[text()='This Month']")
    _last_month_calender = (By.XPATH, "//li[text()='Last Month']")
    _table_rows = (By.XPATH, "//table[@id='campaign-search-table']//tbody//tr")
    _empty_field = (By.XPATH, "//td[@class='dataTables_empty']")

    # results td elements
    _campaign_name_td_row = (By.XPATH, "//table[@id='campaign-search-table']//tbody//tr[1]//td[1]")
    _campaign_id_td_row = (By.XPATH, "//table[@id='campaign-search-table']//tbody//tr[1]//td[2]")
    _campaign_type_td_row = (By.XPATH, "//table[@id='campaign-search-table']//tbody//tr[1]//td[4]")
    _campaign_status_td_row = (By.XPATH, "//table[@id='campaign-search-table']//tbody//tr[1]//td[8]")
    _campaign_date_td_row_start_date = (By.XPATH, "//table[@id='campaign-search-table']//tbody//tr[1]//td[6]//div[2]")
    _campaign_date_td_row_end_date = (By.XPATH, "//table[@id='campaign-search-table']//tbody//tr[1]//td[6]//div[3]")

    campaign_date = ''


    @allure.step("Verify if search page is displayed")
    def verify_search_page(self):
        """
        method to verify search page is displayed
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.isdisplayed(*self._searchpage_header)
            log.info("search page is verified")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying search page".format(e))
        return status

    @allure.step("search campaigns by Campaign Name ")
    def search_by_campaign_name(self, campaign_name):
        """
        method to search campaigns by Campaign Name
        :param: campaign_name
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._campaign_name_search)
            status &= self.enter(campaign_name, *self._campaign_name_search)
            log.info("campaigns clicked successfully and entered the {} in the search box".format(campaign_name))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking campaigns and entering the {1} in the search box".format(e,campaign_name))
        return status

    @allure.step("search campaigns by Campaign ID ")
    def search_by_campaign_id(self, campaign_id):
        """
        method to search campaigns by Campaign id
        :param: campaign_id
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._campaign_id_search)
            status &= self.enter(campaign_id, *self._campaign_id_search)
            log.info("campaigns clicked successfully and entered the {} in the search box".format(campaign_id))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking campaigns and entering the {1} in the search box".format(e, campaign_id))
        return status

    @allure.step("search campaigns by type")
    def search_by_campaign_type(self, campaign_type):
        """
        method to search campaigns by type select one or more types
        :param: campaign_type
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            for value in campaign_type:
                status &= self.click_using_javascript(*self._type_search)
                if value in type_val:
                    type_path = self.wait_and_find_ele_by_xpath(self._type_values.format(value))
                    status &= self.click_element(type_path)
                    log.info("campaigns clicked successfully and entered the {} in the search box".format(value))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking campaigns and entering the {1} in the search box".format(e,
                                                                                                                      type))
        return status

    @allure.step("search campaigns by status")
    def search_by_campaign_status(self, status_val):
        """
        method to search campaigns by status select one or more statuses
        :param: status_val
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            for value in status_val:
                status &= self.click_using_javascript(*self._status_search)
                self.custom_time_wait(2)
                if value in Common:
                    common_path = self.wait_and_find_ele_by_xpath(self._common_status_value.format(value))
                    status &= self.click_element(common_path)
                    log.info("status {} is selected successfully under Common".format(value))
                if value in Approval:
                    approval_path = self.wait_and_find_ele_by_xpath(self._approval_status_value.format(value))
                    status &= self.click_element(approval_path)
                    log.info("status {} is selected successfully under Approval".format(value))
                if value in Other:
                    other_path = self.wait_and_find_ele_by_xpath(self._other_status_value.format(value))
                    status &= self.click_element(other_path)
                    log.info("status {} is selected successfully under Other".format(value))
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking campaigns and entering the {1} in the search box".format(e,
                                                                                                                      status_val))
        return status

    @allure.step("search campaigns by start date")
    def search_by_campaign_start_date(self, start_date):
        """
        method to search campaigns by start date
        :param: start_date
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._start_date_search)
            if start_date == 'Today':
                status &= self.click_using_javascript(*self._today_calender)
                log.info("today date is selected")
            elif start_date == 'yesterday':
                status &= self.click_using_javascript(*self._yesterday_calender)
                log.info("yesterday date is selected")
            elif start_date == 'Last 7 Days':
                status &= self.click_using_javascript(*self._yesterday_calender)
                log.info("Last 7 Daysis selected")
            elif start_date == 'Last 30 Days':
                status &= self.click_using_javascript(*self._yesterday_calender)
                log.info("Last 30 Days is selected")
            elif start_date == 'This Month':
                status &= self.click_using_javascript(*self._yesterday_calender)
                log.info("This Month is selected")
            elif start_date == 'Last Month':
                status &= self.click_using_javascript(*self._yesterday_calender)
                log.info("Last Month is selected")
            elif start_date != '':
                 self.driver.execute_script('document.getElementById("campaign-search-start-date").value ="{}"'.format(start_date))
                 log.info("date range is - {0} is selected".format(start_date))
                 self.custom_time_wait(2)
            campaign_date = self.get_text(*self._selected_date_val)
        except Exception as e:
            status &= False
            log.error("Exception occurred {0} while clicking campaigns and entering the {1} in the search box".format(e,
                                                                                                                      start_date))
        return status, campaign_date

    @allure.step("click search button")
    def click_search_btn(self):
        """
        method to click search button
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._search_btn)
            self.custom_time_wait(2)
            log.info("search button clicked successfully in the search page")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while clicking search button in the search page".format(e))
        return status

    @allure.step("click clear button")
    def click_clear_btn(self):
        """
        method to click clear button
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            status &= self.click_using_javascript(*self._clear_btn)
            self.custom_time_wait(3)
            log.info("search button clicked successfully in the search page")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while clicking clear button in the search page".format(e))
        return status

    @allure.step("Verify if search result is displayed by name")
    def verify_search_results_by_name(self, campaign_name):
        """
        method to verify search campaign name result is displayed
        :param: campaign_name
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._table_rows)
            self.custom_time_wait(3)
            ele = self.find_elements(*self._table_rows)
            rows_count = len(ele)
            if rows_count > 0:
               campaign_name_val = self.get_text(*self._campaign_name_td_row)
               self.custom_time_wait(3)
               (log.info("search results matched by name successfully")) if campaign_name_val == campaign_name else (log.error("the given campaign name don't match with fetched result"))
            else:
                log.error("No matched name search results found")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying search page by name".format(e))
        return status

    @allure.step("Verify if search result is displayed by id")
    def verify_search_results_by_id(self, campaign_id):
        """
        method to verify search by campaign id result is displayed
        :param: campaign_id
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._table_rows)
            self.custom_time_wait(3)
            ele = self.find_elements(*self._table_rows)
            rows_count = len(ele)
            if rows_count > 0:
                campaign_id_val = self.get_text(*self._campaign_id_td_row)
                self.custom_time_wait(3)
                (log.info("search results matched by id successfully")) if campaign_id_val == campaign_id else (
                    log.error("the given campaign id don't match with fetched result"))
            else:
                log.error("No matched id search results found")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying search page by id".format(e))
        return status

    @allure.step("Verify if search result is displayed by status")
    def verify_search_results_by_status(self, status_val):
        """
        method to verify search by campaign status result is displayed
        :param: status_val
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._table_rows)
            self.custom_time_wait(3)
            ele = self.find_elements(*self._table_rows)
            rows_count = len(ele)
            if rows_count > 0:
                for value in status_val:
                    campaign_status_val = self.get_text(*self._campaign_status_td_row)
                self.custom_time_wait(3)
                (log.info("search results matched by status successfully")) if campaign_status_val == value else (
                    log.info("the given campaign status don't match with fetched result by status"))
            else:
                log.error("No matched status search results found")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying search page by status".format(e))
        return status

    @allure.step("Verify if search result is displayed by type")
    def verify_search_results_by_type(self, type_val):
        """
        method to verify search by campaign type result is displayed
        :param: type_val
        :return: status
        """
        status = True
        try:
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._table_rows)
            self.custom_time_wait(3)
            ele = self.find_elements(*self._table_rows)
            rows_count = len(ele)
            if rows_count > 0:
                for value in type_val:
                    campaign_type_val = self.get_text(*self._campaign_type_td_row)
                self.custom_time_wait(3)
                (log.info("search results matched by type successfully")) if campaign_type_val == value else (
                    log.info("the given campaign status don't match with fetched result by type"))
            else:
                log.error("No matched status search results found")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying search page by status".format(e))
        return status

    @allure.step("Verify if search result is displayed by date")
    def verify_search_results_by_date(self, campaign_date):
        """
        method to verify search by campaign date result is displayed
        :param: campaign_date
        :return: status
        """
        status = True
        try:
            date = campaign_date
            start_date =  datetime.datetime.strptime((date.split(' ')[0]), "%Y-%m-%d")
            actual_start_date = start_date.strftime("%d %B %Y")
            self.wait_for_page_load_complete()
            self.scroll_to_element(*self._table_rows)
            empty_text = self.get_text(*self._empty_field)
            if empty_text != 'No matching records found':
                start_date_val = ((self.get_text(*self._campaign_date_td_row_start_date)).split('Start: ')[1])
                resulted_start_date = re.split(r'(.*?\s.*?\s.*?)\s', start_date_val)[1]
                self.custom_time_wait(3)
                (log.info("search results matched by date successfully")) if resulted_start_date == actual_start_date else (
                    log.info("the given campaign don't match with fetched result by date"))
            else:
                log.error("No matched date search results found")
        except Exception as e:
            status &= False
            log.error("Exception occurred {} while verifying search page by date".format(e))
        return status



import os
import allure
import pytest

import output_data_set
from EAGLE_EYE.pages.Summary_page import EESummarytabPage
from EAGLE_EYE.pages.create_campaign_page import EECampaignPage
from EAGLE_EYE.pages.creation_page import EECreationtabPage
from EAGLE_EYE.pages.general_page import EEGeneraltabPage
from EAGLE_EYE.pages.login_page import LoginPage
from EAGLE_EYE.pages.home_page import EEHomePage
from EAGLE_EYE.pages.qualification_page import EEqualificationtabPage
from EAGLE_EYE.pages.reward_page import EErewardtabPage
from EAGLE_EYE.pages.search_page import EESearchPage
from EAGLE_EYE.resources.constants import URL, USER, PSWD, TEST_DATA_PATH, RESULTS_PATH, OUTPUT_PATH
from custom_csv_output_file import OutputresultPage
from utils.file_operations import create_folder
from parsers import __parser

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_data_59248.json'),
                             ['CAMPAIGN_NAME', 'CAMPAIGN_DESC', 'CAMPAIGN_MODE', 'CAMPAIGN_TYPE', 'CLIENT_ACC_TYPE', 'START_DATE','END_DATE','COUPON_EXPIRY','REDEMPTION_PARTNER', 'QUALIFIER','BASKET_AMOUNT','MAX_REWARD',
                              'REWARD_TIER', 'REDEMPTION_LIMIT_COUPON', 'OFFER_DESC', 'SPEND_FROM_TIER','SPEND_UPTO_TIER','POINTS', 'MAX_REDEMPTIONS'])


@pytest.mark.regression
@pytest.mark.parametrize('campaign_name, campaign_desc, campaign_mode, campaign_type, client_acc_type, start_date, end_date, coupon_expiry, redemption_partner, qualifier, basket_amount, max_reward, reward_tier, redemption_limit_coupon, offer_desc, spend_from_tier, spend_upto_tier, points, max_redemptions', params)
@allure.description("Verify user is able to create Tiered Spend For Points Campaign and send for approval for giant eagle and getgo")
def test_59248_tiered_spend_for_points(init_driver, campaign_name, campaign_desc, campaign_mode, campaign_type, client_acc_type, start_date, end_date, coupon_expiry,
               redemption_partner, qualifier, basket_amount, max_reward, reward_tier, redemption_limit_coupon, offer_desc, spend_from_tier, spend_upto_tier, points, max_redemptions):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = EEHomePage(driver)
    search_page = EESearchPage(driver)
    campaign_page = EECampaignPage(driver)
    general_page = EEGeneraltabPage(driver)
    creation_page = EECreationtabPage(driver)
    qualification_page = EEqualificationtabPage(driver)
    reward_page = EErewardtabPage(driver)
    summary_page = EESummarytabPage(driver)
    output_page = OutputresultPage(driver)
    output_data_set.file_path = OUTPUT_PATH
    output_data_set.output_dict = output_data_set.campaign_output_set

    assert login_page.launch_application(URL), 'Failed to browse the URl of an application '
    assert login_page.sign_in(USER, PSWD), 'Failed to login into the application'
    assert home_page.verify_home_page(), 'Failed to load Home Page'
    assert home_page.select_campaign_sidebar(), 'Failed to select campaign from sidebar'
    assert home_page.select_create_new_sidebar(), ' Failed to click on the create new sidebar'
    assert campaign_page.verify_campaign_page(), 'Failed to load create campaign Page'

    assert campaign_page.create_by_campaign_type(campaign_type), 'Failed to click on campaign type'
    assert campaign_page.verify_campaign_page(), 'Failed to load create campaign Page'

    assert general_page.select_by_general_tab(), 'Failed to select general tab'
    assert general_page.verify_general_tab_screen(), 'Failed to verify  genearal tab'
    campaign_name = general_page.enter_campaign_name(campaign_name)
    assert general_page.enter_campaign_desc(campaign_desc), 'Failed to Enter Campaign Desc'
    assert general_page.select_campaign_mode(campaign_mode), 'Failed to select Campaign mode'
    assert general_page.select_client_acc(client_acc_type), 'Failed to select client account type'
    assert general_page.enter_start_date(start_date), 'Failed to enter start date'
    assert general_page.enter_end_date(end_date), 'Failed to enter end date'
    assert creation_page.click_creation_btn(), 'Failed to click create button in general tab'

    assert creation_page.select_by_creation_tab(), 'Failed to select creation tab'
    assert creation_page.verify_creation_tab_screen(), 'Failed to verify  creation tab'
    assert creation_page.select_coupon_expiry_btn(coupon_expiry), 'Failed to select coupon expiry in creation tab'
    assert creation_page.select_redemption_partner(redemption_partner), 'Failed to select 1st redemption partner'
    assert qualification_page.click_qualification_btn(), 'Failed to click qualification button in creation tab'

    assert qualification_page.select_by_qualification_tab(), 'Failed to select qualification tab'
    assert qualification_page.verify_qualification_tab_screen(), 'Failed to verify  qualification tab'
    assert qualification_page.select_qualifier_apply_btn(qualifier, basket_amount), 'Failed to select qualifier applies to button'
    assert qualification_page.select_reward_tier(reward_tier), 'Failed to select reward tier'
    assert reward_page.click_reward_btn(), 'Failed to click reward button in qualification tab'

    assert reward_page.select_by_reward_tab(), 'Failed to select reward tab'
    assert reward_page.verify_reward_tab_screen(), 'Failed to verify reward tab'
    assert reward_page.enter_max_reward_per_transc(max_reward), ' Failed to enter max reward in reward tab'
    assert reward_page.click_redeem_check_box(), ' Failed to click Create separate Redeem Account Transactions'
    assert reward_page.select_scheme_tiered_points(), 'Failed to select scheme in reward tab'
    assert reward_page.enter_tier_values(spend_from_tier,spend_upto_tier,points), 'Failed to select discount type in reward tab'
    assert reward_page.select_redemption_limit_per_transc(redemption_limit_coupon, max_redemptions), 'Failed to select redemption limit per transaction in reward tab'
    assert campaign_page.click_GEDigital_btn(), 'Failed to click GEDigital button in reward tab'

    assert campaign_page.select_by_gedigital_tab(), 'Failed to select GEDigital tab'
    assert campaign_page.verify_gedigital_tab_screen(), 'Failed to verify GEDigital tab'
    assert campaign_page.click_distribution_channel_btn(), 'Failed to click the enable GEDigital check box in GEDigital tab'
    assert campaign_page.enter_offer_display_name(campaign_name, campaign_type), 'Failed to enter offer display name in GEDigital tab'
    # assert campaign_page.upload_offer_image_file(), 'Failed to upload offer image file in GEDigital tab'
    assert campaign_page.enter_offer_desc(offer_desc), 'Failed to enter offer desc in GEDigital tab'
    assert campaign_page.click_receiptdetail_btn(), 'Failed to click receipt details button in  gemiscacc tab'

    assert campaign_page.select_by_receiptdetail_tab(), 'Failed to select receiptdetail tab'
    assert campaign_page.verify_receiptdetail_tab_screen(), 'Failed to verify receiptdetail tab'
    assert campaign_page.enter_receipt_disply_name(campaign_name), 'Failed to enter receipt display name in receiptdetail tab'
    assert summary_page.click_summary_btn(), 'Failed to click receipt details button in receiptdetail tab'

    assert summary_page.select_by_summary_tab(), 'Failed to select summary tab'
    assert summary_page.verify_summary_tab_screen(), 'Failed to verify summary tab'
    assert summary_page.validate_summary_details(campaign_name, campaign_mode, start_date, end_date), 'Failed to validate summary details in summary tab'
    assert summary_page.click_approve_btn(), 'Failed to click on approve button'
    assert summary_page.click_save_btn(), 'Failed to click on save button'
    campaign_id = summary_page.verify_camapign_success_creation()

    assert output_page.collect_values(campaign_id, campaign_name, campaign_type, start_date,
                                      end_date), " Failed to store the values into custom csv output file"

    assert login_page.log_out_user(), 'Failed to logout from the application'

import os
import allure
import pytest
from EAGLE_EYE.pages.login_page import LoginPage
from EAGLE_EYE.pages.home_page import EEHomePage
from EAGLE_EYE.pages.search_page import EESearchPage
from EAGLE_EYE.resources.constants import URL, USER, PSWD, TEST_DATA_PATH, RESULTS_PATH
from utils.file_operations import create_folder
from parsers import __parser

params = __parser.parse_json(os.path.join(TEST_DATA_PATH, 'test_data_56783.json'),
                             ['CAMPAIGN_NAME', 'CAMPAIGN_ID', 'TYPE', 'STATUS', 'START_DATE'])


@pytest.mark.regression
@pytest.mark.parametrize('campaign_name, campaign_id, type, status, start_date', params)
@allure.description("Verify user is able to search the Campaign")
def test_56783(init_driver, campaign_name, campaign_id, type, status, start_date):
    create_folder(RESULTS_PATH)
    driver = init_driver
    login_page = LoginPage(driver)
    home_page = EEHomePage(driver)
    search_page = EESearchPage(driver)

    assert login_page.launch_application(URL), 'Failed to browse the URl of an application '
    assert login_page.sign_in(USER, PSWD), 'Failed to login into the application'
    assert home_page.verify_home_page(), 'Failed to load Home Page'
    assert home_page.select_campaign_sidebar(), 'Failed to select campaing from sidebar'
    assert home_page.select_search_sidebar(), ' Failed to click on the search sidebar'
    assert search_page.verify_search_page(), 'Failed to load search Page'

    assert search_page.click_clear_btn(), 'Failed to click clear button'
    assert search_page.search_by_campaign_name(campaign_name), ' Failed to search by campaign name'
    assert search_page.click_search_btn(), ' Failed to click on the search button'
    assert search_page.verify_search_results_by_name(campaign_name), ' Failed to verify search by campaign name'

    assert search_page.click_clear_btn(), 'Failed to click clear button'
    assert search_page.search_by_campaign_id(campaign_id), ' Failed to search by campaign id'
    assert search_page.click_search_btn(), ' Failed to click on the search button'
    assert search_page.verify_search_results_by_id(campaign_id), ' Failed to verify search by campaign id'

    assert search_page.click_clear_btn(), 'Failed to click clear button'
    assert search_page.search_by_campaign_type(type), ' Failed to search by campaign type'
    assert search_page.click_search_btn(), ' Failed to click on the search button'
    assert search_page.verify_search_results_by_type(type), ' Failed to verify search by campaign type'

    assert search_page.click_clear_btn(), 'Failed to click clear button'
    assert search_page.search_by_campaign_status(status), 'Failed to search by campaign status'
    assert search_page.click_search_btn(), 'Failed to click on the search button'
    assert search_page.verify_search_results_by_status(status), 'Failed to verify search by campaign status'

    assert search_page.click_clear_btn(), 'Failed to click clear button'
    assert search_page.search_by_campaign_start_date(start_date), ' Failed to search by campaign start date'
    assert search_page.click_search_btn(), ' Failed to click on the search button'
    assert search_page.verify_search_results_by_date(start_date), ' Failed to verify search by campaign name'

    assert login_page.log_out_user(), 'Failed to logout from the application'

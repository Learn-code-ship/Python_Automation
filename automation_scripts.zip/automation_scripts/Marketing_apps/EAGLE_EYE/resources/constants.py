import datetime
import os
from os.path import dirname, abspath
from utils.file_operations import load_db_config_file

RESULTS_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'results')
RESOURCE_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'resources')
TEST_DATA_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'resources', 'Testdata')
REPORT_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'results',
                           datetime.datetime.now().strftime('%m%d%Y'))
OUTPUT_PATH = os.path.join(dirname(dirname(abspath(__file__))), 'results', 'output.csv')

URL = load_db_config_file('EAGLE_EYE', "url")
USER = load_db_config_file('EAGLE_EYE', "email_id")
PSWD = load_db_config_file('EAGLE_EYE', "password")


Common = ["Active", "Ready", "Draft"]
Approval = ["Pending", "Rejected"]
Other = ["Inactive", "Suspended", "Stopped", "Deleted", "Expired"]
type_val = ["BOGO", "Basket Points Multiplier", "Basket Spend Points Variable", "Continuity", "Discount Basket",
            "Discount Products", "Points Fixed", "Product Points Multiplier", "Product Spend Points Variable",
            "Product Units Points Variable", "Tiered Spend For Points"]
redemption_partner_val = ["Giant Eagle", "Get Go"]
type_unlimited = ["Basket Points Multiplier", "Product Points Multiplier", "Product Units Points Variable"]
discount = ["free", "fixed", "fixed-price", "percentage", "value-interval", "tax-saver"]















import inspect
import logging
import sys


def custom_logger(log_level=logging.DEBUG):
    """
    method to create new instance of logger
    :param log_level:
    :return: logger object
    """
    # Gets the name of the class / method from where this method is called
    logger_name = inspect.stack()[1][3]
    logger = logging.getLogger(logger_name)
    if not logger.hasHandlers():
        # By default, log all messages
        logger.setLevel(logging.DEBUG)
        #  add file handler
        file_name = "Automation".format(logger_name)
        file_handler = logging.FileHandler(file_name, mode='a')
        file_handler.setLevel(log_level)

        formatter = logging.Formatter(
            '%(asctime)s - %(filename)s:%(lineno)d - %(levelname)s: %(message)s',
            datefmt='%m/%d/%y %H:%M:%S')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        # add console handler
        stream_handler = logging.StreamHandler(sys.stderr)
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

    return logger


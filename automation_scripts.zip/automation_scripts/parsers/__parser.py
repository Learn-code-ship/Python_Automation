import pandas


def parse_csv(file, col_arr):
    """
    Method to read csv file
    :param file: file path
    :param col_arr: column names array
    :return: tuples of values
    """
    df = pandas.read_csv(file, dtype=str, encoding='utf-8').fillna('')
    subset = df[col_arr]
    concat = [''.join(row) for row in subset.values]
    tuples = list(map(list, zip(concat)))
    return tuples


def parse_xl(file, col_arr):
    """
       Method to read excel file
       :param file: file path
       :param col_arr: column names array
       :return: tuples of values
       """
    df = pandas.read_excel(file)
    subset = df[col_arr]
    tuples = [tuple(x) for x in subset.values]
    return tuples


def parse_json(file, col_arr):
    """
       Method to read json file
       :param file: file path
       :param col_arr: column names array
       :return: tuples of values
       """
    df = pandas.read_json(file, encoding='utf-8-sig')
    subset = df[col_arr]
    tuples = [tuple(x) for x in subset.values]
    return tuples

# GE.Marketing.Automation
Qa automation Suite for GE.Marketing

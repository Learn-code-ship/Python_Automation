import os
import pathlib
from os.path import dirname, realpath
from pathlib import Path

from utils.file_operations import load_db_config_file

EXECUTION_MODE = 'Run'  # change value to 'Debug' to stop browser from closing
RESOURCES_DATA_PATH = os.path.join(Path(__file__).parent.parent, 'resources')
TEST_RESULTS_PATH = os.path.join(os.getcwd(), 'results')
CHROME_DRIVER = os.path.join((dirname(realpath(__file__))), 'chromedriver.exe')
BROWSER = load_db_config_file('RunSettings', "browser")

JAR_FILE_PATH = os.path.join(Path(__file__).parent.parent, 'configuration//ojdbc11-full//ojdbc8.jar')
RESULT = os.path.join(pathlib.Path.cwd().parent, 'results')
CHROME_PATH  = os.path.join(Path(__file__).parent.parent, 'configuration//chromedriver.exe')
DOWNLOAD_PATH = os.path.join(Path(__file__).parent.parent, 'downloads')
ERROR_FILE_PATH = os.path.join(Path(__file__).parent.parent, 'failed_error_file.csv')

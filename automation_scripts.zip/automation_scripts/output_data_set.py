file_path = ''
output_dict = ''

svoc_output_set = {"LAST_NAME": "", "GEAC_NO": "", "DOB": "", "ZIPCODE": "", "CARD_TYPE":""}

report_data_set = {"API_HH_NUM":"","API_WALLET_ID":"", "API_CARD_STATUS":"", "CONSUMER_WALLET_IDENTITYID": ""}

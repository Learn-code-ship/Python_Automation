from Utilities import configReader

"""ENVIRONTMENT SPECIFICATION"""
ENVIRONMENT = configReader.readConfig('environment_specification', "environment")

""""DEVICE SPECIFICATION"""
PLATFORM = configReader.readConfig('device_specification', "platform_name")

"""IOS SPECIFICATIONS"""
IOS_DEVICE_NAME = configReader.readConfig('ios_device_specifications',"ios_device_name")
IOS_PLATFORM_VERSION = configReader.readConfig('ios_device_specifications', "ios_platfrom")
IOS_DEVICE_UDID = configReader.readConfig('ios_device_specifications', "ios_device_udid")
UNIT_TEST = "XCUITest" # This property is a generic UNIT testing framework for IOS
IOS_APP_PATH = configReader.readConfig('app_specifications', "ios_app_path")

"""ANDROID SPECIFICATIONS"""
ANDROID_DEVICE_NAME = "android"     # This property is constant irrespective of any android device used
ANDROID_APP_PATH = configReader.readConfig('app_specifications', "android_app_path")

"""General Specifications"""
APP_PACKAGE = configReader.readConfig('app_specifications', "app_Package")
APP_ACTIVITY = configReader.readConfig('app_specifications', "app_Activity")
ALL_PERMISSIONS = "true"  # Property to be set true always to avoid permission pop-ups



import time
from pathlib import Path

from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

desired_cap = {}
desired_cap['platformName'] = 'iOS'
desired_cap['platfromVersion'] = '16.0.2'
#desired_cap['App'] = str(Path().absolute().parent)+'/App/Staging/iOS/GetGo-Develop.App'
desired_cap['deviceName'] = 'iPhone 13'
desired_cap['udid'] = '00008110-00016C162163801E'
desired_cap['bundelid'] = 'com.gianteagle.apps.perksapp'
desired_cap['automationName'] = 'XCUITest'


driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',desired_cap)
time.sleep(5)
driver.find_element(By.XPATH, "//*[@resource-id='SignInButton']").click()
#sign_In_Button = driver.find_element(By.XPATH, "//XCUIElementTypeButton[@name='SignInButton']")
#sign_In_Button.click()
time.sleep(5)
email_id = driver.find_element(By.XPATH, "//XCUIElementTypeTextField[@name='Email']")
email_id.send_keys("sharath.kumar@gianteagle.com")
passw = driver.find_element(By.XPATH, "//XCUIElementTypeSecureTextField[@name='Password']")
passw.send_keys("Ashu@1996")
sign_In = driver.find_element(By.XPATH, "//XCUIElementTypeButton[@name='Sign in']")
sign_In.click()
time.sleep(20)
f_name = driver.find_element(By.XPATH, "//XCUIElementTypeStaticText[@name='Hi, Sharath Kumar']")
assert f_name.is_displayed(), "Username not displayed"

orders_tab = driver.find_element(By.XPATH, "//XCUIElementTypeOther[@name='  Orders Orders']")
orders_tab.click()

#location_search = driver.find_element(By.XPATH, "//XCUIElementTypeTextField[@name='Text input field']")
#location_search.click()
#location_search.send_keys("15238")

profile_tab = driver.find_element(By.XPATH, "//XCUIElementTypeOther[@name='  Profile Profile']")
profile_tab.click()

personal_info = driver.find_element(By.XPATH, "//XCUIElementTypeStaticText[@name='Personal Info']")
personal_info.click()

logout = driver.find_element(By.XPATH, "//XCUIElementTypeStaticText[@name='Logout']")
logout.click()

#driver.quit()
import os
from configparser import ConfigParser

# config = ConfigParser()
# config.read("config.cfg")
# print(config.get("locator","username"))
# print(config.get("basic info","testsiteurl"))


def readConfig(section,key):
    config = ConfigParser()
    path = (os.path.abspath(os.path.join(os.getcwd(), os.pardir, 'Configs')))
    path = path + "/config.cfg"
    config.read(path)
    test = config.get(section,key)
    return test

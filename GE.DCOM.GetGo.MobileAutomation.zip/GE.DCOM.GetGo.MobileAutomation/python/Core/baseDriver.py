from appium import webdriver

class BaseDriver(webdriver.webdriver.WebDriver):

    def __init__(self, desired_cap):
        webdriver.webdriver.WebDriver.__init__(self, 'http://127.0.0.1:4723/wd/hub', desired_cap)

    def click_element(self, ID):
        self.find_element(ID).click()

    def clear_txt_box(self, ID):
        self.find_element(ID).clear()

    def send_keys(self, ID, text):
        self.clear_txt_box(ID)
        self.find_element(ID).send_keys(text)



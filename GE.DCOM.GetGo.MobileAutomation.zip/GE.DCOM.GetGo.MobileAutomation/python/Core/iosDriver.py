import time

from appium import webdriver
from selenium.webdriver.common.by import By

from Configs.configs import PLATFORM, IOS_DEVICE_NAME, IOS_PLATFORM_VERSION, IOS_DEVICE_UDID, \
      UNIT_TEST, APP_PACKAGE, ALL_PERMISSIONS, IOS_APP_PATH
from Core.baseDriver import BaseDriver


class IOSDriver(BaseDriver):

    def __init__(self):
        desired_cap = {}
        desired_cap['platformName'] = PLATFORM
        desired_cap['platfromVersion'] = IOS_PLATFORM_VERSION
        # desired_cap['App'] = IOS_APP_PATH
        desired_cap['deviceName'] = IOS_DEVICE_NAME
        desired_cap['udid'] = IOS_DEVICE_UDID
        desired_cap['bundelid'] = APP_PACKAGE
        desired_cap['automationName'] = UNIT_TEST
        desired_cap['autoGrantPermissions'] = ALL_PERMISSIONS
        BaseDriver.__init__(self, desired_cap)

    def find_element(self, ID):
        return super().find_element(By.NAME, ID)

    def find_element_by_xpath(self, xpath):
        return super().find_element(By.XPATH, xpath)
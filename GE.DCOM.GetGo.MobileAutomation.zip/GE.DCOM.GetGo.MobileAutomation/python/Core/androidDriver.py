import time
from appium import webdriver
from selenium.webdriver.common.by import By
from Configs.configs import PLATFORM, ANDROID_DEVICE_NAME, APP_PACKAGE, APP_ACTIVITY, ALL_PERMISSIONS, ANDROID_APP_PATH
from Core.baseDriver import BaseDriver


class AndroidDriver(BaseDriver):

    def __init__(self):
        desired_cap = {}
        desired_cap['platformName'] = PLATFORM
        desired_cap['deviceName'] = ANDROID_DEVICE_NAME
        #desired_cap['App'] = ANDROID_APP_PATH
        desired_cap['appPackage'] = APP_PACKAGE
        desired_cap['appActivity'] = APP_ACTIVITY
        desired_cap['autoGrantPermissions'] = ALL_PERMISSIONS
        BaseDriver.__init__(self, desired_cap)

    def find_element(self, ID):
        return super().find_element(By.XPATH, f"//*[@resource-id='{ID}']")

    def find_element_by_xpath(self, xpath):
        return super().find_element(By.XPATH, xpath)



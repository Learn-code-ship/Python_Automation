import time

from Screens.basescreen import BaseScreen



class OrderScreen(BaseScreen):

    def __init__(self):
        BaseScreen.__init__(self)
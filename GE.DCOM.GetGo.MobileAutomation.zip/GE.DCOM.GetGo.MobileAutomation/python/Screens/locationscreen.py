import time

from Screens.basescreen import BaseScreen



class LocationScreen(BaseScreen):

    def __init__(self):
        BaseScreen.__init__(self)
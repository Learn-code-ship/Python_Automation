
from webdriver_manager.core import driver

from Screens.basescreen import BaseScreen
from Utilities.generatingLogs import log, logger


class HomeScreen(BaseScreen):

    def __init__(self, ):
        BaseScreen.__init__(self)

    _signIn = "SignInButton"
    _home_screen = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.View[1]/android.view.ViewGroup"
    _orders_screen = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.View[2]/android.view.ViewGroup"
    _location_screen = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.View[3]/android.view.ViewGroup"
    _gift_cards_screen = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.View[4]/android.view.ViewGroup"
    _profile_screen = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.View[5]/android.view.ViewGroup"

    def welcome_message(self):
        """
        :return:
        """

    def click_on_sign_in_button(self):
        """
        Sing in to the App
        :return: bool
        """
        try:
            self.driver.click_element(self._signIn)
            return True
        except Exception as e:
            logger.error("Not able to click on signin button : {}".format(e))
            return False

    def navigate_to_home_screen(self):
        try:
            self.driver.click_element(self._home_screen)
            return True
        except Exception as e:
            logger.error("Not able to navigate to home screen with exception : {}".format(e))
            return False

    def navigate_to_order_screen(self):
        try:
            self.driver.click_element(self._orders_screen)
            return True
        except Exception as e:
            logger.error("Not able to navigate to order screen with exception : {}".format(e))
            return False
    def navigate_to_location_screen(self):
        try:
            self.driver.click_element(self._location_screen)
            return True
        except Exception as e:
            logger.error("Not able to navigate to location screen with exception : {}".format(e))
            return False
    def navigate_to_gift_cards_screen(self):
        try:
            self.driver.click_element(self._gift_cards_screen)
            return True
        except Exception as e:
            logger.error("Not able to navigate to gift card screen with exception : {}".format(e))
            return False
    def navigate_to_profile_screen(self):
        try :
            self.driver.click_element(self._profile_screen)
        except Exception as e:
            logger.error("Not able to navigate to profile screen with exception : {}".format(e))




from Screens.basescreen import BaseScreen
from Utilities.generatingLogs import log, logger


class ProfileScreen(BaseScreen):

    def __init__(self):
        BaseScreen.__init__(self)

    _close_btn = "edit-profile-back-button"
    _personal_info = "personal-info-card"
    _wallet = "wallet-card"
    _orders = "orders-card"
    _settings = "settings-card"
    _help = "help-card"
    _legalandprivacy = "legal-privacy-card"
    _first_name = "edit-profile-firstName-input"
    _last_name = "edit-profile-lastName-input"
    _birthday = "edit-profile-Birthday-input"
    _phone_num = "edit-profile-PhoneInput"
    _save_changes_btn = "edit-profile-submit-button"
    _delete_account_btn = "edit-profile-delete-account-button"
    _change_password = "edit-profile-change-password-button"
    _logout = "edit-profile-logout-button"

    def logout(self):
        try:
            self.driver.click_element(self._personal_info)
            self.driver.click_element(self._logout)
        except Exception as e :
            logger.error("not able to logout with exception : {}".format(e))

    def edit_fname(self, fname_to_edit):
        try:
            self.driver.click_element(self._personal_info)
            self.driver.send_keys(self._first_name, fname_to_edit)
        except Exception as e :
            logger.error("first name not editted with exception : {}".format(e))

    def edit_lname(self, lname_to_edit):
        try:
            self.driver.click_element(self._personal_info)
            self.driver.send_keys(self._last_name, lname_to_edit)
        except Exception as e :
            logger.error("first name not editted with exception : {}".format(e))

    def edit_fname(self, phnumber):
        try:
            self.driver.click_element(self._personal_info)
            self.driver.send_keys(self._phone_num, phnumber)
        except Exception as e :
            logger.error("first name not editted with exception : {}".format(e))


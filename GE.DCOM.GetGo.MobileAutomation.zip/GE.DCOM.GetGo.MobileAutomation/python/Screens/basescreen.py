from _pytest.fixtures import fixture

from Core.androidDriver import AndroidDriver
from Core.iosDriver import IOSDriver
from Configs.configs import PLATFORM

class BaseScreen:

    driver = None
    def __init__(self):
        if (BaseScreen.driver is None):
            if(PLATFORM == "ios"):
                #IOSDriver.__init__(self)
                BaseScreen.driver = IOSDriver()
            elif(PLATFORM == "android"):
                #AndroidDriver.__init__(self)
                BaseScreen.driver = AndroidDriver()







import time

from Screens.basescreen import BaseScreen
from Utilities.generatingLogs import logger


class AzureScreen(BaseScreen):

    def __init__(self):
        BaseScreen.__init__(self)

    _email_txt_fld = "signInName"
    _pass_txt_fld = "password"
    _sign_in_button = "next"
    _phone_number = ""

    def sign_in(self, username, password):
        try:
            time.sleep(5)
            self.driver.send_keys(self._email_txt_fld, username)
            self.driver.send_keys(self._pass_txt_fld, password)
            self.driver.click_element(self._sign_in_button)
            time.sleep(20)
        except Exception as e:
            logger.error("not able to sign in to the application with exception : {}".format(e))


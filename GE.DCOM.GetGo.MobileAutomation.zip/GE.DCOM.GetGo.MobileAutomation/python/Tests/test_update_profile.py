import pytest
from webdriver_manager.core import driver

from Screens.azureb2cscreen import AzureScreen
from Screens.homescreen import HomeScreen
from Screens.profilescreen import ProfileScreen


def test_Update_Profile():
    home_screen = HomeScreen()
    azure_screen = AzureScreen()
    profile_screen = ProfileScreen()

    assert home_screen.click_on_sign_in_button()
    assert azure_screen.sign_in("sharath.kumar@gianteagle.com", "Ashu@1996")
    assert home_screen.navigate_to_profile_screen()
    assert profile_screen.edit_fname()
    assert home_screen.navigate_to_home_screen()
    assert profile_screen.logout()


package GE.DCOM.GetGo.Mobile.Automation.Tests;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.remote.DesiredCapabilities;

import GE.DCOM.GetGo.Mobile.Automation.Controllers.ConfigManager;
import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.DataContainer;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class BaseTest {
	
	public static AndroidDriver driver;
	public static HomePage homePage;
	protected static DataContainer dataSet;
	
	static ConfigManager configManager = new ConfigManager();
		
	public BaseTest() {
		dataSet = ConfigManager.JsonReader();
		}

	@BeforeClass
	public static void DesiredCapabilities() throws MalformedURLException {	
		Properties property = ConfigManager.ConfigReader();
		DesiredCapabilities capabilites = new DesiredCapabilities();
		capabilites.setCapability(MobileCapabilityType.PLATFORM_VERSION, property.getProperty("Platform"));
		capabilites.setCapability(MobileCapabilityType.PLATFORM_VERSION, property.getProperty("Platform_Version"));
		//capabilites.setCapability(MobileCapabilityType.DEVICE_NAME, property.getProperty("Device_Name"));
		capabilites.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
		//capabilites.setCapability(AndroidMobileCapabilityType.AVD_LAUNCH_TIMEOUT, 500000);
		//capabilites.setCapability("commandTimeouts", "12000");
		capabilites.setCapability("appPackage", "com.hatchedlabs.apps.getgo.staging");
		capabilites.setCapability("appActivity", property.getProperty("App_Activity"));
		capabilites.setCapability("autoGrantPermissions", true);

	//	capabilites.setCapability(MobileCapabilityType.APP,
	//			"/Users/Sharath.Kumar/Documents/Repos/GE.DCOM.GetGo/Testing/GE.DCOM.GetGo.Automation/Android/Getgo_staging.apk");
		

		driver = new AndroidDriver(new URL("http://localhost:4723/wd/hub"), capabilites);

		homePage = new HomePage(driver);
	}
	
	@AfterClass
	public static void tearDown()
	{
		driver.quit();
		}
}

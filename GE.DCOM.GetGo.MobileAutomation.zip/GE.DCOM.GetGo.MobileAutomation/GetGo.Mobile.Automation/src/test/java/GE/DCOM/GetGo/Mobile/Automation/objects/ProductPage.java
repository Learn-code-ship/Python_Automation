package GE.DCOM.GetGo.Mobile.Automation.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ProductPage extends AndroidActions{
	AndroidDriver driver;

	public ProductPage(AndroidDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@resource-id='pdp-child-Extra Cheese-check']")
	private WebElement addOnSelect;
	
	@AndroidFindBy(xpath = "//*[@resource-id='pdp-add-to-order']")
	private WebElement addToOrderBtn;
	
	public void selectAddOn()
	{
		addOnSelect.click();
		System.out.println("Add on select button is clicked ");
	}
	
	public String getItemPrice()
	{		
		String orderText = driver.findElement(By.xpath("//*[@resource-id='pdp-add-to-order']//*[contains(@text, 'Add to Order')]")).getText();
		return orderText.replace(" ⸱ Add to Order", "");
	}
	
	public void clickAddToOrder()
	{
		addToOrderBtn.click();
		System.out.println("Add to order button is clicked ");
	}
}

package GE.DCOM.GetGo.Mobile.Automation.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class OrderConfirmationPage extends AndroidActions {
	AndroidDriver driver;

	public OrderConfirmationPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-pickup-time']")
	private WebElement orderPickupTime;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-id']")
	private WebElement orderId;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-status']")
	private WebElement orderStatus;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-create-day']")
	private WebElement orderCreateDay;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-create-time']")
	private WebElement orderCreateTime;
	
	@AndroidFindBy(xpath = "//*[@resource-id='map-it']")
	private WebElement mapIt;
	
	@AndroidFindBy(xpath = "//*[@resource-id='button-text']")
	private WebElement mapText;
	
	@AndroidFindBy(xpath = "//*[@resource-id='call-us-help-number']")
	private WebElement callUs;
	
	@AndroidFindBy(xpath = "//*[@text='   Pick it Up']")
	private WebElement pickItUp;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-detail']")
	private WebElement orderDetailSection;
	
	@AndroidFindBy(xpath = "//*[@resource-id='-name-text']")
	private WebElement orderedItem;
	
	@AndroidFindBy(xpath = "//*[@resource-id='-price-text']")
	private WebElement itemPrice;
	
	@AndroidFindBy(xpath = "//*[@resource-id='per-item-label']")
	private WebElement itemQty;
	
	@AndroidFindBy(xpath = "//*[@resource-id='sub-total-price-text']")
	private WebElement subTotalPrice;
	
	@AndroidFindBy(xpath = "//*[@resource-id='tax-price-text']")
	private WebElement taxPrice;
	
	@AndroidFindBy(xpath = "//*[@resource-id='total-price-text']")
	private WebElement totalPrice;
	
	@AndroidFindBy(xpath = "//*[@text='Cancel Order']")
	private WebElement cancelOrderBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='primary-action']")
	private WebElement keepMyOrderBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='tertiary-action']")
	private WebElement orderCancelBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='back-button']")
	private WebElement orderBackBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='close-confirmation-page']")
	private WebElement closeConfirmationBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-id-text']")
	private WebElement OrderConfirmationPageorderId;
	
	@AndroidFindBy(xpath = "//*[@resource-id='total-price-text']")
	private WebElement OrderConfirmationPageTotalPrice;
	
	@AndroidFindBy(xpath = "//*[@bounds='[196,1543][343,1599]']")
	private WebElement OrderConfirmationPageTotalItems;
	
	@AndroidFindBy(xpath = "//*[@bounds='[196,1145][1356,1215]']")
	private WebElement OrderConfirmationPageStoreName;
	
	@AndroidFindBy(xpath = "//*[@bounds=[196,645][1356,715]']")
	private WebElement OrderConfirmationPagePickUpTime;
	
	public String getPickupDay()
	{		
		System.out.println("The Order created date is: "+orderCreateDay.getText());
		return orderCreateDay.getText();
	}
	
	public String getPickupTime()
	{		
		String Order_Pick_Up_Time=orderPickupTime.getText().replace(".", "");
		System.out.println("The order pick up time is: "+Order_Pick_Up_Time);
		return Order_Pick_Up_Time;
	}
	
	public String getOrderId()
	{	
		String Order_Id=orderId.getText().replace("Order ID: ", "");
		System.out.println("The Order Id is: "+Order_Id);
		return Order_Id;
	}
	
	public String getOrderStatus()
	{		
		String Order_status=orderStatus.getText();
		System.out.println("The Order Id is: "+Order_status);
		return Order_status;
	}
	
	public boolean verifyMap()
	{
		try {
            return mapIt.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}
	
	public boolean verifyCallUsSection()
	{
		try {
            return callUs.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}
	
	public boolean verifyPickItSection()
	{
		try {
            return pickItUp.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}
	
	public boolean verifyOrderDetailSection()
	{
		try {
            return orderDetailSection.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}
	
	public String getOrderedItem()
	{		
		String Ordered_Item=orderedItem.getText();
		System.out.println("The Order Item is: "+Ordered_Item);
		return Ordered_Item;
	}
	
	public String getItemPrice()
	{	
		String Item_Price=itemPrice.getText();
		System.out.println("The Item price is: "+Item_Price);
		return Item_Price;
	}
	
	public String getItemQty()
	{		
		String Item_Quantity=itemQty.getText().replace("Qty: ", "");
		System.out.println("The Item quantity is: "+Item_Quantity);
		return Item_Quantity;
	}
	
	public String getsubTotal()
	{	
		String Sub_Total_Price=subTotalPrice.getText();
		System.out.println("The Total price is: "+Sub_Total_Price);
		return Sub_Total_Price;
	}
	
	public String getTaxPrice()
	{	
		scrollToText("Tax");
		String Tax_Price=taxPrice.getText();
		System.out.println("The Tax price is: "+Tax_Price);
		return Tax_Price;
	}
	
	public String getTotalPrice()
	{	
		scrollToText("Total");
		String Total_Price=totalPrice.getText();
		System.out.println("The Total price is: "+Total_Price);
		return Total_Price;
	}
	
	public void cancelOrder()
	{		
		cancelOrderBtn.click();
		System.out.println("Cancel Order button is clicked ");
		keepMyOrderBtn.isDisplayed();
		orderCancelBtn.click();
		System.out.println("Order Cancel button is clicked ");
	}
	
	public void clockorderBackBtn() throws InterruptedException
	{
		Thread.sleep(3000);
		orderBackBtn.click();
		System.out.println("Order back button is clicked ");
	}
	public void OrderDetailsUnderViewDetailsTab() throws InterruptedException{
		System.out.println("Order Details under ViewDetails tab are: ");
		getOrderId();
		getTotalPrice();
		getTaxPrice();
		getsubTotal();
		
	}
	
	public void clickcloseConfirmationBtn() throws InterruptedException {
		closeConfirmationBtn.click();
		System.out.println("Confirmation page is closed");
		Thread.sleep(5000);
				
	}
	
	public String getOrderConfirmationPageorderId()
	{	
		String Order_Id=OrderConfirmationPageorderId.getText().replace("Order ID: ", "");
		System.out.println("The Order Id in Confirmation page is: "+Order_Id);
		return Order_Id;
	}
	
	public String getOrderConfirmationPageTotalPrice()
	{	
		String total_Price=OrderConfirmationPageTotalPrice.getText();
		System.out.println("The Total price in Confirmation page is: "+total_Price);
		return total_Price;
	}
	
	public String getOrderConfirmationPageTotalItems()
	{	
		String total_Items=OrderConfirmationPageTotalItems.getText();
		System.out.println("The total items in Confirmation page is: "+total_Items);
		return total_Items;
	}
	
	public String getOrderConfirmationPageStoreName()
	{	
		String store_name=OrderConfirmationPageStoreName.getText();
		System.out.println("The store on in Confirmation page is: "+store_name);
		return store_name;
	}
	
	
	public void verifyOrderConfirmationPageValidation(){
		System.out.println("Order Confirmation page validations are: \n");
		getOrderConfirmationPageorderId();	
		//getOrderConfirmationPageTotalItems();
		//getOrderConfirmationPageTotalPrice();
		//getOrderConfirmationPageStoreName();
		
	}

}

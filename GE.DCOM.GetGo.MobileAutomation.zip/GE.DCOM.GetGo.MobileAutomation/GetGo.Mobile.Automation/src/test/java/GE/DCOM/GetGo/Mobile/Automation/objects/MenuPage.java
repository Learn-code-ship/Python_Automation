package GE.DCOM.GetGo.Mobile.Automation.objects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class MenuPage extends AndroidActions{
	AndroidDriver driver;

	public MenuPage(AndroidDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@text='Pizza']")
	private WebElement menuItem;
	
	@AndroidFindBy(xpath = "//*[@text='Beer']")
	private WebElement menuItemForAlcohol;
	
	@AndroidFindBy(xpath = "//*[@text='Corona Extra 6pk Nr']")
	private WebElement subMenuItemForAlcohol;
	
	@AndroidFindBy(xpath = "//*[@text='Cheese']")
	private WebElement subMenuItem;
	
	@AndroidFindBy(xpath = "//*[@resource-id='pdp-child-Extra Cheese-check']")
	private WebElement addOnSelect;
	
	@AndroidFindBy(xpath = "//*[@resource-id='pdp-add-to-order']")
	private WebElement addToOrderBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='cart-button']")
	//@AndroidFindBy(xpath = "//*[@bounds='[1167,2613][1237,2683]']")
	private WebElement cartBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='cart-item-remove-button']")
	private WebElement removeCartBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='empty-cart-banner']")
	private WebElement emptyCartBanner;
	
	@AndroidFindBy(xpath = "//*[@resource-id='back-button']")
	private WebElement backBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='product-price-text']")
	private WebElement menuPagePizzaSubItemTileText;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'go-to-order-back-button']")
	private WebElement menuPagePizzaSubItemBackBtn;
	
	@AndroidFindBy(xpath = "//*[@text = 'Breakfast']")
	private WebElement menuPageBreakfast;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'product-tile-button']")
	private WebElement menuPageBreakfastSubItem;
	
	@AndroidFindBy(xpath = "//*[@text = 'Appetizers + Snacks']")
	private WebElement menuPageAppetizers;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'product-tile-button']")
	private WebElement itemPageOne;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'product-price-text']")
	private WebElement itemPageOneText;
	
	@AndroidFindBy(xpath = "//*[@bounds = '[738,330][1339,1045]']")
	private WebElement itemPageTwo;
	
	@AndroidFindBy(xpath = "//*[@bounds = '[778,825][1298,935]']")
	private WebElement itemPageTwoText;
	
	@AndroidFindBy(xpath = "//*[@text = 'Cart Summary']")
	private WebElement cartPageHeader;
	
	
	
	public void selectMenuItem() throws InterruptedException
	{
		Thread.sleep(3000);
	    try {
	        if (cartBtn.isDisplayed()) {
	            cartBtn.click();
	            System.out.println("Cart button is clicked");
	            Thread.sleep(3000);
	            removeCartBtn.click();
	            System.out.println("Remove Cart button is clicked");
	            Thread.sleep(5000);
	            backBtn.click();
	            System.out.println("Back button is clicked");
	        }
	    } catch (Exception e) {
	       System.out.println("Cart is empty");
	    }

	    try {
	        menuItem.click();
	        System.out.println("Menu item button is clicked");
	        subMenuItem.click();
	        System.out.println("Sub Menu item button is clicked");
	    } catch (Exception e) {
	       e.getStackTrace();
	    }
	}
	
	public void selectAlcoholItem() throws InterruptedException
	{
		Thread.sleep(3000);
	    try {
	        if (cartBtn.isDisplayed()) {
	            cartBtn.click();
	            System.out.println("Cart button is clicked");
	            Thread.sleep(3000);
	            removeCartBtn.click();
	            System.out.println("Remove Cartbutton is clicked");
	            Thread.sleep(5000);
	            backBtn.click();
	            System.out.println("Back button is clicked");
	        }
	    } catch (Exception e) {
	       System.out.println("Cart is empty");
	    }

	    try {
	    	scrollToText("Beer");
			menuItemForAlcohol.click();
			System.out.println("Menu item button is clicked");
			subMenuItemForAlcohol.click();
			System.out.println("Sub menu button is clicked");
	    } catch (Exception e) {
	    	e.getStackTrace();
	    }
	}
	
	public void clickCartIcon() throws InterruptedException
	{
		cartBtn.click();
		System.out.println("Cart button is clicked ");
		Thread.sleep(10000);
		if(	cartPageHeader.isDisplayed()==false) {
			cartBtn.click();
			System.out.println("Cart button is clicked 2nd time");
		}
		verifyCartSummaryPage();
	}
	
	public void itemSelectionPageOne() throws InterruptedException
	{
		System.out.println("Inside Item selection");
		Thread.sleep(3000);
			itemPageOne.click();
			////System.out.println("Sub Item selected on page one is: "+itemPageOneText.getText());
			itemPageTwo.click();
			Thread.sleep(6000);
			Thread.sleep(3000);
	}
	public void clickmenuPageAppetizersItemSelection() throws InterruptedException
	{
		Thread.sleep(15000);
		menuPageAppetizers.click();
		System.out.println("Menu page 'Appetizers and Snacks' is clicked ");
		itemSelectionPageOne();
	}
	
	public void verifyCartSummaryPage()  throws InterruptedException
	{
		Thread.sleep(6000);
		if(	cartPageHeader.isDisplayed()) {
			System.out.println("Cart Summary page displayed");
	}
	}
}

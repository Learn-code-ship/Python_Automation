package GE.DCOM.GetGo.Mobile.Automation.Tests;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.Creditcard;
import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.CartPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.LocationPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderConfirmationPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderHistoryPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrdersPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.PaymentPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProductPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;

public class CartPageTests extends BaseTest{
	
	HomePage homePage = new HomePage(driver);
	ProfilePage profilePage = new ProfilePage(driver);
	User user = dataSet.getUser().get(0);
	LocationPage locationPage = new LocationPage(driver);
	StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
	OrdersPage ordersPage = new OrdersPage(driver);
	OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);
	OrderConfirmationPage orderConfirmationPage = new OrderConfirmationPage(driver);
	MenuPage menuPage = new MenuPage(driver);
	CartPage cartPage = new CartPage(driver);
	PaymentPage paymentPage = new PaymentPage(driver);
	ProductPage productpage = new ProductPage(driver);
	Creditcard card = dataSet.getCreditcard().get(0);

	
  public void CartPageChangePickupScheduleTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		cartPage.clickscheduleForLaterBtn();
		String new_pickUpTimeSelected = storeSelectionPage.changescheduleLaterPickupTime();
		System.out.println("Changed Pick up time: "+new_pickUpTimeSelected);
		Assert.assertNotSame(pickupTimeSelected, new_pickUpTimeSelected);
		cartPage.clickcartBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
    
	public void OrderHistoryTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();	
		cartPage.clickProceedToPayment();
		Thread.sleep(30000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		String orderId_OrderConfirmationPage = orderConfirmationPage.getOrderConfirmationPageorderId();
		System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderConfirmationPage);
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.clickProfileTab();
		profilePage.clickOrdersBtn();
		orderHistoryPage.verifyOrderHistoryPage();
		String orderId_OrderHistoryPage = orderHistoryPage.getOrderId();
		System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderHistoryPage);
		Assert.assertEquals(orderId_OrderConfirmationPage, orderId_OrderHistoryPage);
		orderHistoryPage.clickorderHistotyPageBackBtn();
		profilePage.clickPersonalInfoBtn();
		profilePage.clickLogoutBtn();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
	
	
	public void OrderConfirmationPageTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		cartPage.CartClearing();
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		Thread.sleep(5000);
		String cartItemPrice = cartPage.getItemPrice();
		System.out.println("cartItemPrice: "+cartItemPrice);
		Thread.sleep(5000);
		String cartItemQty = cartPage.getItemQuantity();
		System.out.println("cartItemQty: "+cartItemQty);
		cartPage.clickProceedToPayment();
		Thread.sleep(30000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		orderConfirmationPage.verifyOrderConfirmationPageValidation();
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
	

	public void AddMoreItemsTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		cartPage.CartClearing();
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		Thread.sleep(5000);
		cartPage.clickaddMoreItems();
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		cartPage.clickProceedToPayment();
		Thread.sleep(30000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		orderConfirmationPage.verifyOrderConfirmationPageValidation();
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
	
	public void OrderDetailsTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();	
		cartPage.clickProceedToPayment();
		Thread.sleep(30000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		String orderId_OrderConfirmationPage = orderConfirmationPage.getOrderConfirmationPageorderId();
		System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderConfirmationPage);
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.clickProfileTab();
		profilePage.clickOrdersBtn();
		orderHistoryPage.verifyOrderHistoryPage();
		String orderId_OrderHistoryPage = orderHistoryPage.getOrderId();
		System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderHistoryPage);
		Assert.assertEquals(orderId_OrderConfirmationPage, orderId_OrderHistoryPage);
		orderHistoryPage.clickorderHistoryViewDetails();
		orderHistoryPage.verifyOrderDetailsPageValidation();
		
		String orderId_OrderDetailsPage = orderHistoryPage.getOrderDetailsPageorderId();
		System.out.println("Order Id on Order Details Page: "+orderId_OrderDetailsPage);
		Assert.assertEquals(orderId_OrderConfirmationPage, orderId_OrderDetailsPage);
		
		orderHistoryPage.clickorderHistotyPageBackBtn();
		orderHistoryPage.clickorderHistotyPageBackBtn();
		profilePage.clickPersonalInfoBtn();
		profilePage.clickLogoutBtn();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
  	
  	
	public void EditItemTest() throws InterruptedException
	{
  		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		Thread.sleep(15000);
		cartPage.CartClearing();
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		Thread.sleep(5000);
		cartPage.clickEditItems();
		Thread.sleep(5000);
		cartPage.clickIncreaseItems();
		cartPage.clickaddToOrderBtn();
		cartPage.clickProceedToPayment();
		Thread.sleep(30000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		orderConfirmationPage.verifyOrderConfirmationPageValidation();
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
	@Test
	public void UndoItemTest() throws InterruptedException
	{
  		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		Thread.sleep(15000);
		cartPage.CartClearing();
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		Thread.sleep(5000);
		cartPage.clickcartRemoveBtn();
		Thread.sleep(3000);
		cartPage.clickUndoItems();
		cartPage.clickProceedToPayment();
		Thread.sleep(45000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		orderConfirmationPage.verifyOrderConfirmationPageValidation();
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
 	
 
	public void MayWeSuggestItemTest() throws InterruptedException
	{
  		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		Thread.sleep(15000);
		cartPage.CartClearing();
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		Thread.sleep(5000);
		cartPage.clickmayWeSuggest();
		cartPage.clickProceedToPayment();
		Thread.sleep(45000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		orderConfirmationPage.verifyOrderConfirmationPageValidation();
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
	
	public void CreditCardTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println("Pick up time seslected: "+pickupTimeSelected);
		cartPage.CartClearing();
		menuPage.clickmenuPageAppetizersItemSelection();
		cartPage.clickaddToOrderBtn();
		menuPage.clickCartIcon();
		Thread.sleep(5000);
		cartPage.clickProceedToPayment();
		Thread.sleep(45000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(30000);
		orderConfirmationPage.verifyOrderConfirmationPageValidation();
		orderConfirmationPage.clickcloseConfirmationBtn(); 
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
 }

package GE.DCOM.GetGo.Mobile.Automation.objects;

import org.openqa.selenium.WebElement;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import org.openqa.selenium.support.PageFactory;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class CartPage extends AndroidActions {
	AndroidDriver driver;

	public CartPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		MenuPage menuPage = new MenuPage(driver);
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(xpath = "//*[@resource-id='base-menu-selected-store-header']")
	private WebElement selectedstore;

	@AndroidFindBy(xpath = "//*[@resource-id='asap-button']")
	private WebElement pickUpAsap;

	@AndroidFindBy(xpath = "//*[@resource-id='schedule-button']")
	private WebElement pickUpLater;

	@AndroidFindBy(xpath = "//*[@resource-id='item-price']")
	private WebElement itemPrice;

	@AndroidFindBy(xpath = "//*[@resource-id='product-quantity-text']")
	private WebElement itemQty;

	@AndroidFindBy(xpath = "//*[@resource-id='tax-price-text']")
	private WebElement taxPrice;

	@AndroidFindBy(xpath = "//*[@resource-id='total-price-text']")
	private WebElement totalPrice;

	@AndroidFindBy(xpath = "//*[@text='Proceed to Payment']")
	private WebElement proceedToPayment;

	@AndroidFindBy(xpath = "//*[@resource-id='alcohol-check-birthday-input']")
	private WebElement verifyAgeField;

	@AndroidFindBy(xpath = "//*[@resource-id='age-modal-continue-button']")
	private WebElement continueBtn;

	@AndroidFindBy(xpath = "//*[@resource-id='close-alcohol-bottomsheet']")
	private WebElement closeModalBtn;

	@AndroidFindBy(xpath = "//*[@resource-id='back-button']")
	private WebElement cartBackBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='base-menu-store-name']")
	private WebElement storeNameUnderCartTab;
	
	//@AndroidFindBy(xpath = "//*[@bounds='[828,2855][1272,2892]']")
	@AndroidFindBy(xpath = "//*[@resource-id='pdp-add-to-order']")
	private WebElement addToOrderBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='schedule-button']")
	private WebElement scheduleForLaterBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='total-price-text']")
	private WebElement TotalPrice;
	
	@AndroidFindBy(xpath = "//*[@resource-id='cart-item-remove-button']")
	private WebElement cartRemoveBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='cart-button']")
	private WebElement cartBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='empty-cart-banner']")
	private WebElement emptyCartBanner;
	
	@AndroidFindBy(xpath = "//*[@text = 'Cart Summary']")
	private WebElement cartPageHeader;
	
	@AndroidFindBy(xpath = "//*[@text = 'Add more items']")
	private WebElement addMoreItems;
	
	@AndroidFindBy(xpath = "//*[@resource-id='PayPal']")
	private WebElement payPal;
	
	@AndroidFindBy(xpath = "//*[@content-desc='PayPal']")
	private WebElement payPalBtn;
	
	@AndroidFindBy(xpath = "//*[@content-desc='paypal paylater']")
	private WebElement payLaterBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'email']")
	private WebElement emailTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='btnNext']")
	private WebElement btnNext;
	
	@AndroidFindBy(xpath = "//*[@text = 'Password']")
	private WebElement passWord;
	
	@AndroidFindBy(xpath = "//*[@resource-id='btnLogin']")
	private WebElement btnLogin;
	
	@AndroidFindBy(xpath = "//*[@resource-id='payment-submit-btn']")
	private WebElement paymentSubmitBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='sendPayment']")
	private WebElement sendPaymentBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='cart-item-edit-button']")
	private WebElement EditItemsBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='pdp_positive_button']")
	private WebElement itemIncBtn;
	
	@AndroidFindBy(xpath = "//*[@text = 'UNDO']")
	private WebElement undoItem;
	
	@AndroidFindBy(xpath = "//*[@text = 'May we suggest']")
	private WebElement mayWeSuggest;
	
	@AndroidFindBy(xpath = "//*[@resource-id='product-add-button-']")
	private WebElement productAddBtn;
	
	
	
	public boolean verifyStore() {
		try {
            return selectedstore.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}

	public boolean verifyPickupAsap() {
		try {
            return pickUpAsap.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}

	public boolean verifyPickupLater() {
		try {
            return pickUpLater.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}

	public String getItemPrice() {
		System.out.println("Item Price is: "+itemPrice.getText());
		return itemPrice.getText();
	}

	public String getItemQuantity() {
		System.out.println("Item quantity is: "+itemQty.getText());
		return itemQty.getText();
	}

	public String getTotalPrice() {
		scrollToText("Total");
		System.out.println("Total price is: "+totalPrice.getText());
		return totalPrice.getText();
	}

	public String getTaxPrice() {
		System.out.println("Tax price is: "+taxPrice.getText());
		return taxPrice.getText();
	}

	public void clickProceedToPayment() throws InterruptedException {
		Thread.sleep(15000);
		if(proceedToPayment.isEnabled()==false) {
			System.out.println("'Proceed to payment' button is disabled");
			
		}
		else {
			System.out.println("'Proceed to payment' button is enabled");
			if(proceedToPayment.isDisplayed()) {
				proceedToPayment.click();
			}
			else {
				scrollToText("Proceed to Payment");
				proceedToPayment.click();
			}
		}
		System.out.println("'Proceed to payment' button is clicked");
	}

	public void closeAgeModal() throws InterruptedException {
		Thread.sleep(3000);
		closeModalBtn.click();
		System.out.println("'Close modal' button is clicked");
	}

	public void verifyAge() {
		verifyAgeField.click();
		System.out.println("'Verify age field' is clicked");
		verifyAgeField.sendKeys("10/10/1990");
		continueBtn.click();
		System.out.println("'Continue' button is clicked");
	}
	
	public void clickcartBackBtn() throws InterruptedException {
		Thread.sleep(5000);
		cartBackBtn.click();
		System.out.println("'Cart back' button is clicked");
	}
	
	public String getstoreNameUnderCartTab() throws InterruptedException
	{
	Thread.sleep(4000);
	System.out.println("Store name under Cart tab is: "+storeNameUnderCartTab.getText());
	return storeNameUnderCartTab.getText();
	}
	
	public void clickaddToOrderBtn() throws InterruptedException {
		Thread.sleep(3000);
		addToOrderBtn.click();
		System.out.println("'Add to Order' button is clicked");
		Thread.sleep(15000);
	}
	
	public void clickscheduleForLaterBtn() throws InterruptedException {
		Thread.sleep(5000);
		scheduleForLaterBtn.click();
		System.out.println("'Schedule for later' button is clicked");
	}
	
	public String verifyscheduleForLaterText() throws InterruptedException {
		Thread.sleep(5000);
		String scheduled_time=scheduleForLaterBtn.getText();
		return scheduled_time;
		
	}
	
	public void clickcartRemoveBtn() throws InterruptedException {
		Thread.sleep(5000);
		cartRemoveBtn.click();
		System.out.println("'Remove' button is clicked");
	}
	
	public void CartClearing() throws InterruptedException {
		try {
			if(cartBtn.isDisplayed())
            {
				System.out.println("The cart button is displayed");
				cartBtn.click();
				Thread.sleep(6000);
				System.out.println("Clearing cart initialised ");
				while (cartRemoveBtn.isDisplayed()==true) {
					  System.out.println("Remove button exists");
					  clickcartRemoveBtn();
					  Thread.sleep(4000);
					}
            }
		} 
		catch (Exception e) {
			
		}
		finally {
			try {
				if(cartPageHeader.isDisplayed())
	            {
					clickcartBackBtn();
	            	Thread.sleep(6000);
	            	System.out.println("Finally Cart clicked");
	            }	
	    
			} catch (Exception e) {
			}
		}
		  Thread.sleep(4000);

}
	public void clickaddMoreItems() throws InterruptedException {
		addMoreItems.click();
		System.out.println("'Add more items' button is clicked");
		Thread.sleep(5000);
	}
	
	public void clickpayPal() throws InterruptedException {
		payPal.click();
		System.out.println("'PayPal'tab is clicked");
		Thread.sleep(5000);
	}
	
	public void clickpayPalBtn() throws InterruptedException {
		payPalBtn.click();
		System.out.println("'PayPal' button is clicked");
		Thread.sleep(5000);
	}
	
	public void EnterpayPalDetails() throws InterruptedException {
		emailTab.click();
		emailTab.sendKeys("Ann_stewart-dehart@yopmail.com");
		System.out.println("Email is entered");
		btnNext.click();
		Thread.sleep(5000);
		passWord.click();
		passWord.sendKeys("Password1");
		btnLogin.click();
		Thread.sleep(9000);
	}
	
	public void clickpayPalSubmitBtn() throws InterruptedException {
		paymentSubmitBtn.click();
		System.out.println("'PayPal submit ' button is clicked");
		Thread.sleep(5000);
	}
	
	public void clickConfirmPaymentBtn() throws InterruptedException {
		sendPaymentBtn.click();
		System.out.println("'Confirm and Place Order' button is clicked");
		Thread.sleep(5000);
	}
	
	public void clickEditItems() throws InterruptedException {
		EditItemsBtn.click();
		System.out.println("'Edit items' button is clicked");
		Thread.sleep(5000);
	}
	
	public void clickIncreaseItems() throws InterruptedException {
		Thread.sleep(5000);
		itemIncBtn.click();
		itemIncBtn.click();
		System.out.println("'Increase items' button is clicked");
		Thread.sleep(6000);
	}
	
	public void clickUndoItems() throws InterruptedException {
		undoItem.click();
		System.out.println("'Undo items' button is clicked");
		Thread.sleep(5000);
	}
	
	public void clickmayWeSuggest() throws InterruptedException {
		if(mayWeSuggest.isDisplayed()) {
			System.out.println("'May we suggest' tab is displayed");
		}
		productAddBtn.click();
		System.out.println("'May we suggest' product is added to Cart");
		Thread.sleep(5000);
	}
	
	
	
}	

	
	

	

	
	

package GE.DCOM.GetGo.Mobile.Automation.Tests;

import org.junit.Assert;
import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.Creditcard;
import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.CartPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.LocationPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderConfirmationPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrdersPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.PaymentPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProductPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderHistoryPage;

public class OrderTests extends BaseTest{
	
	HomePage homePage = new HomePage(driver);
	ProfilePage profilePage = new ProfilePage(driver);
	StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
	OrdersPage ordersPage = new OrdersPage(driver);
	OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);
	MenuPage menuPage = new MenuPage(driver);
	CartPage cartPage = new CartPage(driver);
	PaymentPage paymentPage = new PaymentPage(driver);
	Creditcard card = dataSet.getCreditcard().get(0);
	User user = dataSet.getUser().get(0);
	ProductPage productpage = new ProductPage(driver);
	OrderConfirmationPage orderConfirmationPage = new OrderConfirmationPage(driver);
	
	
	public void StoreFavouritesTest() throws InterruptedException
	{	
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		ordersPage.CheckAndUncheckFavoriteStores();
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
	
	public void OrderingStoreSearchTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
	
	public void OrderPageNavigationTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		orderHistoryPage.orderAgainBtn();
		orderHistoryPage.favoritesBtn();
		orderHistoryPage.menuBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}

	public void OrderingStoreSortingTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.clickorderTab();
		storeSelectionPage.searchStore(user.getPincode());
		storeSelectionPage.validateStoreDisplayOrder();
		storeSelectionPage.selectYourStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
}


	public void ViewDetailsTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		orderHistoryPage.orderAgainBtn();
		Thread.sleep(5000);
		orderHistoryPage.verifyViewDetailBtn();
		ordersPage.clickOnmenuTabBtn();
 		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
}
	
		
		public void ChangeStoreTest() throws InterruptedException
		{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStore(user.getPincode());
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		String firstStorename = ordersPage.getstoreNameUnderOrdersTab();
		System.out.println(firstStorename);
		ordersPage.clickOnstoreNameUnderOrdersTabBtn();
		storeSelectionPage.enterStoreDetailsAndValidateIt(user.getNoKerosenepPincode());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected2 = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected2);
		String secondStorename = ordersPage.getstoreNameUnderOrdersTab();
		System.out.println(secondStorename);
		Assert.assertNotEquals(firstStorename,secondStorename);
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		}
		
	
		public void ReOrderTest() throws InterruptedException
		{
		Thread.sleep(10000);
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStore(user.getPincode());
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		ordersPage.clickOnOrderAgainBtn();
		ordersPage.clickOnthefirstReOrderButton();
		cartPage.clickProceedToPayment();
		Thread.sleep(30000);
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		ordersPage.clickOncloseConfirmationPageBtnBtn();
		ordersPage.clickOnmenuTabBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		}
		
	
		public void OrderAgainMessagesTest() throws InterruptedException
		{
		
			Thread.sleep(10000);
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getorderAgainMessageEmail(), user.getPassword());
			homePage.clickHomeTab();
			Assert.assertEquals(true, homePage.loggedInAccount(user.getfirstNameOrderAgain()));
			ordersPage.clickOnOrderNow();
			storeSelectionPage.selectStore(user.getPincode());
			storeSelectionPage.orderHere();
			String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
			System.out.println(pickupTimeSelected);
			ordersPage.clickOnOrderAgainBtn();
			Assert.assertEquals(true, ordersPage.orderagainempty());
			ordersPage.clickOnmenuTabBtn();
	 		profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
		}
		
		
		public void StoreHeaderTest() throws InterruptedException
		{
			Thread.sleep(10000);
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
			ordersPage.clickOnOrderNow();
			storeSelectionPage.selectStore(user.getPincode());
			storeSelectionPage.orderHere();
			String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
			System.out.println(pickupTimeSelected);
			String firstStorename = ordersPage.getstoreNameUnderOrdersTab();
			System.out.println("Store name selected under Orders tab: "+firstStorename);
			menuPage.clickCartIcon();
			String secondStorename = cartPage.getstoreNameUnderCartTab();
			System.out.println("Store name selected under Cart tab: "+secondStorename);
			cartPage.clickcartBackBtn();
			Assert.assertEquals(firstStorename,secondStorename);
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());		
		}
		
		
		public void OrderHistoryTest() throws InterruptedException
		{
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			ordersPage.clickOnOrderNow();
			storeSelectionPage.selectStoreDisplay(user.getPincode());
			storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
			ordersPage.selectFirstStore();
			storeSelectionPage.orderHere();
			String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
			System.out.println("Pick up time seslected: "+pickupTimeSelected);
			menuPage.clickmenuPageAppetizersItemSelection();
			cartPage.clickaddToOrderBtn();
			menuPage.clickCartIcon();	
			cartPage.clickProceedToPayment();
			Thread.sleep(30000);
			paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
			paymentPage.selectMonth();
			paymentPage.selectYear();
			paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
			paymentPage.selectState();
			paymentPage.placeOrder();
			Thread.sleep(20000);
			String orderId_OrderConfirmationPage = orderConfirmationPage.getOrderConfirmationPageorderId();
			System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderConfirmationPage);
			orderConfirmationPage.clickcloseConfirmationBtn(); 
			profilePage.clickProfileTab();
			profilePage.clickOrdersBtn();
			orderHistoryPage.verifyOrderHistoryPage();
			String orderId_OrderHistoryPage = orderHistoryPage.getOrderId();
			System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderHistoryPage);
			Assert.assertEquals(orderId_OrderConfirmationPage, orderId_OrderHistoryPage);
			orderHistoryPage.clickorderHistotyPageBackBtn();
			profilePage.clickPersonalInfoBtn();
			profilePage.clickLogoutBtn();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
		}
		
		
		public void OrderConfirmationPageTest() throws InterruptedException
		{
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			ordersPage.clickOnOrderNow();
			storeSelectionPage.selectStoreDisplay(user.getPincode());
			storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
			ordersPage.selectFirstStore();
			storeSelectionPage.orderHere();
			String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
			System.out.println("Pick up time seslected: "+pickupTimeSelected);
			menuPage.clickmenuPageAppetizersItemSelection();
			cartPage.clickaddToOrderBtn();
			menuPage.clickCartIcon();	
			cartPage.clickProceedToPayment();
			Thread.sleep(30000);
			paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
			paymentPage.selectMonth();
			paymentPage.selectYear();
			paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
			paymentPage.selectState();
			paymentPage.placeOrder();
			Thread.sleep(20000);
			String orderId_OrderConfirmationPage = orderConfirmationPage.getOrderConfirmationPageorderId();
			System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderConfirmationPage);
			orderConfirmationPage.clickcloseConfirmationBtn(); 
			orderConfirmationPage.verifyOrderConfirmationPageValidation();
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
			
		}
		
		
		public void PaypalTest() throws InterruptedException
		{
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			ordersPage.clickOnOrderNow();
			storeSelectionPage.selectStoreDisplay(user.getPincode());
			storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
			ordersPage.selectFirstStore();
			storeSelectionPage.orderHere();
			String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
			System.out.println("Pick up time seslected: "+pickupTimeSelected);
			menuPage.clickmenuPageAppetizersItemSelection();
			cartPage.clickaddToOrderBtn();
			menuPage.clickCartIcon();	
			cartPage.clickProceedToPayment();
			Thread.sleep(30000);
			cartPage.clickpayPal();
			cartPage.clickpayPalBtn();
			Thread.sleep(15000);
			cartPage.EnterpayPalDetails();
			cartPage.clickpayPalSubmitBtn();
			Thread.sleep(15000);
			cartPage.clickConfirmPaymentBtn();
			Thread.sleep(20000);
			String orderId_OrderConfirmationPage = orderConfirmationPage.getOrderConfirmationPageorderId();
			System.out.println("Order Id on Order Confirmation Page: "+orderId_OrderConfirmationPage);
			orderConfirmationPage.clickcloseConfirmationBtn(); 
			orderConfirmationPage.verifyOrderConfirmationPageValidation();
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
			
		}
		
	

		
	
}

package GE.DCOM.GetGo.Mobile.Automation.Tests;
import org.junit.Assert;
import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderHistoryPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrdersPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;

public class GuestUserTest extends BaseTest {

	HomePage homePage = new HomePage(driver);
	ProfilePage profilePage = new ProfilePage(driver);
	StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
	OrdersPage ordersPage = new OrdersPage(driver);
	OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);
	User user = dataSet.getUser().get(0);
	MenuPage menuPage = new MenuPage(driver);
	
	@Test
	public void GuestUserOrderNavigationTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		orderHistoryPage.orderAgainBtn();
		ordersPage.orderAgainPageValidation();
		orderHistoryPage.favoritesBtn();
		ordersPage.favouritePageValidation();
		orderHistoryPage.menuBtn();
		homePage.clickHomeTab();
		profilePage.clickProfileTab();
	}
	@Test
	public void GuestUserStoreFavoritesTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		ordersPage.clickFirstFavouriteStore();
		ordersPage.verifypleaseSignInToastMsg();
		ordersPage.clickgoToOrderBackBtn();
		ordersPage.clickgoToOrderBackBtn();
		ordersPage.clickselectLaterBtn();
		homePage.clickHomeTab();
		profilePage.clickProfileTab();		
	}
	@Test
	public void GuestUserOrderAgainTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		ordersPage.clickOnOrderAgainBtn();
		ordersPage.orderAgainPageValidation();
		homePage.clickHomeTab();
	}
	@Test
	public void GuestUserEAIVPersonalizedOffersHome() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.clickHomeTab();
		homePage.scrollToBottom("Age-Verified Offers");
		homePage.clickAgeVerifiedOffersBtn();
		homePage.clickAgeVerifiedOffersCigarettesTobaccoBtn();
		profilePage.clickJustForYouTab();
		profilePage.verifyElementsUnderJustForYouAndCouponsGuestUser();
		profilePage.clickCouponsTab();
		profilePage.verifyElementsUnderJustForYouAndCouponsGuestUser();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.clickProfileTab();
		homePage.clickHomeTab();
	}
	@Test
	public void GuestUserAdvantageCardTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.clickHomeTab();
		homePage.clickSignInToAdvCardBtn();
		Thread.sleep(5000);
		homePage.verifyMyPerksPageValidation();
		homePage.clickbackBtn();
		profilePage.clickProfileTab();
	}
	
	@Test
	public void GuestUserProductFavoriteTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.clickHomeTab();
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		menuPage.clickmenuPageAppetizersItemSelection();
		ordersPage.clickPDPfavouriteBtn();
		ordersPage.PDPfavouritePageValidation();
		ordersPage.clickPDPBackBtn();
		homePage.clickHomeTab();
	}
	@Test
	public void GuestUserPersonalInfoTest() throws InterruptedException
	{	
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.verifySignInBtn();
		homePage.clickaccountTab();
		homePage.clickPersonalInfoTab();
		homePage.verifyPersonalInfoPage();
		homePage.clickPersonalInfoBackBtn();
		homePage.clickHomeTab();
	}
	@Test
	public void GuestUserWalletTest() throws InterruptedException
	{
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.clickaccountTab();
		homePage.clickwalletsTab();
		homePage.verifySignInToSeeTab();
		homePage.clickSignInToSeeTabCancelBtn();
		homePage.clickHomeTab();
		
	}
	@Test
	public void GuestUserOrderHistoryTest() throws InterruptedException
	{
		
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.clickaccountTab();
		profilePage.clickOrdersBtn();
		profilePage.verifyorderHistoryView();
		profilePage.verifyOrderHistoryPageText();
		profilePage.clickOrderHistoryBackBtn();
		homePage.clickHomeTab();
	}
	@Test
	public void FAQNavigationAccountHomeGuestTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.clickHomeTab();
		homePage.clickHomePerksBanner();
		homePage.scrollToBottom("FAQ's");
		profilePage.clickFAQBtn();;
		profilePage.verifyPerksFAQheaderIsDisplayed();
		profilePage.verifyPerksFAQviewIsDisplayed();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.clickProfileTab();
		profilePage.clickProfilePerksBanner();
		homePage.scrollToBottom("FAQ's");
		profilePage.clickFAQBtn();;
		profilePage.verifyPerksFAQheaderIsDisplayed();
		profilePage.verifyPerksFAQviewIsDisplayed();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.clickOrderHistoryBackBtn();
		homePage.clickHomeTab();
	}
}

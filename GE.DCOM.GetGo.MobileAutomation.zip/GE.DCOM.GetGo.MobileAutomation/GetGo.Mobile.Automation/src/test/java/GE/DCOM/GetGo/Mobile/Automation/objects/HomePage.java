package GE.DCOM.GetGo.Mobile.Automation.objects;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import java.time.Duration;
import java.util.HashMap;

import org.bson.BsonElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.WebDriverWait;


import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;


public class HomePage extends AndroidActions{
	
	AndroidDriver driver;
	WebDriverWait wait;
	ProfilePage profilePage = new ProfilePage(driver);

	public HomePage(AndroidDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(accessibility = "Close")
	private WebElement closepopup;
	
	@AndroidFindBy(xpath = "//*[@resource-id='home-tab-icon']")
	private WebElement homeTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='SignInButton']")
	private WebElement signinbtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='signInName']")
	private WebElement emailtxtbox;

	@AndroidFindBy(xpath = "//*[@resource-id='password']")
	private WebElement passwrd;
	
	@AndroidFindBy(xpath = "//*[@resource-id='next']")
	private WebElement signin;
	
	@AndroidFindBy(xpath = "//*[@resource-id='verifyNumberLater']")
	private WebElement remindlaterbtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='greeting-text']")
	private WebElement greetingText;
	
	@AndroidFindBy(xpath = "//*[@resource-id='locations-tab-icon']")
	private WebElement locationTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-tab-icon']")
	private WebElement orderTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='skipAdvantageCardBtn']")
	private WebElement skipAdvantageCardBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='account-tab-icon']")
	private WebElement accountTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='personal-info-card']")
	private WebElement personalInfoTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-heading']")
	private WebElement personalInfoPage;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-not-logged-in-message']")
	private WebElement personalInfoPageText;
	
	@AndroidFindBy(xpath = "//*[@resource-id='SignInButton']")
	private WebElement personalInfoTabSignInBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-back-button']")
	private WebElement personalInfoBackBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='wallet-card']")
	private WebElement walletsTab;
	
	@AndroidFindBy(xpath = "//*[@text='Sign In to see the Wallet']")
	private WebElement signInToSeeText;
	
	@AndroidFindBy(xpath = "//*[@resource-id='SignInButton']")
	private WebElement SignInToSeeSignInTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='cancel-button']")
	private WebElement SignInToSeeCancelTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.hatchedlabs.apps.getgo.staging:id/com_braze_inappmessage_modal']")
	private WebElement blackFridayDealsFlashMsg;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.hatchedlabs.apps.getgo.staging:id/com_braze_inappmessage_modal_close_button']")
	private WebElement blackFridayDealsFlashMsgBackBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Age-Verified Offers']")
	public WebElement ageVerifiedOffersBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Cancel' and @resource-id='button-text']")
	private WebElement ageVerifiedOffersCancelBtn;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'Beer, Wine, and Liquor') and @resource-id='button-text']")
	private WebElement ageVerifiedOffersBeerWineLiquorBtn;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'Cigarettes & Tobacco') and @resource-id='button-text']")
	private WebElement ageVerifiedOffersCigarettesTobaccoBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='home-perks-banner']")
	private WebElement signInToAdvCard;
	
	@AndroidFindBy(xpath = "//*[@text='myPerks']")
	private WebElement myPerksPageText;
	
	@AndroidFindBy(xpath = "//*[@text='Welcome to myPerks!']")
	private WebElement myPerksPageLogo;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'back-button']")
	private WebElement backBtn;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'Begin Age Verification') and @resource-id='button-text']")
	private WebElement beginAgeVerificationBtn;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'Verify your age to earn bonus perks')]")
	private WebElement verifyYourAgeTxt;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'Bonus Perks!')]")
	private WebElement bonusPerksTxt;
	
	@AndroidFindBy(xpath = "//*[@resource-id='home-perks-banner']")
	private WebElement homePerksBanner;
	
	
	public void clickHomeTab()
	{
		homeTab.click();
		System.out.println("Home page is clicked and navigated to 'Home Page' ");
	}
	
	public void clickWalletImg() 
	{
		driver.findElement(By.xpath("//*[@resource-id='view-wallet']")).click();
		System.out.println("'Wallet' is clicked and navigated to 'Wallet Page' ");
	}
	
	public void closepopup()
	{
		try {
			if (closepopup.isDisplayed())
            {
				closepopup.click();
				System.out.println("Close pop up is clicked and pop up is closed ");
            	Thread.sleep(5000);
            }
		} catch (Exception e) {
			System.out.println("Ad banner popup is not displayed");
		}
	}
	
	public void signin(String usernmae, String password) throws InterruptedException
	{
		signinbtn.click();
		System.out.println("'Sign In' button is clicked");
		Thread.sleep(15000);
		emailtxtbox.sendKeys(usernmae);
		System.out.println("'Username' entered is: "+usernmae);
		passwrd.sendKeys(password);
		System.out.println("'Password' entered is: "+password);
		signin.click();
		System.out.println("'Sign In' tab is clicked");
		Thread.sleep(25000);
		try {
            if (remindlaterbtn.isDisplayed())
            	System.out.println("'Remind later' is displayed");
            {
            	remindlaterbtn.click();
            	System.out.println("'Remind later' tab is clicked");
            	Thread.sleep(10000);
            }	
            if (skipAdvantageCardBtn.isDisplayed())
            	System.out.println("'Skip advantage card' is displayed");
            {
            	skipAdvantageCardBtn.click();
            	System.out.println("'Skip advantage card' tab is clicked");
            	Thread.sleep(10000);
            }
		} catch (Exception e) {
			System.out.println("Remind later / skip Advantage button is not displayed in this occurance ");
		}
	}
	
	public boolean loggedInAccount(String firstname) 
	{
		String loggedInAccName = greetingText.getText();
		String actual = loggedInAccName.substring(4, loggedInAccName.length()-1);
		if(actual.equals(firstname)) 
		{
			System.out.println("Logged in Account name is displayed");
			return true;
		}
		return false; 
	}
	
	public void clickLocationTab()
	{
		locationTab.click();
		System.out.println("'Location' tab is clicked");
	}
	
	public void clickorderTab()
	{
		orderTab.click();
		System.out.println("'Order' tab is clicked");
	}
	
	public void verifySignInBtn()
	{
		signinbtn.isDisplayed();
		System.out.println("Sign In button is displayed");
	}
	
	public void clickaccountTab()
	{
		accountTab.click();
		System.out.println("Account tab is clicked ");
	}
	
	public void clickPersonalInfoTab()
	{
		personalInfoTab.click();
		System.out.println("Personal Info tab is clicked ");
	}
	
	public String displayPersonalInfoTab()
	{
		String Personal_info_Page_text = personalInfoPageText.getText();
		System.out.println("Personal_info_Page_text: "+Personal_info_Page_text);
		return Personal_info_Page_text;
	}
	
	public void verifypersonalInfoTabSignInBtn()
	{
		System.out.println("Personal Info Sign Tab is displayed: "+personalInfoTabSignInBtn.isDisplayed());
		
	}
	
	public void verifyPersonalInfoPage()
	{
		System.out.println("Personal Info page is displayed");
		displayPersonalInfoTab();
		verifypersonalInfoTabSignInBtn();
	}
	
	public void clickPersonalInfoBackBtn()
	{
		personalInfoBackBtn.click();
		System.out.println("'Personal info back' button is clicked ");
	}
	
	public void clickwalletsTab()
	{
		walletsTab.click();
		System.out.println("Wallets tab is clicked ");
	}
	
	public String verifySignInToSeeText()
	{
		String SignInToSee_text = signInToSeeText.getText();
		System.out.println("Sign In to see tab text : "+SignInToSee_text);
		return SignInToSee_text;
	}
	
	
	public void verifySignInToSeeTabSignInBtn()
	{
		System.out.println("Sign In to see Sign button is displayed: "+SignInToSeeSignInTab.isDisplayed());
	}
	
	public void verifySignInToSeeTabCancelBtn()
	{
		System.out.println("Sign In to see Sign button is displayed: "+SignInToSeeCancelTab.isDisplayed());
	}
	
	public void clickSignInToSeeTabCancelBtn()
	{
		SignInToSeeCancelTab.click();
		System.out.println("Sign In to see Cancel button is clicked");
	}
	
	
	public void verifySignInToSeeTab()
	{
		System.out.println("'Sign In to see' tab is displayed");
		verifySignInToSeeText();
		verifySignInToSeeTabSignInBtn();
		verifySignInToSeeTabCancelBtn();
	}
	
	public void verifyBlackFridayFlashMsg()
	{
		try {
			if(blackFridayDealsFlashMsg.isDisplayed())
            {
				blackFridayDealsFlashMsgBackBtn.click();
            	Thread.sleep(6000);
            	System.out.println("Black Friday Flash message is cancelled");
            }	
    
		} catch (Exception e) {
			System.out.println("Black Friday Flash message did not appear");
		}
	}
	
	public void clickAgeVerifiedOffersBtn() throws InterruptedException
	{	
		
		Thread.sleep(1000);
		try {
			if(ageVerifiedOffersBtn.isDisplayed())
            {
				ageVerifiedOffersBtn.click();
            	Thread.sleep(1000);
            	System.out.println("Age Verified Offers Btn is Clicked");
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers Btn is not clicked");
		}
	}
	public void clickAgeVerifiedOffersCancelBtn() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(ageVerifiedOffersCancelBtn.isDisplayed())
            {
				ageVerifiedOffersCancelBtn.click();
            	Thread.sleep(1000);
            	System.out.println("Age Verified Offers Cancel Btn is Clicked");
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers Cancel Btn is not clicked");
		}
	}
	public void clickAgeVerifiedOffersBeerWineLiquorBtn() throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			if(ageVerifiedOffersBeerWineLiquorBtn.isDisplayed())
            {
				ageVerifiedOffersBeerWineLiquorBtn.click();
            	Thread.sleep(1000);
            	System.out.println("Age Verified Offers Beer Wine Liquor Btn is Clicked");
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers Beer Wine Liquor Btn is not clicked");
		}
		
	}
	public void clickAgeVerifiedOffersCigarettesTobaccoBtn() throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			if(ageVerifiedOffersCigarettesTobaccoBtn.isDisplayed())
            {
				ageVerifiedOffersCigarettesTobaccoBtn.click();
            	Thread.sleep(1000);
            	System.out.println("Age Verified Offers Cigarettes Tobacco Btn is Clicked");
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers Cigarettes Tobacco Btn is not clicked");
		}
	}
	public boolean verifyAgeVerifiedOffersCancelBtnDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(ageVerifiedOffersCancelBtn.isDisplayed())
            {
            	System.out.println("Age Verified Offers Cancel Btn is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers Cancel Btn is not Displayed");
		}
		return ageVerifiedOffersCancelBtn.isDisplayed();
	}
	public boolean verifyAgeVerifiedOffersBeerWineLiquorBtnDisplayed() throws InterruptedException
	{
		
		Thread.sleep(1000);
		try {
			if(ageVerifiedOffersBeerWineLiquorBtn.isDisplayed())
            {
            	System.out.println("Age Verified Offers Beer Wine Liquor Btn is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers Beer Wine Liquor Btn is not Displayed");
		}
		return ageVerifiedOffersBeerWineLiquorBtn.isDisplayed();
	}
	public boolean verifyAgeVerifiedOffersCigarettesTobaccoBtnDisplayed() throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			if(ageVerifiedOffersCigarettesTobaccoBtn.isDisplayed())
            {
            	System.out.println("Age Verified Offers Cigarettes Tobacco Btn is Displayed");
            	Thread.sleep(1000);   	
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers Cigarettes Tobacco Btn is not Displayed");
		}
		return ageVerifiedOffersCigarettesTobaccoBtn.isDisplayed();
	}
	
	@SuppressWarnings("deprecation")
	public void scrollToBottom(String text) {	
       try {
    		Thread.sleep(5000); 
    		driver.findElement(MobileBy.AndroidUIAutomator(
                    "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollToEnd(10);"));
           	Thread.sleep(1000);   	
           	System.out.println("It scrolled to the text "+text);
		} catch (Exception e) {
			System.out.println("It didn't scroll to the text "+text);
		}
    }
	
	public void clicksignInToAdvCard(String usernmae, String password) throws InterruptedException
	{
		signInToAdvCard.click();
		System.out.println("'Sign In' button is clicked");
		Thread.sleep(15000);
		emailtxtbox.sendKeys(usernmae);
		System.out.println("'Username' entered is: "+usernmae);
		passwrd.sendKeys(password);
		System.out.println("'Password' entered is: "+password);
		signin.click();
		System.out.println("'Sign In' tab is clicked");
		Thread.sleep(25000);
		try {
            if (remindlaterbtn.isDisplayed())
            	System.out.println("'Remind later' is displayed");
            {
            	remindlaterbtn.click();
            	System.out.println("'Remind later' tab is clicked");
            	Thread.sleep(10000);
            }	
            if (skipAdvantageCardBtn.isDisplayed())
            	System.out.println("'Skip advantage card' is displayed");
            {
            	skipAdvantageCardBtn.click();
            	System.out.println("'Skip advantage card' tab is clicked");
            	Thread.sleep(10000);
            }
		} catch (Exception e) {
			System.out.println("Remind later / skip Advantage button is not displayed in this occurance ");
		}
	}
	public void verifymyPerksPageText()
	{
		if(myPerksPageText.isDisplayed()) {
		System.out.println("'My perks' page is displayed ");
	}
	}
	
	public void verifymyPerksPageLogo()
	{
		if(myPerksPageLogo.isDisplayed()) {
		System.out.println("'My perks' logo is displayed ");
	}
	}
	
	public void verifyMyPerksPageValidation()
	{
		System.out.println("'My perks' page validations: ");
		verifymyPerksPageText();
		verifymyPerksPageLogo();
	}
	
	public void clickbackBtn() throws InterruptedException
	{
		Thread.sleep(2000);
		backBtn.click();
		System.out.println("backBtn button is clicked");
	}
	public boolean verifyBonusPerksTxtIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(bonusPerksTxt.isDisplayed())
            {
            	System.out.println("bonus Perks Text is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("bonus Perks Text is not Displayed");
		}
		return bonusPerksTxt.isDisplayed();
	}
	public boolean verifyYourAgeTxtIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(verifyYourAgeTxt.isDisplayed())
            {
            	System.out.println("verify Your Age Txt is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("verify Your Age Text is not Displayed");
		}
		return verifyYourAgeTxt.isDisplayed();
	}
	
	public boolean verifyBeginAgeVerificationBtnisDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(beginAgeVerificationBtn.isDisplayed())
            {
            	System.out.println("begin Age Verification Btn is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("begin Age Verification Btn is not Displayed");
		}
		return beginAgeVerificationBtn.isDisplayed();
	}
	public void verifyElementsUnderJustForYouAndCouponsSignedNonVerifiedUser() throws InterruptedException {
		Thread.sleep(5000);
		this.verifyBonusPerksTxtIsDisplayed();
		this.verifyYourAgeTxtIsDisplayed();
		this.verifyBeginAgeVerificationBtnisDisplayed();
	}
	public boolean verifyHomePerksBannerIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(homePerksBanner.isDisplayed())
            {
            	System.out.println("home Perks Banner is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("home Perks Banner is not Displayed");
		}
		return homePerksBanner.isDisplayed();
	}
	public void clickHomePerksBanner() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(homePerksBanner.isDisplayed())
            {
				homePerksBanner.click();
            	System.out.println("home Perks Banner is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("home Perks Banner is not clicked");
		}
	}
	public void clickSignInToAdvCardBtn() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(signInToAdvCard.isDisplayed())
            {
				signInToAdvCard.click();
            	System.out.println("signIn To AdvCard is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("signIn To AdvCard is not clicked");
		}
	}

}


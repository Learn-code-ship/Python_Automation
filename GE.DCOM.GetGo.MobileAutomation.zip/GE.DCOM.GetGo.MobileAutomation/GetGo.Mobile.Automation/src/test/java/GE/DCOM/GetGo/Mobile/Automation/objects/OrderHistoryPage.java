package GE.DCOM.GetGo.Mobile.Automation.objects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class OrderHistoryPage extends AndroidActions{
	AndroidDriver driver;

	public OrderHistoryPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-id']")
	private WebElement orderId;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-status']")
	private WebElement orderStatus;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-create-time']")
	private WebElement orderPickupTime;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-create-day']")
	private WebElement orderPickupDay;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-total']")
	private WebElement orderTotal;
	
	@AndroidFindBy(xpath = "//*[@text='View Details']")
	private WebElement viewDetailsBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Order Again']")
	private WebElement orderAgainBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Favorites']")
	private WebElement favoritesBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='menu-tab']")
	private WebElement menuBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Order History']")
	private WebElement orderHistoryHeader;
	
	@AndroidFindBy(xpath = "//*[@resource-id='back-button']")
	private WebElement orderHistotyPageBackBtn;
	
	@AndroidFindBy(xpath = "//*[@text='View Details']")
	private WebElement orderHistoryViewDetails;
	
	@AndroidFindBy(xpath = "//*[@text='Order Details']")
	private WebElement orderDetailsHeader;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-id']")
	private WebElement OrderDetailsPageorderId;
	
	
	public String getOrderId()
	{	
		String Order_Id=orderId.getText().replace("Order ID: ", "");
		System.out.println("Order Id is: "+Order_Id);
		return Order_Id;
	}
	
	public String getOrderStatus()
	{		
		String Order_Status=orderStatus.getText();
		System.out.println("Order status is: "+Order_Status);
		return Order_Status;
	}
	
	public String getPickupDay()
	{		
		String Order_PickUpDay=orderPickupDay.getText();
		System.out.println("Order pick up day is: "+Order_PickUpDay);
		return Order_PickUpDay;
	}
	
	public String getPickupTime()
	{		
		String Order_PickUp_Time=orderPickupTime.getText();
		System.out.println("Order pick up time is: "+Order_PickUp_Time);
		return Order_PickUp_Time;
	}
	
	public String getTotalPrice()
	{	
		String Total_Price=orderTotal.getText().replace("Total ", "");
		System.out.println("Total price is: "+Total_Price);
		return Total_Price;
	}
	
	public boolean verifyViewDetailBtn()
	{
		try {
            return viewDetailsBtn.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}

	public void orderAgainBtn()
	{
		orderAgainBtn.click();
		System.out.println("Order again button is clicked");
		orderAgainBtn.isDisplayed();
		System.out.println("Order again tab is displayed");
		
	}
	
	public void favoritesBtn()
	{
		favoritesBtn.click();
		System.out.println("Favourite button is clicked");
		favoritesBtn.isDisplayed();
		System.out.println("Favotites tab is displayed");
	}
	
	public void menuBtn()
	{
		menuBtn.click();
		System.out.println("Menu button is clicked");
		menuBtn.isDisplayed();
		System.out.println("Menu tab is displayed");
	}
	
	public void verifyOrderHistoryPage()
	{
		if(orderHistoryHeader.isDisplayed()) {
			System.out.println("'Order History' page is displayed");
		}
	}
	
	public void clickorderHistotyPageBackBtn() throws InterruptedException{
		orderHistotyPageBackBtn.click();
		System.out.println("Order History page 'Back button' page is clicked");
		Thread.sleep(5000);
	}
	
	public void clickorderHistoryViewDetails()
	{		
		orderHistoryViewDetails.click();
		System.out.println("Order History page 'View Details' button is clicked");
		
	}
	
	public void verifyOrderDetailsPage()
	{
		if(orderDetailsHeader.isDisplayed()) {
			System.out.println("'Order Details' page is displayed");
		}
	}
	
	public String getOrderDetailsPageorderId()
	{	
		String Order_Id=OrderDetailsPageorderId.getText().replace("Order ID: ", "");
		System.out.println("The Order Id in Confirmation page is: "+Order_Id);
		return Order_Id;
	}
	
	public void verifyOrderDetailsPageValidation() throws InterruptedException{
		Thread.sleep(6000);
		System.out.println("Order Details page validations are: \n");
		verifyOrderDetailsPage();
	}
}


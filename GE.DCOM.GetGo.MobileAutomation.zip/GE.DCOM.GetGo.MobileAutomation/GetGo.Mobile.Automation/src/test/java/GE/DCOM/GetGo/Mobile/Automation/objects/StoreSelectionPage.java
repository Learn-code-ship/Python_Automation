package GE.DCOM.GetGo.Mobile.Automation.objects;


import java.time.LocalTime;
import java.time.ZoneId;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class StoreSelectionPage extends AndroidActions{
	
	AndroidDriver driver;

	public StoreSelectionPage(AndroidDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-tab-icon']")
	private WebElement orderTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='select-a-store']")
	private WebElement storeSelectBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='store-search']")
	private WebElement storeTextField;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'store-name']")
	private WebElement selectYourStore;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-here']")
	private WebElement orderHereBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='testid_asap']")
	private WebElement asapBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='testid_schedule']")
	private WebElement scheduleLaterBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Today']")
	private WebElement todayBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Tomorrow']")
	private WebElement tomorrowBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='time-slot-button']")
	private WebElement timeSlotDropdown;
	
	@AndroidFindBy(xpath = "(//*[@resource-id='dropdown-list-item'])[3]//*")
	private WebElement timeSlotSelection;
	
	@AndroidFindBy(xpath = "(//*[@resource-id='dropdown-list-item'])[X]//*")
	private WebElement timeSlotSelection1;
	
	@AndroidFindBy(xpath = "(//*[@resource-id='dropdown-list-item'])[4]//*")
	private WebElement newtimeSlotSelection;
	
	@AndroidFindBy(xpath = "//*[@text='07:00 am']")
	private WebElement alcoholTimeSlot;
	
	@AndroidFindBy(xpath = "//*[@resource-id='start-order']")
	private WebElement startOrderBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='close-error']")
	private WebElement modalOkButton;
	
	@AndroidFindBy(xpath = "//*[@resource-id='base-menu-store-name']")
	private WebElement menuStoreName;
	
	@AndroidFindBy(xpath = "//*[@resource-id='search-box']")
	private WebElement storeSearchBox;
	
	@AndroidFindBy(xpath = "//*[@resource-id='clear-store-search']")
	private WebElement storeSearchCancelBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'store-distance-text-783']")
	private WebElement firstStore;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'store-distance-text-1560']")
	private WebElement secondStore;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'store-distance-text-739']")
	private WebElement thirdStore;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'store-distance-text-1737']")
	private WebElement fourthStore;
	
	@AndroidFindBy(xpath = "//*[@resource-id='go-to-order-back-button']")
	private WebElement storeSearchBackBtn;
	
	@AndroidFindBy(xpath = "//*[@text = 'Continue']")
	private WebElement continueBtn;
	
	
	public void clickOrderTab()
	{
		orderTab.click();
		System.out.println("Order tab is clicked ");
	}
	
	public void selectStore(String storeNumber) throws InterruptedException
	{
		storeSelectBtn.click();
		Thread.sleep(5000);
		if(storeSelectBtn.isDisplayed()==true) {
			storeSelectBtn.click();
		}
		System.out.println("Store Select button is clicked ");
		Thread.sleep(5000);
		try {
            if (modalOkButton.isDisplayed())
            {
            	modalOkButton.click();
            	System.out.println("Modal Ok button is clicked ");
            }			
		} catch (Exception e) {
			System.out.println("modal button is not displayed in this occurance ");
		}
		Thread.sleep(15000);
		storeTextField.click();
		System.out.println("Store text field is clicked ");
		storeTextField.sendKeys(storeNumber);
		System.out.println("Store number is: "+storeNumber);
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		Thread.sleep(5000);
		selectYourStore.click();
		System.out.println("Select your Store is clicked ");
	}
	public String scheduleLaterPickupTime() throws InterruptedException
	{
		Thread.sleep(1000);
		scheduleLaterBtn.click();
		System.out.println("Schedule later is clicked ");
		Thread.sleep(1000);
		timeSlotDropdown.click();
		System.out.println("Time slot dropdown is clicked ");
		String pickupTimeSelected = timeSlotSelection.getText();
		System.out.println("Pick up time selected is: "+pickupTimeSelected);
		timeSlotSelection.click();
		System.out.println("Time slot selection is clicked ");
		startOrderBtn.click();
		Thread.sleep(10000);
		System.out.println("Start order button is clicked ");
		return pickupTimeSelected;
	}
	
	public void scheduleTimeForAlcoholItem()
	{		
		LocalTime currentTime = LocalTime.now(ZoneId.of("US/Eastern"));
		LocalTime startTime = LocalTime.of(7, 0);
		LocalTime endTime = LocalTime.of(22, 0);
	    if (currentTime.isBefore(startTime)) 
	    {
	    	scheduleLaterBtn.click();
	    	System.out.println("Schedule later button is clicked ");
	    	timeSlotDropdown.click();
	    	System.out.println("Time slot dropdown is clicked ");
	    	scrollToText("07:00 am");
			alcoholTimeSlot.click();
			System.out.println("Time scheduled for Today 7:00 AM");
	    } else if (currentTime.isBefore(endTime)) 
	    {
	    	asapBtn.click();
	    	System.out.println("Time selected as ASAP");
		} else 
		{
			scheduleLaterBtn.click();
			System.out.println("Schedule later button is clicked ");
			tomorrowBtn.click();
			System.out.println("Tomorrow button is clicked ");
			timeSlotDropdown.click();
			System.out.println("Time slot dropdown is clicked ");
			scrollToText("07:00 am");
			alcoholTimeSlot.click();
			System.out.println("Time scheduled for Today 7:00 AM");
		}		
		startOrderBtn.click();
		System.out.println("Start order button is clicked ");
	}
	
	public void orderHere()
	{
		orderHereBtn.click();
		System.out.println("Order here button is clicked ");
	}
	
	public void orderTab()
	{
		orderTab.click();
		System.out.println("Order Tab is clicked ");
	}
	
	public void startOrderBtn() throws InterruptedException
	{
		startOrderBtn.click();
		System.out.println("Start Order button is clicked ");
		Thread.sleep(10000);
	}
	
	public void selectStoreDisplay(String storeNumber) throws InterruptedException
	{
		storeSelectBtn.click();
		System.out.println("Start select button is clicked ");
		Thread.sleep(5000);
		try {
            if (modalOkButton.isDisplayed())
            {
            	modalOkButton.click();
            	System.out.println("Modal Ok button is clicked ");
            }			
		} catch (Exception e) {
			System.out.println("modal button is not displayed in this occurance ");
		}
		Thread.sleep(15000);
		storeTextField.click();
		System.out.println("Store Text field button is clicked ");
		storeTextField.sendKeys(storeNumber);
		System.out.println("Store number selected is: "+storeNumber);
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		Thread.sleep(5000);
		selectYourStore.isDisplayed();
	}
	
	public void selectYourStore()
	{
		selectYourStore.click();
		System.out.println("Select your store button is clicked ");

	}
	
	public String menuStoreName(String page)
	{
		String storeName=menuStoreName.getText();
		System.out.println("The store selected in "+page+" is "+storeName);
		return storeName;
		
	}
	
	public void enterCityOrZipCodeToGetStoreAndValidateIt(String storeNumber) throws InterruptedException
	{
		storeTextField.sendKeys(storeNumber);
		System.out.println("Store selected is: "+storeNumber);
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		Thread.sleep(3000);
		storeSelectBtn.click();
		System.out.println("Store select button is clicked ");
		Thread.sleep(10000);
		storeTextField.click();
		System.out.println("Store text field is clicked ");
		storeTextField.sendKeys(storeNumber);
		System.out.println("Store selected is: "+storeNumber);
		Thread.sleep(3000);
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		Thread.sleep(5000);
		selectYourStore.isDisplayed();
	}
	
	public void enterStoreDetailsAndValidateIt(String storeNumber) throws InterruptedException
	{
	storeTextField.click();
	System.out.println("Store text field is clicked ");
	storeTextField.sendKeys(storeNumber);
	System.out.println("Store selected is: "+storeNumber);
	Thread.sleep(3000);
	driver.pressKey(new KeyEvent(AndroidKey.ENTER));
	selectYourStore.isDisplayed();
	}
	
	public void checkModalOkBtn() throws InterruptedException { 	
            	try {
                    if (modalOkButton.isDisplayed())
                    {
                    	modalOkButton.click();
                    }			
        		} catch (Exception e) {
        			System.out.println("modal button is not displayed in this occurance ");
        		}
            	Thread.sleep(3000);
	}
	public void searchStore(String storeNumber) throws InterruptedException
	{
		storeSelectBtn.click();
		System.out.println("Store select button is clicked ");
		Thread.sleep(5000);
		try {
            if (modalOkButton.isDisplayed())
            {
            	modalOkButton.click();
        		System.out.println("Modal Ok button is clicked ");
            }			
		} catch (Exception e) {
			System.out.println("modal button is not displayed in this occurance ");
		}
		Thread.sleep(15000);
		storeTextField.click();
		System.out.println("Store text field is clicked ");
		storeTextField.sendKeys(storeNumber);
		System.out.println("Store selected is: "+storeNumber);
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		Thread.sleep(5000);
		
	}
	
	public void clickstoreSearchCancelBtn()
	{
		storeSearchCancelBtn.click();
		System.out.println("Store search Cancel button is clicked");
	}
	
	public void clickstoreSearchBackBtn()
	{
		storeSearchBackBtn.click();
		System.out.println("Store search Back button is clicked");
	}
	
	public void validateStoreDisplayOrder() throws InterruptedException
	{
	Thread.sleep(4000);
	
	String[] FS =firstStore.getText().split(" ");
	Double firstStoreName = Double.parseDouble(FS[0].replace(",",""));
	
	String[] SS =firstStore.getText().split(" ");
	Double secondStoreName = Double.parseDouble(SS[0].replace(",",""));
	
	String[] TS =firstStore.getText().split(" ");
	Double thirdStoreName = Double.parseDouble(TS[0].replace(",",""));
	
	String[] FoS =firstStore.getText().split(" ");
	Double fourthStoreName = Double.parseDouble(FoS[0].replace(",",""));
	
	if( firstStoreName <= secondStoreName) {
           if (secondStoreName <= thirdStoreName) {
           		if(thirdStoreName<=fourthStoreName) {
           			System.out.println("The stores are in ascending order");
           		}
           }
	   }
	}

	public String changescheduleLaterPickupTime() throws InterruptedException
	{
		Thread.sleep(1000);
		timeSlotDropdown.click();
		System.out.println("Time slot dropdown is clicked ");
		String pickupTimeSelected = newtimeSlotSelection.getText();
		System.out.println("New Pick up time selected is: "+pickupTimeSelected);
		timeSlotSelection.click();
		System.out.println("Time slot selection is clicked ");
		continueBtn.click();
		Thread.sleep(6000);
		return pickupTimeSelected;
	}
	
	public void clicktimeSlotSelection()
	{
		//"(//*[@resource-id='dropdown-list-item'])[4]//*")
		
		System.out.println("Store search Back button is clicked");
	}

	
}
	
	
	

	
	
	
			



package GE.DCOM.GetGo.Mobile.Automation.Tests;

import org.junit.Assert;
import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderHistoryPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrdersPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;

public class HomePageTests extends BaseTest{
	HomePage homePage = new HomePage(driver);
	ProfilePage profilePage = new ProfilePage(driver);
	StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
	OrdersPage ordersPage = new OrdersPage(driver);
	OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);
	User user = dataSet.getUser().get(0);
	MenuPage menuPage = new MenuPage(driver);
	
	@Test
	public void NavigationTest() throws InterruptedException
	{

		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
	@Test
	public void HomePageStartOrderTest() throws InterruptedException
	{

		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		ordersPage.clickOnOrderNow();
		storeSelectionPage.selectStoreDisplay(user.getPincode());
		storeSelectionPage.enterCityOrZipCodeToGetStoreAndValidateIt(user.getCity());
		ordersPage.selectFirstStore();
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		System.out.println(pickupTimeSelected);
		ordersPage.clickOnmenuTabBtn();
 		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
		
	}
	
	@Test
	public void EAIVAgeVerifiedOffersHomeTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.scrollToBottom("Age-Verified Offers");
		homePage.clickAgeVerifiedOffersBtn();
		Assert.assertEquals(true, homePage.verifyAgeVerifiedOffersCigarettesTobaccoBtnDisplayed());
		Assert.assertEquals(true, homePage.verifyAgeVerifiedOffersBeerWineLiquorBtnDisplayed());
		Assert.assertEquals(true, homePage.verifyAgeVerifiedOffersCancelBtnDisplayed());
		homePage.clickAgeVerifiedOffersCancelBtn();
 		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
	@Test
	public void EAIVBeerWineAndLiquorHomeTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.scrollToBottom("Age-Verified Offers");
		homePage.clickAgeVerifiedOffersBtn();
		homePage.clickAgeVerifiedOffersBeerWineLiquorBtn();
		profilePage.verifyElementsUnderBeerAndLiquor();
		profilePage.clickCloseBtn();
 		profilePage.Signout();
	}
  @Test
	public void EAIVCigarettesTobaccoAgeVerificationHomeTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.scrollToBottom("Age-Verified Offers");
		homePage.clickAgeVerifiedOffersBtn();
		homePage.clickAgeVerifiedOffersCigarettesTobaccoBtn();
		homePage.verifyElementsUnderJustForYouAndCouponsSignedNonVerifiedUser();
		profilePage.clickCouponsTab();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
	@Test
	public void PerksAndAdvantageCardTests() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.clickWalletImg();
		profilePage.findTotalPerks();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
	@Test
	public void myPerksValidationTestHomeTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.clickHomePerksBanner();
		profilePage.clickHowItWorksBtn();
		profilePage.verifyElementsUnderHowItWorks();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
  @Test
  public void FAQNavigationHomeTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.clickHomePerksBanner();
		homePage.scrollToBottom("FAQ's");
		profilePage.clickFAQBtn();;
		profilePage.verifyPerksFAQheaderIsDisplayed();
		profilePage.verifyPerksFAQviewIsDisplayed();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}

}

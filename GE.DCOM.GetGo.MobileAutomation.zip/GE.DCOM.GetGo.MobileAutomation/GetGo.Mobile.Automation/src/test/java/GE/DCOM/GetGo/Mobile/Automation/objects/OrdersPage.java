package GE.DCOM.GetGo.Mobile.Automation.objects;


import java.time.Duration;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class OrdersPage extends AndroidActions{
	AndroidDriver driver;
	String storename,storename2;
	WebElement ele;
	WebDriverWait wait;

	public OrdersPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@text='View Details']")
	private WebElement orderFavTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-nearby-tab']")
	private WebElement nearby;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-favourite-tab']")
	private WebElement FavTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'store-name']")
	private WebElement selectYourStore;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Order Now']/ancestor::android.widget.Button[@resource-id='iwbt-primary-button']")
	private WebElement orderNow;
	
	@AndroidFindBy(xpath = "//*[@resource-id='base-menu-store-name']")
	private WebElement storeNameUnderOrdersTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'base-menu-selected-store-header']")
	private WebElement storeNameUnderOrdersTabBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'order-again-tab']")
	private WebElement orderAgainTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'menu-tab']")
	private WebElement menuTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'close-confirmation-page']")
	private WebElement closeConfirmationPageBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'order-again-empty']")
	private WebElement orderagainempty;
	
	@AndroidFindBy(xpath = "//*[@text = 'View Details']")
	private WebElement viewDetailsTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'order-id']")
	private WebElement orderId;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'sub-total-price-text']")
	private WebElement subTotalPriceText;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'tax-price-text']")
	private WebElement taxPriceText;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'total-price-text']")
	private WebElement totalPriceText;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'toggle-favorite']")
	private WebElement toggleFavourite;
	
	//@AndroidFindBy(xpath = "//*[@resource-id = 'toast-0.24053424150308764']")
	@AndroidFindBy(xpath = "//*[@bounds = '[0,2531][1440,2619]']")
	private WebElement pleaseSignInToastMsg;
	
	@AndroidFindBy(xpath = "//*[@text = 'Please sign in to favorite the store.']")
	private WebElement pleaseSignInToastMsgText;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'go-to-order-back-button']")
	private WebElement goToOrderBackBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'select-later']")
	private WebElement selectLaterBtn;
	
	@AndroidFindBy(xpath = "//*[@text = 'No need to start from scratch']")
	private WebElement orderAgainPageTextOne;
	
	@AndroidFindBy(xpath = "//*[@text = 'Please sign in to view your previous orders and start ordering']")
	private WebElement orderAgainPageTextTwo;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'SignInButton']")
	private WebElement orderAgainPageSignInBtn;
	
	@AndroidFindBy(xpath = "//*[@text = 'Sign in to see your saved favorites and start ordering']")
	private WebElement favouritePageTextTwo;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'PDP-Favourite-Button']")
	//@AndroidFindBy(xpath = "//*[@bounds = '[1216,179][1356,319]")
	private WebElement PDPfavouriteBtn;
	
	@AndroidFindBy(xpath = "//*[@text = 'Sign in or sign up']")
	private WebElement PDPfavouritePageTextOne;
	
	@AndroidFindBy(xpath = "//*[@text = 'We would love to make your order, to add your items please sign in or create an account.']")
	//@AndroidFindBy(xpath = "//*[@bounds = '[104,1632][1336,1772]'")
	private WebElement PDPfavouritePageTexttwo;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'SignInButton']")
	private WebElement PDPfavouritePageSignInOrSignUpBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id = 'back-button']")
	private WebElement backBtn;
	
	
	
	
	
	
	public void CheckAndUncheckFavoriteStores() {
		
		try {
			List<WebElement> favoriteCount = driver
					.findElements(By.xpath("//*[@resource-id='toggle-favorite']"));
			List<WebElement> nearByfavoriteStore = driver
					.findElements(By.xpath("//*[@resource-id='store-name']"));
			for (WebElement element : favoriteCount) {
				element.click();
				System.out.println("Have favorated the Store");
				Thread.sleep(1000);
				break;
			}
			for (WebElement elementFav : nearByfavoriteStore) {
				storename = elementFav.getText();
				System.out.println("Got the Fav store text in FavoriteTab");
				FavTab.click();
				System.out.println("Have clicked on the Fav Tab");
				Thread.sleep(5000);
				break;
			}
			wait = new WebDriverWait(driver, Duration.ofSeconds(4));
			WebElement favoriteStore = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@resource-id='fav-store-container']//*[@resource-id='store-name']")));
			storename2=favoriteStore.getText();
			Assert.assertEquals(storename, storename2);
			System.out.println("Got the text of the Favorite Item");
			nearby.click();
			System.out.println("Have Clicked on NearBy Tab");
			Thread.sleep(5000);
			List<WebElement> FavItem = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//*[@resource-id='toggle-favorite']")));
			for (WebElement elementFav : FavItem) {
				elementFav.click();
				System.out.println("Have Unfavored the Store");
				Thread.sleep(2000);
				System.out.println("Have clicked on the Fav Tab");
				FavTab.click();
				break;
			}
			wait = new WebDriverWait(driver, Duration.ofSeconds(4));
			WebElement NoFavorites = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@resource-id='fav-store-container']")));
			System.out.println("No Favorites are there "+NoFavorites.isDisplayed());
			Thread.sleep(2000);
			nearby.click();
			System.out.println("Have Clicked on NearBy Tab");
		}
	  catch (Exception e) {
		e.printStackTrace();
	  }
	}
	
	public void selectFirstStore() throws InterruptedException
	{
		selectYourStore.click();
		System.out.println("Select your storevbutton is clicked");
	}
	
	public void clickOnOrderNow() throws InterruptedException
	{	
		orderNow.click();
		System.out.println("Order now button is clicked");
	}
	
	public void clickOnstoreNameUnderOrdersTabBtn() throws InterruptedException
	{
	Thread.sleep(2000);
	storeNameUnderOrdersTabBtn.click();
	System.out.println("Store name under Orders tab button is clicked");
	}
	public String getstoreNameUnderOrdersTab() throws InterruptedException
	{
	Thread.sleep(4000);
	return storeNameUnderOrdersTab.getText();
	}
	
	public void clickOnOrderAgainBtn() throws InterruptedException
	{
	Thread.sleep(2000);
	orderAgainTab.click();
	System.out.println("Order Again tab is clicked");
	}
	public void clickOnmenuTabBtn() throws InterruptedException
	{
	Thread.sleep(2000);
	System.out.println("Menu Tab is displayed"+menuTab.isDisplayed());
	menuTab.click();
	System.out.println("Menu tab is clicked");
	}
	public void clickOnthefirstReOrderButton() throws InterruptedException
	{
	Thread.sleep(5000);
	try {
	List<WebElement> reorderButtons = driver.findElements(By.xpath("//*[contains(@resource-id, 'order-again-reorder')]"));
	for (WebElement element : reorderButtons) {
	element.click();
	System.out.println("Have clicked on the first reorder Button");
	Thread.sleep(1000);
	break;
	}
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	}
	
	public void clickOncloseConfirmationPageBtnBtn() throws InterruptedException
	{
		Thread.sleep(2000);
		System.out.println("Confirmation message button is displayed: "+closeConfirmationPageBtn.isDisplayed());
		closeConfirmationPageBtn.click();
		System.out.println("Close confirmation button is clicked ");
		Thread.sleep(5000);
	}
	public boolean orderagainempty() throws InterruptedException
	{	
		Thread.sleep(2000);
		System.out.println("Order Again empty is displayed: "+orderagainempty.isDisplayed());
		return orderagainempty.isDisplayed();
	}
	public void clickOnviewDetailsTab() throws InterruptedException
	{
	Thread.sleep(2000);
	viewDetailsTab.click();
	System.out.println("View details tab is clicked ");
	}
	
	public String getOrderId() throws InterruptedException
	{
	Thread.sleep(4000);
	System.out.println("Order Id is: "+orderId.getText());
	return orderId.getText();
	}
	
	public void clickFirstFavouriteStore1() throws InterruptedException
	{
	Thread.sleep(2000);
	if(toggleFavourite.isEnabled()==false) {
	toggleFavourite.click();
		if(toggleFavourite.isEnabled()==false) {
		toggleFavourite.submit();
		}
		else {
			System.out.println("First store is clicked to Favourite is clicked already");
		}
	System.out.println("First store is clicked to Favourite");
	}
	}
	
	public void clickFirstFavouriteStore() throws InterruptedException
	{
	Thread.sleep(5000);
	if(toggleFavourite.isDisplayed()) {
		System.out.println("Favourite button is displayed");
		toggleFavourite.click();
		System.out.println("Favourite button is clicked");
		if(pleaseSignInToastMsg.isDisplayed()==false) {
			toggleFavourite.click();
			System.out.println("Favourite button is clicked 2nd time");
		}
	}
	System.out.println("Favourite button is finally clicked");
	}

	
	
	
	public void displaypleaseSignInToastMsgText() throws InterruptedException
	{
	Thread.sleep(2000);
	//System.out.println("Please Sign In toast message text: "+pleaseSignInToastMsgText.getText());
	System.out.println("Please Sign In toast message text: "+pleaseSignInToastMsg.getText());
	}
	
	public void verifypleaseSignInToastMsg() throws InterruptedException
	{	
		Thread.sleep(5000);
		System.out.println("Please Sign In Toast message is displayed: "+pleaseSignInToastMsg.isDisplayed());
	}
	
	public void clickgoToOrderBackBtn() throws InterruptedException
	{
	Thread.sleep(2000);
	goToOrderBackBtn.click();
	System.out.println("Go to Order back button is clicked");
	}
	
	public void clickselectLaterBtn() throws InterruptedException
	{
	Thread.sleep(2000);
	selectLaterBtn.click();
	System.out.println("Select later button is clicked");
	}
	
	public void orderAgainPageValidation() throws InterruptedException
	{
		
	Thread.sleep(2000);
	System.out.println("Order Again Page validations: ");
	System.out.println("Order Again Page is displayed");
	System.out.println("Order Again Page text one: "+orderAgainPageTextOne.getText());
	System.out.println("Order Again Page test two: "+orderAgainPageTextTwo.getText());
	System.out.println("Order Again Page Sign In button is displayed: "+orderAgainPageSignInBtn.isDisplayed());
	}
	
	public void favouritePageValidation() throws InterruptedException
	{
		
	Thread.sleep(2000);
	System.out.println("Favourite validations: ");
	System.out.println("Favourite Page is displayed");
	System.out.println("Favourite Page text one: "+orderAgainPageTextOne.getText());
	System.out.println("Favourite Page test two: "+favouritePageTextTwo.getText());
	System.out.println("Favourite Page Sign In button is displayed: "+orderAgainPageSignInBtn.isDisplayed());
	}
	
	public void clickPDPfavouriteBtn() throws InterruptedException
	{
	Thread.sleep(2000);
	if(	PDPfavouriteBtn.isDisplayed()) {
		System.out.println("PDP 'Favourite' button is displayed");
	PDPfavouriteBtn.click();
	if(PDPfavouritePageTextOne.isDisplayed()==false) {
		PDPfavouriteBtn.click();
		System.out.println("PDP 'Favourite' button is clicked 2nd time");
	}
	System.out.println("PDP 'Favourite' button is clicked");
	Thread.sleep(5000);
	}
	}
	public void PDPfavouritePageValidation() throws InterruptedException
	{
		
	Thread.sleep(3000);
	System.out.println("PDP Favourite validations: ");
	System.out.println("PDP Favourite Page is displayed");
	System.out.println("PDP Favourite Page text one: "+PDPfavouritePageTextOne.getText());
	System.out.println("PDP Favourite Page test two: "+PDPfavouritePageTexttwo.getText());
	System.out.println("PDP Favourite Page Sign In button is displayed: "+PDPfavouritePageSignInOrSignUpBtn.isDisplayed());
	}
	
	public void clickbackBtn() throws InterruptedException
	{
	Thread.sleep(2000);
	backBtn.click();
	System.out.println("backBtn button is clicked");
	}
	
	
	public void clickPDPBackBtn() throws InterruptedException
	{
	ProfilePage profilePage = new ProfilePage(driver);
	Thread.sleep(2000);
	goToOrderBackBtn.click();
	goToOrderBackBtn.click();
	clickbackBtn();
	clickbackBtn();
	profilePage.clickProfileTab();
	Thread.sleep(5000);
	}
}

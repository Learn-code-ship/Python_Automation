package GE.DCOM.GetGo.Mobile.Automation.objects;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LocationPage extends AndroidActions {
	AndroidDriver driver;

	public LocationPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(xpath = "//*[@resource-id='search-box']")
	private WebElement searchField;

	@AndroidFindBy(xpath = "//*[@resource-id='view-mode-button']")
	private WebElement listView;

	@AndroidFindBy(xpath = "//*[@accessibility id='expanded']")
	private WebElement filterOption;

	@AndroidFindBy(xpath = "//*[@content-desc='collapsed']")
	private WebElement fuelTypeFilter;

	@AndroidFindBy(xpath = "//*[@text='Distance']")
	private WebElement distanceFilter;

	@AndroidFindBy(xpath = "//*[@text='Price']")
	private WebElement priceFilter;

	@AndroidFindBy(xpath = "//*[@resource-id='stores-list-view']")
	private WebElement storeResults;

	@AndroidFindBy(xpath = "//*[@text='Unleaded']")
	private WebElement fuelType;

	@AndroidFindBy(xpath = "//*[@text='Online Ordering']")
	private WebElement deliveryType;
	
	@AndroidFindBy(xpath = "//*[@resource-id='info-text']")
	private WebElement noKeroseneTypeStores;
	
	@AndroidFindBy(xpath = "//*[@resource-id='ok-button']")
	private WebElement okButton;
	
	@AndroidFindBy(xpath = "//*[@resource-id='store-card-store-name-text']")
	private WebElement selectStore;
	
	@AndroidFindBy(xpath = "//*[@resource-id='store-details-view-location-info']")
	private WebElement storeInfo;
	
	@AndroidFindBy(xpath = "//*[@resource-id='store-details-fuel-info']")
	private WebElement storePrices;
	
	@AndroidFindBy(xpath = "//*[@resource-id='store-details-features']")
	private WebElement storeFeatures;
	
	@AndroidFindBy(xpath = "//*[@resource-id='active-store-button']")
	private WebElement activeStore;
	
	@AndroidFindBy(xpath = "//*[@resource-id='store-card-start-order-button']")
	private WebElement startOrderBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='primary-button']")
	private WebElement primaryOkbutton;
	
	@AndroidFindBy(xpath = "//*[@resource-id='store-details-back-button']")
	private WebElement storeDetailsBackBtn;
	
	
	
	
	
	public void searchStore(String searchKey) throws InterruptedException {
		Thread.sleep(5000);
		searchField.click();
		System.out.println("'Search field' is clicked ");
		searchField.sendKeys(searchKey);
		System.out.println("Input given in Search field is: "+searchKey);
		Thread.sleep(5000);
	}

	public void clickListViewBtn() throws InterruptedException {
				listView.click();
				System.out.println("'List View' button is clicked ");
				Thread.sleep(3000);
	}
		
		
	public boolean verifyStoreFilter() {
		try {
			return fuelTypeFilter.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean verifyDistanceFilter() {
		try {
			return distanceFilter.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public void selectStoreType(String fuelType) throws InterruptedException {
		fuelTypeFilter.click();
		System.out.println("'Fuel type' filter button is clicked ");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@text='" + fuelType + "']")).click();
		Thread.sleep(3000);
	}

	public boolean verifyStoreResults() {
		try {
			return storeResults.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean verifyFuelType() {
		try {
			System.out.println("Fule type displayed is: "+fuelType.getText());
			return fuelType.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean verifyDeliveryType() {
		try {
			System.out.println("Delivery type displayed is: "+deliveryType.getText());
			return deliveryType.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean verifyStoreName(String store) {
		try {
			WebElement storeName = driver
					.findElement(By.xpath("//*[@resource-id='stores-list-view']//*[contains(@text, '" + store + "')]"));
			System.out.println(storeName.getText());
			System.out.println("Store name displayed is: "+storeName.getText());
			return storeName.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public boolean verifyStoreAddress(String pinCode) {
		try {
			WebElement storeAddress = driver.findElement(
					By.xpath("//*[@resource-id='stores-list-view']//*[contains(@text, '" + pinCode + "')]"));
			System.out.println(storeAddress.getText());
			return storeAddress.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}

	public int getStoreCountByFuelType(String fuelType) {
		List<WebElement> storeCount = driver
				.findElements(By.xpath("//*[@resource-id='stores-list-view']//*[@text='" + fuelType + "']"));
		return storeCount.size();
	}

	public void selectPriceFilter() throws InterruptedException {
		distanceFilter.click();
		Thread.sleep(3000);
		priceFilter.click();
		Thread.sleep(3000);
	}

	public boolean validatePriceSorting() {
		try {
			List<WebElement> storeCount = driver
					.findElements(By.xpath("//*[@resource-id='stores-list-view']//*[contains(@text, '$')]"));
			List<Double> prices = new ArrayList<>();

			for (WebElement element : storeCount) {
				String priceText = element.getText().replace("$", "");
				double price = Double.parseDouble(priceText);
				prices.add(price);
			}

			boolean isSorted = true;
			for (int i = 1; i < prices.size(); i++) {
				if (prices.get(i) < prices.get(i - 1)) {
					isSorted = false;
					break;
				}
			}
			return isSorted;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean verifynoKeroseneTypeStores() {
		try {
			System.out.println(noKeroseneTypeStores.isDisplayed());
			Thread.sleep(2000);
			return noKeroseneTypeStores.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}
	public void clickSelectStoreBtn() throws InterruptedException {
		selectStore.click();
		Thread.sleep(2000);
	}
	
	public boolean verifystoreInfo() {
		try {
			System.out.println(storeInfo.isDisplayed());
			Thread.sleep(2000);
			//okButton.click();
			return storeInfo.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}
	
	public boolean verifystorePrices() {
		try {
			System.out.println(storePrices.isDisplayed());
			Thread.sleep(2000);
			//okButton.click();
			return storePrices.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}
	
	public boolean verifystoreFeatures() {
		try {
			System.out.println(storeFeatures.isDisplayed());
			Thread.sleep(2000);
			//okButton.click();
			return storeFeatures.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}
	
	public void clickactiveStore() throws InterruptedException {
		activeStore.click();
		System.out.println("Active store "+activeStore+" is clicked");
		Thread.sleep(2000);
	}
	
	public boolean verifyactiveStoreAddress(String pinCode) {
		try {
			WebElement storeAddress = driver.findElement(
					By.xpath("//*[@resource-id='store-details-view-store-info']//*[contains(@text, '" + pinCode + "')]"));
			System.out.println("Store address is: "+storeAddress.getText());
			return storeAddress.isDisplayed();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return false;
	}
	
	public void selectStoreForStartOrder(String storeNumber) throws InterruptedException
	{
		searchStore(storeNumber);
		try {
            if (startOrderBtn.isDisplayed())
            	System.out.println("Start Order button is displayed in this occurance ");
            {
            	startOrderBtn.click();
            	System.out.println("Start Order button is clicked");
            	Thread.sleep(10000);
            }			
		} catch (Exception e) {
			System.out.println("Start Order button is not displayed in this occurance ");
			
			Thread.sleep(15000);
			searchField.click();
			System.out.println("Store field button is clicked");
			searchField.sendKeys("Store number selected is: "+storeNumber);
			driver.pressKey(new KeyEvent(AndroidKey.ENTER));
			Thread.sleep(5000);
			activeStore.isDisplayed();
			Thread.sleep(15000);
		}
		}
		
	public void clickPrimaryOkbutton() throws InterruptedException {
		primaryOkbutton.click();
		System.out.println("Primary Ok button is clicked");
		Thread.sleep(2000);
	}
	
	public void storeDetailsBackBtn() throws InterruptedException {
		storeDetailsBackBtn.click();
		System.out.println("Store details back button is clicked");
		Thread.sleep(2000);
	}
	public void selectDistanceFilter() throws InterruptedException {
		priceFilter.click();
		Thread.sleep(3000);
		distanceFilter.click();
		Thread.sleep(3000);
	}


}

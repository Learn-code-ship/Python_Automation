package GE.DCOM.GetGo.Mobile.Automation.Tests;

import org.junit.Assert;
import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProductPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;
import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.Creditcard;
import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.CartPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.PaymentPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderConfirmationPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderHistoryPage;

public class EndToEndTests extends BaseTest{
	
	@Test
	public void OrderAnItem() throws InterruptedException
	{
		HomePage homePage = new HomePage(driver);
		StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
		MenuPage menuPage = new MenuPage(driver);
		ProductPage productpage = new ProductPage(driver);
		CartPage cartPage = new CartPage(driver);
		PaymentPage paymentPage = new PaymentPage(driver);
		OrderConfirmationPage orderConfirmationPage = new OrderConfirmationPage(driver);
		User user = dataSet.getUser().get(0);
		Creditcard card = dataSet.getCreditcard().get(0);
		
		Thread.sleep(10000);
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		
		storeSelectionPage.clickOrderTab();
		storeSelectionPage.selectStore(user.getPincode());
		storeSelectionPage.orderHere();
		String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
		
		menuPage.selectMenuItem();
		productpage.selectAddOn();
		String pdpItemPrice = productpage.getItemPrice();
		productpage.clickAddToOrder();
		Thread.sleep(15000);
		menuPage.clickCartIcon();
		String cartItemPrice = cartPage.getItemPrice();
		String cartItemQty = cartPage.getItemQuantity();
		
		Assert.assertEquals(true, cartPage.verifyStore());
		Assert.assertEquals(true, cartPage.verifyPickupAsap());
		Assert.assertEquals(true, cartPage.verifyPickupLater());
		//Assert.assertEquals(true, pdpItemPrice.equals(cartItemPrice));
		
		String cartTotal = cartPage.getTotalPrice();	
		cartPage.clickProceedToPayment();
		Thread.sleep(30000);
		
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();
		Thread.sleep(20000);
		
		String pickupTimeScheduled = orderConfirmationPage.getPickupTime();
		String itemPrice = orderConfirmationPage.getItemPrice();
		String itemTotal = orderConfirmationPage.getTotalPrice();
		String itemQty = orderConfirmationPage.getItemQty();
		Assert.assertEquals(true, pickupTimeScheduled.equals(pickupTimeSelected));
		String orderId = orderConfirmationPage.getOrderId();
		
		Assert.assertEquals(true, orderConfirmationPage.getOrderStatus().equals("Ordered"));
		Assert.assertEquals(true, orderConfirmationPage.verifyMap());
		Assert.assertEquals(true, orderConfirmationPage.verifyCallUsSection());
		Assert.assertEquals(true, orderConfirmationPage.verifyPickItSection());
		Assert.assertEquals(true, cartItemQty.equals(itemQty));
		Assert.assertEquals(true, cartItemPrice.equals(itemPrice));
		Assert.assertEquals(true, cartTotal.equals(itemTotal));
		orderConfirmationPage.cancelOrder();
		Assert.assertEquals(true, orderConfirmationPage.getOrderStatus().equals("Order Canceled"));
		
	}
	
	
	public void OrderAnAlcoholItem() throws InterruptedException
	{
		HomePage homePage = new HomePage(driver);
		ProfilePage profilePage = new ProfilePage(driver);
		StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
		MenuPage menuPage = new MenuPage(driver);
		ProductPage productpage = new ProductPage(driver);
		CartPage cartPage = new CartPage(driver);
		PaymentPage paymentPage = new PaymentPage(driver);
		OrderConfirmationPage orderConfirmationPage = new OrderConfirmationPage(driver);
		OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);
		User user = dataSet.getUser().get(1);
		Creditcard card = dataSet.getCreditcard().get(0);
		
		Thread.sleep(10000);
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		
		storeSelectionPage.clickOrderTab();
		storeSelectionPage.selectStore(user.getPincode());
		storeSelectionPage.orderHere();
		storeSelectionPage.scheduleTimeForAlcoholItem();
		
		menuPage.selectAlcoholItem();
		String pdpItemPrice = productpage.getItemPrice();
		productpage.clickAddToOrder();
		Thread.sleep(15000);
		menuPage.clickCartIcon();
		String cartItemPrice = cartPage.getItemPrice();
		
		Assert.assertEquals(true, cartPage.verifyStore());
		Assert.assertEquals(true, cartPage.verifyPickupAsap());
		Assert.assertEquals(true, cartPage.verifyPickupLater());
		Assert.assertEquals(true, pdpItemPrice.equals(cartItemPrice));
		Assert.assertEquals(true, cartPage.getTaxPrice().equals("$0.00"));
			
		cartPage.clickProceedToPayment();
		cartPage.verifyAge();
		Thread.sleep(15000);
		
		paymentPage.enterCardDetails(card.getCreditCardType(), card.getCreditCardNumber(), card.getCvv());
		paymentPage.selectMonth();
		paymentPage.selectYear();
		paymentPage.enterAddressDetails(user.getAddress(), user.getStreet(), user.getCity(), user.getPincode());
		paymentPage.selectState();
		paymentPage.placeOrder();		
		Thread.sleep(2000);
		
		String orderId = orderConfirmationPage.getOrderId();		
		String pickupDayScheduled = orderConfirmationPage.getPickupDay();
		String pickupTimeScheduled = orderConfirmationPage.getPickupTime();
		String itemTotal = orderConfirmationPage.getTotalPrice();
		Assert.assertEquals(true, orderConfirmationPage.getTaxPrice().equals("$0.00"));
		
		driver.navigate().back();
		profilePage.clickProfileTab();
		profilePage.clickOrdersBtn();
		
		String pickupDay = orderHistoryPage.getPickupDay();
		String pickupTime = orderHistoryPage.getPickupTime();		
		String orderTotal = orderHistoryPage.getTotalPrice();
		
		Assert.assertEquals(true, orderHistoryPage.getOrderId().equals(orderId));	
		Assert.assertEquals(true, orderHistoryPage.getOrderStatus().equals("Ordered"));
		Assert.assertEquals(true, pickupDayScheduled.equals(pickupDay));
		Assert.assertEquals(true, pickupTimeScheduled.equals(pickupTime));
		Assert.assertEquals(true, itemTotal.equals(orderTotal));
		Assert.assertEquals(true, orderHistoryPage.verifyViewDetailBtn());
	}

}

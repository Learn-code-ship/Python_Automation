package GE.DCOM.GetGo.Mobile.Automation.Tests;

import org.junit.Assert;

import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.Fueltype;
import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.Stores;
import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.CartPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.LocationPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrdersPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProductPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;

public class LocationTests extends BaseTest {
		LocationPage locationPage = new LocationPage(driver);
		Fueltype fueltype = dataSet.getFueltype().get(0);
		HomePage homePage = new HomePage(driver);
		ProfilePage profilePage = new ProfilePage(driver);
		StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
		User user = dataSet.getUser().get(0);

		
		@Test
		public void StoreFilterAndSortTest_58674() throws InterruptedException
		{
			
			Thread.sleep(10000);
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
			homePage.clickLocationTab();
			locationPage.searchStore(user.getPincode());
			locationPage.clickListViewBtn();
			Assert.assertEquals(true, locationPage.verifyStoreResults());
			Assert.assertEquals(true, locationPage.verifyStoreFilter());
			Assert.assertEquals(true, locationPage.verifyDistanceFilter());
			locationPage.selectStoreType(fueltype.getSuperType());
			Assert.assertEquals(true, locationPage.getStoreCountByFuelType(fueltype.getSuperType())>0);
			locationPage.selectPriceFilter();
			Assert.assertEquals(true, locationPage.validatePriceSorting());
			locationPage.selectStoreType(fueltype.getPremiumType());
			Assert.assertEquals(true, locationPage.getStoreCountByFuelType(fueltype.getPremiumType())>0);
			locationPage.selectStoreType(fueltype.getDieselType());
			Assert.assertEquals(true, locationPage.getStoreCountByFuelType(fueltype.getDieselType())>0);
			locationPage.selectDistanceFilter();
			locationPage.clickListViewBtn();
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
		}
		
		@Test
		public void StoreSearchTest_58675() throws InterruptedException
		{
			Thread.sleep(10000);
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
			Stores store = dataSet.getStores().get(2);
			homePage.clickLocationTab();
			locationPage.searchStore(store.getPinCode());
			locationPage.clickListViewBtn();
			locationPage.selectStoreType(fueltype.getSuperType());
			locationPage.selectStoreType(fueltype.getDieselType());
			locationPage.selectStoreType(fueltype.getKeroseneType());
			locationPage.selectStoreType(fueltype.getPremiumType());
			locationPage.selectStoreType(fueltype.getUnleadedType());
			Assert.assertEquals(true, locationPage.verifyFuelType());
			Assert.assertEquals(true, locationPage.verifyDeliveryType());
			Assert.assertEquals(true, locationPage.verifyStoreName(store.getStoreName()));
			Assert.assertEquals(true, locationPage.verifyStoreAddress(store.getPinCode()));
			locationPage.clickListViewBtn();
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
		}
		
	
		@Test
		public void NoFuelTypeInPincodeTest_46148() throws InterruptedException
		{
			Thread.sleep(10000);
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
			homePage.clickLocationTab();
			locationPage.searchStore(user.getPincode());
			locationPage.clickListViewBtn();
			Assert.assertEquals(true, locationPage.verifyStoreResults());
			Assert.assertEquals(true, locationPage.verifyStoreFilter());
			locationPage.selectStoreType(fueltype.getKeroseneType());
			Assert.assertEquals(true, locationPage.getStoreCountByFuelType(fueltype.getKeroseneType())>0);
			locationPage.searchStore(user.getNoKerosenepPincode());
			Thread.sleep(5000);
			Assert.assertEquals(true,locationPage.verifynoKeroseneTypeStores());
			locationPage.clickPrimaryOkbutton();
			locationPage.clickListViewBtn();
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
			
		}
		@Test
		public void StoreDetailsTest_16046() throws InterruptedException
		{
			
			Thread.sleep(10000);
			homePage.verifyBlackFridayFlashMsg();
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();
			homePage.clickLocationTab();
			locationPage.searchStore(user.getPincode());
			locationPage.selectStoreType(fueltype.getUnleadedType());
			locationPage.clickactiveStore();
			Assert.assertEquals(true,locationPage.verifystoreInfo());
			Assert.assertEquals(true,locationPage.verifystorePrices());
			Assert.assertEquals(true,locationPage.verifystoreFeatures());
			locationPage.storeDetailsBackBtn();
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
			
		}
	
		@Test
		public void StoreOnlineOrderingTest_16046() throws InterruptedException
		{
			homePage.verifyBlackFridayFlashMsg();
			Thread.sleep(10000);
			homePage.closepopup();
			homePage.signin(user.getEmail(), user.getPassword());
			homePage.clickHomeTab();             
			homePage.clickLocationTab();
			locationPage.selectStoreForStartOrder(user.getPincode());
			storeSelectionPage.checkModalOkBtn();
			String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
			System.out.println(pickupTimeSelected);
			profilePage.Signout();
			Assert.assertEquals(true, profilePage.verifySignInBtn());
		}

		@Test
		public void LocationPageStartOrderTest() throws InterruptedException
		{
				homePage.verifyBlackFridayFlashMsg();
				Thread.sleep(10000);
				homePage.closepopup();
				homePage.signin(user.getEmail(), user.getPassword());
				homePage.clickHomeTab();             
				homePage.clickLocationTab();
				locationPage.selectStoreForStartOrder(user.getPincode());
				storeSelectionPage.checkModalOkBtn();
				String pickupTimeSelected = storeSelectionPage.scheduleLaterPickupTime();
				System.out.println(pickupTimeSelected);
				profilePage.Signout();
				Assert.assertEquals(true, profilePage.verifySignInBtn());								

		}
		
	
		
		

}

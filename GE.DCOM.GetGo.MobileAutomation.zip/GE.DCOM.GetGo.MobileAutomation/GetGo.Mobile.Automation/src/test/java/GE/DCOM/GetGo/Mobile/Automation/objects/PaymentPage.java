package GE.DCOM.GetGo.Mobile.Automation.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PaymentPage extends AndroidActions{
	AndroidDriver driver;

	public PaymentPage(AndroidDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@text='Credit Card']")
	private WebElement creditCardTab;
	
	@AndroidFindBy(xpath = "//*[@text='PayPal']")
	private WebElement payPalTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='fullName']")
	private WebElement cardHolderName;
	
	@AndroidFindBy(xpath = "//*[@resource-id='accountNumber']")
	private WebElement cardNumber;
	
	@AndroidFindBy(xpath = "//*[@resource-id='expMonth']")
	private WebElement cardExpMonth;
	
	@AndroidFindBy(xpath = "//*[@resource-id='expYear']")
	private WebElement cardExpYear;
	
	@AndroidFindBy(xpath = "//*[@resource-id='cvv']")
	private WebElement cvv;
	
	@AndroidFindBy(xpath = "//*[@resource-id='BillingAddress_LineOne']")
	private WebElement billingAddressLine1;
	
	@AndroidFindBy(xpath = "//*[@resource-id='BillingAddress_LineTwo']")
	private WebElement billingAddressLine2;
	
	@AndroidFindBy(xpath = "//*[@resource-id='BillingAddress_City']")
	private WebElement city;
	
	@AndroidFindBy(xpath = "//*[@resource-id='BillingAddress_State']")
	private WebElement state;
	
	@AndroidFindBy(xpath = "//*[@resource-id='BillingAddress_ZipCode']")
	private WebElement zipCode;
	
	@AndroidFindBy(xpath = "//*[@resource-id='SaveCardInformation']")
	private WebElement saveCardBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='sendPayment']")
	private WebElement placeOrderBtn;
	
	public void enterCardDetails(String cardName, String cardNumb, String cvvNumb)
	{
		cardHolderName.sendKeys(cardName);
		System.out.println("Card holder name is: "+cardName);
		cardNumber.sendKeys(cardNumb);
		System.out.println("Card number is: "+cardNumb);
		//cardExpMonth.sendKeys(expMonth);
		//cardExpYear.sendKeys(expYear);
		cvv.sendKeys(cvvNumb);
		System.out.println("Card cvv is: "+cvvNumb);
	}
	
	public void selectMonth() throws InterruptedException {
		cardExpMonth.click();
		System.out.println("Card expiry month is clicked  ");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@text='May']")).click();		
	}
	
	public void selectYear() throws InterruptedException {
		cardExpYear.click();
		System.out.println("Card expiry year is clicked  ");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@text='2025']")).click();		
	}
	
	public void selectState() throws InterruptedException {
		state.click();
		System.out.println("State is clicked  ");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@text='California']")).click();		
	}
	
	public void enterAddressDetails(String AddLine1, String AddLine2, String cityName, String zip) 
	{
		billingAddressLine1.sendKeys(AddLine1);
		System.out.println("Billing address line 1 is: "+AddLine1);
		billingAddressLine2.sendKeys(AddLine2);
		System.out.println("Billing address line 2 is: "+AddLine2);
		city.sendKeys(cityName);
		System.out.println("City name is: "+cityName);
		//state.sendKeys(stateName)
		zipCode.sendKeys(zip);
		System.out.println("Zip code is: "+zip);
	}
	
	public void saveCreditCard()
	{
		saveCardBtn.click();
		System.out.println("Save Credit card button is clicked ");
	}
	
	public void placeOrder()
	{
		placeOrderBtn.click();
		System.out.println("Place Order button is clicked ");
	}
}

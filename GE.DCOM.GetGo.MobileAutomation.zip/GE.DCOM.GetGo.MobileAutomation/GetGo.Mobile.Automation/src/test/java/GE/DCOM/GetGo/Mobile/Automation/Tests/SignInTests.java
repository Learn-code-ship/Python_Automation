package GE.DCOM.GetGo.Mobile.Automation.Tests;

import org.junit.Assert;
import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;


public class SignInTests extends BaseTest{
	
	@Test
	public void UserSignInTest() throws InterruptedException
	{
		HomePage homePage = new HomePage(driver);
		ProfilePage profilePage = new ProfilePage(driver);
		User user = dataSet.getUser().get(0);
		
		Thread.sleep(10000);
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.clickProfileTab();
		profilePage.clickPersonalInfoBtn();
		profilePage.clickLogoutBtn();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
}

package GE.DCOM.GetGo.Mobile.Automation.objects;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import GE.DCOM.GetGo.Mobile.Automation.utils.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ProfilePage extends AndroidActions {

	AndroidDriver driver;

	public ProfilePage(AndroidDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(xpath = "//*[@resource-id='account-tab-icon']")
	private WebElement profiletab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='personal-info-card']")
	private WebElement personalinfobtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-firstName-input']")
	private WebElement firstNameField;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-lastName-input']")
	private WebElement lastNameField;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-Birthday-input']")
	private WebElement dobField;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-PhoneInput']")
	private WebElement phoneField;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-submit-button']")
	private WebElement saveChangeBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Profile updated successfully']")
	private WebElement toastMessage;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-delete-account-button']")
	private WebElement deleteAccountBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-back-button']")
	private WebElement profileBackBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-change-password-button']")
	private WebElement changePasswordLink;
	
	@AndroidFindBy(xpath = "//*[@resource-id='orders-card']")
	private WebElement ordersCard;
	
	@AndroidFindBy(xpath = "//*[@resource-id='edit-profile-logout-button']")
	private WebElement logoutobtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='SignInButton']")
	private WebElement signinbtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='Wallet-perks-banner']//*[1]")
	private WebElement perks;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-history-view']")
	private WebElement orderHistoryView;
	
	@AndroidFindBy(xpath = "//*[@text='Hello There!']")
	private WebElement orderHistoryViewTextOne;
	
	@AndroidFindBy(xpath = "//*[@text='Please sign in to view your order history.']")
	private WebElement orderHistoryViewTextTwo;
	
	@AndroidFindBy(xpath = "//*[@resource-id='back-button']")
	private WebElement backBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Are you 21 or older?']")
	private WebElement areyou21orolderPopupTxt;
	
//	@AndroidFindBy(xpath = "//*[@text='You are leaving the GetGo application for a site hosted by a third-party that requires users to be 21 years of age or older. The third-party's Policy and Terms govern your use of its site(s)']")
//	private WebElement beerPopupText;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'You are leaving the GetGo application for a site') and @class='android.widget.TextView']")
	private WebElement beerPopupText;
	
	@AndroidFindBy(xpath = "//*[@text='Yes, Proceed' and @resource-id='button-text']")
	private WebElement yesProceedBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Close' and @resource-id='button-text']")
	private WebElement closeBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='just-for-you-tab']")
	private WebElement justForYouTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='order-again-tab']")
	private WebElement couponsTab;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'Personalized offers are waiting') and @class='android.widget.TextView']")
	private WebElement personalizedOffersText;
	
	@AndroidFindBy(xpath ="//*[contains(@text, 'Sign in to unlock offers that have been personalized just for you.') and @class='android.widget.TextView']")
	private WebElement signInOffersText;
	
	@AndroidFindBy(xpath = "//*[@resource-id='profile-perks-banner']")
	private WebElement profilePerksBanner;
	
	@AndroidFindBy(xpath = "//*[@text='How It Works' and @resource-id='button-text']")
	private WebElement howItWorksBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='earning-tab']")
	private WebElement earningTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='redeeming-tab']")
	private WebElement redeemingTab;
	
	@AndroidFindBy(xpath = "//*[@resource-id='FAQs-button']")
	private WebElement FAQBtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='perks-faq-view']")
	private WebElement perksFAQview;
	
	@AndroidFindBy(xpath = "//*[@resource-id='perks-faq-header']")
	private WebElement perksFAQheader;
	
	
	public void clickProfileTab()
	{
		profiletab.click();
		System.out.println("Profile tab is clicked ");
	}
	
	public void clickPersonalInfoBtn()
	{
		personalinfobtn.click();
		System.out.println("Personal info tab is clicked ");
	}
	
	public void clickLogoutBtn()
	{
		System.out.println("Click on Logout button is clicked ");
		logoutobtn.click();
	}
	
	public boolean verifySignInBtn() throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			if(signinbtn.isDisplayed())
	        {
	        	System.out.println("signin btn is Displayed");
	        	Thread.sleep(1000);
	        }	
	
		} catch (Exception e) {
			System.out.println("signin btn is not Displayed");
		}
		return signinbtn.isDisplayed();
	}
	
	public void clickOrdersBtn() throws InterruptedException
	{
		ordersCard.click();
		System.out.println("Orders card is clicked ");
		Thread.sleep(10000);
	}
	
	public void updateFirstName(String firstName)
	{
		System.out.println("Orders card is clicked ");
		System.out.println("First name is clicked "+firstName);
		firstNameField.sendKeys(firstName);
	}
	
	public void updateLastName(String lastName)
	{
		lastNameField.click();
		System.out.println("First name is clicked "+lastName);
		lastNameField.sendKeys(lastName);
	}
	
	public void updatDob(String dob)
	{
		dobField.click();
		System.out.println("DOB field is clicked ");
		dobField.sendKeys(dob);
		System.out.println("DOB selcted: "+dob);
	}
	
	public void updatePhone(String phone)
	{
		phoneField.click();
		System.out.println("Phone  field is clicked ");
		phoneField.sendKeys(phone);
		System.out.println("DOB selcted: "+phone);
	}
	
	public void clickSaveBtn()
	{
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		saveChangeBtn.click();
		System.out.println("Save change button is clicked ");
	}
	
	public String getFirstName()
	{
		String First_name=firstNameField.getText();
		System.out.println("First name is: "+First_name);
		return First_name;
	}
	
	public String getLastName()
	{
		String Last_name=lastNameField.getText();
		System.out.println("Last name is: "+Last_name);
		return Last_name;
	}
	
	public String getDob()
	{
		String DOB=dobField.getText();
		System.out.println("DOB is: "+DOB);
		return DOB;
	}
	
	public String getPhone()
	{
		String Phone_Field=phoneField.getText();
		System.out.println("Phone field is: "+Phone_Field);
		return Phone_Field;
	}
	
	public void clickBackBtn()
	{
		profileBackBtn.click();
		System.out.println("Profile back button is clicked ");
	}
	
	public boolean verifyToastMessage()
	{
		try {
            return toastMessage.isDisplayed();            
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
	}
	
	public String getTotalPerks() 
	{
		String Perks=perks.getText();
		System.out.println("Perks is: "+Perks);
		return Perks;
	}
	
	public void Signout() {
		this.clickProfileTab();
		this.clickPersonalInfoBtn();
		this.clickLogoutBtn();
	}
	
	public void clickordersCard() throws InterruptedException
	{
		ordersCard.click();
		System.out.println("Orders card is clicked ");
		Thread.sleep(10000);
		
	}
	
	public void verifyorderHistoryView()
	{
		if(orderHistoryView.isDisplayed()) {
		System.out.println("Order History page is displayed");
		}
	}
	
	public void verifyOrderHistoryPageText() 
	{
		System.out.println("Order History Page text one: "+orderHistoryViewTextOne.getText());
		System.out.println("Order History Page test two: "+orderHistoryViewTextTwo.getText());
		System.out.println("Order History Page Sign In button is displayed: "+signinbtn.isDisplayed());
		
	}
	
	public void clickOrderHistoryBackBtn() throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			if(backBtn.isDisplayed())
            {
				backBtn.click();
            	System.out.println("back Btn is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("back Btn is not clicked");
		}
	
	}
	public void findTotalPerks()
	{
		int noOfperks=0;
		try {
			String perks = this.getTotalPerks();
			if(perks=="") {
				System.out.println("These are no perks");
			}else {
				noOfperks = Integer.parseInt(this.getTotalPerks());
			if(noOfperks>0)	
				System.out.println("These are total perks "+noOfperks);  
			}
        } catch (Exception e) {
            System.out.println("These are no perks");
        }
		
	}
	public boolean verifyAreyou21orolderPopuptextDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(areyou21orolderPopupTxt.isDisplayed())
            {
            	System.out.println("Are you 21 or older Popup text is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("Are you 21 or older Popup text is not Displayed");
		}
		return areyou21orolderPopupTxt.isDisplayed();
	}
	
	public boolean verifybeerPopupTextDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(beerPopupText.isDisplayed())
            {
            	System.out.println("Beer and Liqour validation Text is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("Beer and Liqour validation Text is not Displayed");
		}
		return beerPopupText.isDisplayed();
	}
	
	public boolean verifyyesProceedBtnDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(yesProceedBtn.isDisplayed())
            {
            	System.out.println("yes Proceed Btn is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("yes Proceed Btn is not Displayed");
		}
		return yesProceedBtn.isDisplayed();
	}
	
	public boolean verifycloseBtnDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(closeBtn.isDisplayed())
            {
            	System.out.println("close Btn is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("close Btn is not Displayed");
		}
		return closeBtn.isDisplayed();
	}
	
	public void clickCloseBtn() throws InterruptedException
	{
		Thread.sleep(1000);
		try {
			if(closeBtn.isDisplayed())
            {
				closeBtn.click();
            	Thread.sleep(1000);
            	System.out.println("Age Verified Offers cancel Btn is Clicked");
            }	
    
		} catch (Exception e) {
			System.out.println("Age Verified Offers cancel Btn is not clicked");
		}
	}
	public boolean verifyJustForYouTabIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(justForYouTab.isDisplayed())
            {
            	System.out.println("just For You Tab is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("just For You Tab is not Displayed");
		}
		return justForYouTab.isDisplayed();
	}
	public void clickJustForYouTab() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(justForYouTab.isDisplayed())
            {
				justForYouTab.click();
            	System.out.println("just For You Tab is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("just For You Tab is not clicked");
		}		
	}
	public boolean verifyCouponsTabIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(couponsTab.isDisplayed())
            {
            	System.out.println("coupons Tab is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("coupons Tab is not Displayed");
		}
		return couponsTab.isDisplayed();
	}
	public void clickCouponsTab() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(couponsTab.isDisplayed())
            {
				couponsTab.click();
            	System.out.println("coupons Tab is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("coupons Tab is not clicked");
		}
	}
	public boolean verifyPersonalizedOffersTextIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(personalizedOffersText.isDisplayed())
            {
            	System.out.println("personalized Offers Text is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("personalized Offers Text is not Displayed");
		}
		return personalizedOffersText.isDisplayed();
	}
	public boolean verifySignInOffersTextIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(signInOffersText.isDisplayed())
            {
            	System.out.println("signIn Offers Text is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("signIn Offers Text is not Displayed");
		}
		return signInOffersText.isDisplayed();
	}
	public void verifyElementsUnderJustForYouAndCouponsGuestUser() throws InterruptedException {
		Thread.sleep(3000);
		this.verifyJustForYouTabIsDisplayed();
		this.verifyCouponsTabIsDisplayed();
		this.verifyPersonalizedOffersTextIsDisplayed();
		this.verifySignInOffersTextIsDisplayed();
		this.verifySignInBtn();	
	}
	public void verifyElementsUnderBeerAndLiquor() throws InterruptedException {
		Thread.sleep(2000);
		this.verifyAreyou21orolderPopuptextDisplayed();
		this.verifybeerPopupTextDisplayed();
		this.verifyyesProceedBtnDisplayed();
		this.verifycloseBtnDisplayed();
	}
	public boolean verifyprofilePerksBannerIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(profilePerksBanner.isDisplayed())
            {
            	System.out.println("profile Perks Banner is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("profile Perks Banner is not Displayed");
		}
		return profilePerksBanner.isDisplayed();
	}
	public void clickProfilePerksBanner() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(profilePerksBanner.isDisplayed())
            {
				profilePerksBanner.click();
            	System.out.println("profile Perks Banner is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("profile Perks Banner is not clicked");
		}
	}
	public boolean verifyHowItWorksBtnIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(howItWorksBtn.isDisplayed())
            {
            	System.out.println("how It Works Btn is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("how It Works Btn is not Displayed");
		}
		return howItWorksBtn.isDisplayed();
	}
	public void clickHowItWorksBtn() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(howItWorksBtn.isDisplayed())
            {
				howItWorksBtn.click();
            	System.out.println("How It Works Btn is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("How It Works Btn is not clicked");
		}
	}
	public boolean verifyEarningTabIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(earningTab.isDisplayed())
            {
            	System.out.println("earning Tab is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("earning Tab is not Displayed");
		}
		return earningTab.isDisplayed();
	}
	public void clickEarningTab() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(earningTab.isDisplayed())
            {
				earningTab.click();
            	System.out.println("earning Tab is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("earning Tab is not clicked");
		}
	}
	public boolean verifyRedeemingTabIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(redeemingTab.isDisplayed())
            {
            	System.out.println("redeeming Tab is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("redeeming Tab is not Displayed");
		}
		return redeemingTab.isDisplayed();
	}
	public void clickRedeemingTab() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(redeemingTab.isDisplayed())
            {
				redeemingTab.click();
            	System.out.println("redeeming Tab is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("redeeming Tab is not clicked");
		}
	}
	public void verifyElementsUnderHowItWorks() throws InterruptedException {
		Thread.sleep(2000);
		this.verifyEarningTabIsDisplayed();
		this.clickRedeemingTab();
		this.verifyRedeemingTabIsDisplayed();
		this.clickEarningTab();
		this.clickOrderHistoryBackBtn();
	}
	public boolean verifyFAQBtnIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(FAQBtn.isDisplayed())
            {
            	System.out.println("FAQ Btn is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("FAQ Btn is not Displayed");
		}
		return FAQBtn.isDisplayed();
	}
	public void clickFAQBtn() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(FAQBtn.isDisplayed())
            {
				FAQBtn.click();
            	System.out.println("FAQ Btn is clicked");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("FAQ Btn is not clicked");
		}
	}
	public boolean verifyPerksFAQviewIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(perksFAQview.isDisplayed())
            {
            	System.out.println("perks FAQ view is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("perks FAQ view is not Displayed");
		}
		return perksFAQview.isDisplayed();
	}
	public boolean verifyPerksFAQheaderIsDisplayed() throws InterruptedException
	{	
		Thread.sleep(1000);
		try {
			if(perksFAQheader.isDisplayed())
            {
            	System.out.println("perks FAQ header is Displayed");
            	Thread.sleep(1000);
            }	
    
		} catch (Exception e) {
			System.out.println("perks FAQ header is not Displayed");
		}
		return perksFAQheader.isDisplayed();
	}
}

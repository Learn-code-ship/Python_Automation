package GE.DCOM.GetGo.Mobile.Automation.Tests;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.User;
import GE.DCOM.GetGo.Mobile.Automation.objects.CartPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.HomePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.LocationPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.MenuPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrderHistoryPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.OrdersPage;
import GE.DCOM.GetGo.Mobile.Automation.objects.ProfilePage;
import GE.DCOM.GetGo.Mobile.Automation.objects.StoreSelectionPage;

public class ProfileTests extends BaseTest{
	
	HomePage homePage = new HomePage(driver);
	ProfilePage profilePage = new ProfilePage(driver);
	User user = dataSet.getUser().get(0);
	LocationPage locationPage = new LocationPage(driver);
	StoreSelectionPage storeSelectionPage = new StoreSelectionPage(driver);
	OrdersPage ordersPage = new OrdersPage(driver);
	OrderHistoryPage orderHistoryPage = new OrderHistoryPage(driver);
	MenuPage menuPage = new MenuPage(driver);
	CartPage cartPage = new CartPage(driver);
	
	
	public void UpdateProfileTest() throws InterruptedException 
	{
				
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.clickProfileTab();
		profilePage.clickPersonalInfoBtn();
		profilePage.updateFirstName(user.getEditFirstName());
		profilePage.updateLastName(user.getEditLastName());
		profilePage.updatDob(user.getEditDob());
		profilePage.updatePhone(user.getEditphone());
		profilePage.clickSaveBtn();
		
		Thread.sleep(10000);
		//profilePage.verifyToastMessage();
		profilePage.clickPersonalInfoBtn();
		Assert.assertEquals(true, profilePage.getFirstName().equals(user.getEditFirstName()));
		Assert.assertEquals(true, profilePage.getLastName().equals(user.getEditLastName()));
		Assert.assertEquals(true, profilePage.getDob().equals(user.getEditDob()));
		Assert.assertEquals(true, profilePage.getPhone().equals(user.getEditphone()));
		
		profilePage.clickBackBtn();
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getEditFirstName()));
		
		profilePage.clickProfileTab();
		profilePage.clickPersonalInfoBtn();
		profilePage.updateFirstName(user.getFirstName());
		profilePage.updateLastName(user.getLastName());
		profilePage.updatDob(user.getDob());
		profilePage.updatePhone(user.getPhone());
		profilePage.clickSaveBtn();
		
		Thread.sleep(10000);
		//profilePage.verifyToastMessage();
		profilePage.clickPersonalInfoBtn();
		Assert.assertEquals(true, profilePage.getFirstName().equals(user.getFirstName()));
		Assert.assertEquals(true, profilePage.getLastName().equals(user.getLastName()));
		Assert.assertEquals(true, profilePage.getDob().equals(user.getDob()));
		Assert.assertEquals(true, profilePage.getPhone().equals(user.getPhone()));
		
		profilePage.clickBackBtn();
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	} 
  public void EAIVAgeVerifiedOffersAccountTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.clickProfileTab();
		homePage.clickAgeVerifiedOffersBtn();
		Assert.assertEquals(true, homePage.verifyAgeVerifiedOffersCigarettesTobaccoBtnDisplayed());
		Assert.assertEquals(true, homePage.verifyAgeVerifiedOffersBeerWineLiquorBtnDisplayed());
		Assert.assertEquals(true, homePage.verifyAgeVerifiedOffersCancelBtnDisplayed());
		homePage.clickAgeVerifiedOffersCancelBtn();
 		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
  public void EAIVBeerWineAndLiquorAccountTest() throws InterruptedException
	{
		Thread.sleep(10000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.clickProfileTab();
		homePage.clickAgeVerifiedOffersBtn();
		homePage.clickAgeVerifiedOffersBeerWineLiquorBtn();
		profilePage.verifyElementsUnderBeerAndLiquor();
		profilePage.clickCloseBtn();;
 		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
  
	public void EAIVCigarettesTobaccoAgeVerificationHomeTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		homePage.scrollToBottom("Age-Verified Offers");
		homePage.clickAgeVerifiedOffersBtn();
		homePage.clickAgeVerifiedOffersCigarettesTobaccoBtn();
		homePage.verifyElementsUnderJustForYouAndCouponsSignedNonVerifiedUser();
		profilePage.clickCouponsTab();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}

	public void EAIVCigarettesTobaccoAgeVerificationAccountTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.clickProfileTab();
		homePage.clickAgeVerifiedOffersBtn();
		homePage.clickAgeVerifiedOffersCigarettesTobaccoBtn();
		homePage.verifyElementsUnderJustForYouAndCouponsSignedNonVerifiedUser();
		profilePage.clickCouponsTab();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
 
	public void myPerksValidationTestAccountTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.clickProfileTab();
		profilePage.clickProfilePerksBanner();
		profilePage.clickHowItWorksBtn();
		profilePage.verifyElementsUnderHowItWorks();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}
 @Test
	public void FAQNavigationAccountTest() throws InterruptedException
	{
		Thread.sleep(5000);
		homePage.verifyBlackFridayFlashMsg();
		homePage.closepopup();
		homePage.signin(user.getEmail(), user.getPassword());
		homePage.clickHomeTab();
		Assert.assertEquals(true, homePage.loggedInAccount(user.getFirstName()));
		profilePage.clickProfileTab();
		profilePage.clickProfilePerksBanner();
		homePage.scrollToBottom("FAQ's");
		profilePage.clickFAQBtn();;
		profilePage.verifyPerksFAQheaderIsDisplayed();
		profilePage.verifyPerksFAQviewIsDisplayed();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.clickOrderHistoryBackBtn();
		profilePage.Signout();
		Assert.assertEquals(true, profilePage.verifySignInBtn());
	}


  
	
	

	
	
	


}

package GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities;

public class Fueltype {
	private String unleadedType;
  	private String superType;
  	private String premiumType;
  	private String achType;
  	private String dieselType;
  	private String keroseneType;

    public String getUnleadedType() {
        return unleadedType;
    }

    public void setUnleadedType(String unleadedType) {
        this.unleadedType = unleadedType;
    }
    
    public String getSuperType() {
        return superType;
    }

    public void setSuperType(String superType) {
        this.superType = superType;
    }
    
    public String getPremiumType() {
        return premiumType;
    }

    public void setPremiumType(String premiumType) {
        this.premiumType = premiumType;
    }
    
    public String getAchType() {
        return achType;
    }

    public void setAchType(String achType) {
        this.achType = achType;
    }
    
    public String getDieselType() {
        return dieselType;
    }

    public void setDieselType(String dieselType) {
        this.dieselType = dieselType;
    }
    
    public String getKeroseneType() {
        return keroseneType;
    }

    public void setKeroseneType(String keroseneType) {
        this.keroseneType = keroseneType;
    }
}

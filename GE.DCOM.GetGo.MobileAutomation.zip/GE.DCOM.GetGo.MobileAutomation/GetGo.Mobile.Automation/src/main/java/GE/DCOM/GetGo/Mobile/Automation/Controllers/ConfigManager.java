package GE.DCOM.GetGo.Mobile.Automation.Controllers;

import java.util.*;

import com.fasterxml.jackson.databind.ObjectMapper;

import GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities.DataContainer;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;  

public class ConfigManager {
	
	public static Properties config;

	public static Properties ConfigReader() 
	{
		// TODO Auto-generated method stub
		FileReader reader = null;
		try {
			Path paths = Paths.get(System.getProperty("user.dir"), "config.properties");
			reader = new FileReader(paths.toString());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	      
	    Properties properties=new Properties();  
	    try {
	    	properties.load(reader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	    config = properties;
	    return properties;
	}
	
	
	public static DataContainer JsonReader() {	
		
		String env = ConfigManager.config.getProperty("Environment");
		
		 ObjectMapper objectMapper = new ObjectMapper();
		 	Path filePath = Paths.get(System.getProperty("user.dir"), "TestData", env + "TestData.json");
	        File jsonFile = new File(filePath.toString());
	        try {

	            DataContainer dataContainer = objectMapper.readValue(jsonFile, DataContainer.class);
	            return dataContainer;

	        } catch (IOException e) {
	            e.printStackTrace();
	            return null;
	        }
	}

}

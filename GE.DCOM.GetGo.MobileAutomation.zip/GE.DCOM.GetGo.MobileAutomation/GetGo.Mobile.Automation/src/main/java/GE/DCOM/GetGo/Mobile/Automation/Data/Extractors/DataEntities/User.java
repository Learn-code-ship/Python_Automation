package GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities;

import java.nio.charset.StandardCharsets;
import java.util.*;

public class User {
	
	  	private String firstName;
	  	private String lastName;
	  	private String editFirstName;
	  	private String editLastName;
	  	private String dob;
	  	private String editDob;
	  	private String phone;
	  	private String editPhone;
	    private String age;
	    private String email;
	    private String password;
	    private String address;
	    private String street;
	    private String city;
	    private String state;
	    private String pincode;
	    private String noKerosenepPincode;
	    private String orderAgainMessageEmail;
	    private String firstNameOrderAgain;

	    public String getFirstName() {
	        return firstName;
	    }

	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    
	    public String getLastName() {
	        return lastName;
	    }

	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	    public String getEditFirstName() {
	        return editFirstName;
	    }

	    public void setEditFirstName(String editFirstName) {
	        this.editFirstName = editFirstName;
	    }
	    
	    public String getEditLastName() {
	        return editLastName;
	    }

	    public void setEditLastName(String editLastName) {
	        this.editLastName = editLastName;
	    }

	    public String getAge() {
	        return age;
	    }

	    public void setAge(String age) {
	        this.age = age;
	    }
	    
	    public String getDob() {
	        return dob;
	    }

	    public void setDob(String dob) {
	        this.dob = dob;
	    }
	    
	    public String getEditDob() {
	        return editDob;
	    }

	    public void setEditDob(String editDob) {
	        this.editDob = editDob;
	    }
	    
	    public String getPhone() {
	        return phone;
	    }

	    public void setPhone(String phone) {
	        this.phone = phone;
	    }
	    
	    public String getEditphone() {
	        return editPhone;
	    }

	    public void setEditPhone(String editPhone) {
	        this.editPhone = editPhone;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getPassword() {
	        byte[] decoded = Base64.getDecoder().decode(password);
	        String password = new String(decoded, StandardCharsets.UTF_8);
	        System.out.println(password);
	        return password;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }

	    public String getAddress() {
	        return address;
	    }

	    public void setAddress(String address) {
	        this.address = address;
	    }

	    public String getStreet() {
	        return street;
	    }

	    public void setStreet(String street) {
	        this.street = street;
	    }

	    public String getCity() {
	        return city;
	    }

	    public void setCity(String city) {
	        this.city = city;
	    }

	    public String getState() {
	        return state;
	    }

	    public void setState(String state) {
	        this.state = state;
	    }

	    public String getPincode() {
	    	System.out.println("pincode: "+pincode);
	        return pincode;
	    }

	    public void setPincode(String pincode) {
	        this.pincode = pincode;
	    }
	    
	    public String getNoKerosenepPincode() {
	        return noKerosenepPincode;
	    }
	    
	    public void setNoKerosenepPincode(String noKerosenepPincode) {
	        this.noKerosenepPincode = noKerosenepPincode;
	    }
	    public String getorderAgainMessageEmail() {
	        return orderAgainMessageEmail;
	    }

	    public void setorderAgainMessageEmail(String orderAgainMessageEmail) {
	        this.orderAgainMessageEmail = orderAgainMessageEmail;
	    }
	    public String getfirstNameOrderAgain() {
	        return firstNameOrderAgain;
	    }

	    public void setfirstNameOrderAgain(String firstNameOrderAgain) {
	        this.firstNameOrderAgain = firstNameOrderAgain;
	    }
}

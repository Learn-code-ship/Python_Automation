package GE.DCOM.GetGo.Mobile.Automation.utils;

import java.nio.charset.StandardCharsets;
import java.util.*;

public class Encryption {

	public static void main(String[] args) 
	{
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the password to encrypt \n");
		String text = scanner.nextLine();
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        String encoded = Base64.getEncoder().encodeToString(bytes);
        System.out.print(encoded);
	}
}

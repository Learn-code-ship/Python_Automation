package GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities;

public class Stores {
	private String pinCode;
  	private String storeName;
  	private String storeAddress;
  	private String onlineOrdering;

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }
    
    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }
    
    public String getStoreAddress() {
        return storeAddress;
    }

    public void setStoreAddress(String storeAddress) {
        this.storeAddress = storeAddress;
    }
    
    public String getOnlineOrdering() {
        return onlineOrdering;
    }

    public void setOnlineOrdering(String onlineOrdering) {
        this.onlineOrdering = onlineOrdering;
    }
}

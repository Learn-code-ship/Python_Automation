package GE.DCOM.GetGo.Mobile.Automation.Data.Extractors.DataEntities;

import java.util.List;

import org.openqa.selenium.remote.RemoteWebDriver;

public class DataContainer {
	
    private List<User> user;
    private List<Product> product;
    private List<Creditcard> creditcard;
    private List<Paypal> paypal;
    private List<Fueltype> fueltype;
    private List<Stores> stores;

    public List<User> getUser() {
        return user;
    }

    public void setUser(List<User> user) {
        this.user = user;
    }

    public List<Product> getProduct() {
        return product;
    }

    public void setProduct(List<Product> product) {
        this.product = product;
    }
    
    public List<Creditcard> getCreditcard() {
    	return creditcard;
    }
    
    public void setCreditcard(List<Creditcard> creditcard) {
        this.creditcard = creditcard;
    }
    
    public List<Paypal> getPaypal() {
    	return paypal;
    }
    
    public void setPaypal(List<Paypal> paypal) {
        this.paypal = paypal;
    }
    
    public List<Fueltype> getFueltype() {
    	return fueltype;
    }
    
    public void setFueltype(List<Fueltype> fueltype) {
        this.fueltype = fueltype;
    }
    
    public List<Stores> getStores() {
    	return stores;
    }
    
    public void setStores(List<Stores> stores) {
        this.stores = stores;
    }
}
